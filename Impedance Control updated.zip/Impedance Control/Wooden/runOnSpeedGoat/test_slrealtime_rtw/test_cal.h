#ifndef RTW_HEADER_test_cal_h_
#define RTW_HEADER_test_cal_h_
#include "rtwtypes.h"
#include "test_types.h"

/* Storage class 'PageSwitching', for system '<S13>/Enabled Subsystem' */
typedef struct {
  struct_Qf6qpjnCSySZJkQhCiHVS Out1_Y0;/* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S18>/Out1'
                                        */
} test_EnabledSubsystem_cal_type;

/* Storage class 'PageSwitching', for system '<Root>' */
typedef struct {
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S17>/Constant'
                                       */
  real_T CompareToConstant_const_b; /* Mask Parameter: CompareToConstant_const_b
                                     * Referenced by: '<S21>/Constant'
                                     */
  real_T CANWrite1_P1_Size[2];         /* Computed Parameter: CANWrite1_P1_Size
                                        * Referenced by: '<S11>/CAN Write1'
                                        */
  real_T CANWrite1_P1[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S11>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_e[2];      /* Computed Parameter: CANWrite1_P1_Size_e
                                       * Referenced by: '<S12>/CAN Write1'
                                       */
  real_T CANWrite1_P1_e[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S12>/CAN Write1'
      */
  real_T motor2position_Y0;            /* Computed Parameter: motor2position_Y0
                                        * Referenced by: '<S13>/motor 2 position'
                                        */
  real_T motor2velocity_Y0;            /* Computed Parameter: motor2velocity_Y0
                                        * Referenced by: '<S13>/motor 2 velocity'
                                        */
  real_T CANRead1_P1_Size[2];          /* Computed Parameter: CANRead1_P1_Size
                                        * Referenced by: '<S13>/CAN Read1'
                                        */
  real_T CANRead1_P1[6];
                      /* Expression: [initValues(1:4) messageType initValues(6)]
                       * Referenced by: '<S13>/CAN Read1'
                       */
  real_T CANWrite1_P1_Size_m[2];      /* Computed Parameter: CANWrite1_P1_Size_m
                                       * Referenced by: '<S14>/CAN Write1'
                                       */
  real_T CANWrite1_P1_n[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S14>/CAN Write1'
      */
  real_T motor3position_Y0;            /* Computed Parameter: motor3position_Y0
                                        * Referenced by: '<S15>/motor 3 position'
                                        */
  real_T motor3velocity_Y0;            /* Computed Parameter: motor3velocity_Y0
                                        * Referenced by: '<S15>/motor 3 velocity'
                                        */
  real_T CANRead1_P1_Size_f[2];        /* Computed Parameter: CANRead1_P1_Size_f
                                        * Referenced by: '<S15>/CAN Read1'
                                        */
  real_T CANRead1_P1_i[6];
                      /* Expression: [initValues(1:4) messageType initValues(6)]
                       * Referenced by: '<S15>/CAN Read1'
                       */
  real_T CANWrite1_P1_Size_o[2];      /* Computed Parameter: CANWrite1_P1_Size_o
                                       * Referenced by: '<S16>/CAN Write1'
                                       */
  real_T CANWrite1_P1_g[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S16>/CAN Write1'
      */
  real_T CANsetup_P1_Size[2];          /* Computed Parameter: CANsetup_P1_Size
                                        * Referenced by: '<S6>/CAN setup'
                                        */
  real_T CANsetup_P1[40];
  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S6>/CAN setup'
   */
  real_T CANsetup_P2_Size[2];          /* Computed Parameter: CANsetup_P2_Size
                                        * Referenced by: '<S6>/CAN setup'
                                        */
  real_T CANsetup_P2;                  /* Expression: initStruct
                                        * Referenced by: '<S6>/CAN setup'
                                        */
  real_T CANsetup_P3_Size[2];          /* Computed Parameter: CANsetup_P3_Size
                                        * Referenced by: '<S6>/CAN setup'
                                        */
  real_T CANsetup_P3[31];              /* Expression: termStruct
                                        * Referenced by: '<S6>/CAN setup'
                                        */
  real_T Step3_Time;                   /* Expression: 2
                                        * Referenced by: '<S10>/Step3'
                                        */
  real_T Step3_Y0;                     /* Expression: 0
                                        * Referenced by: '<S10>/Step3'
                                        */
  real_T Step3_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S10>/Step3'
                                        */
  real_T Step_Time;                    /* Expression: 1.0
                                        * Referenced by: '<S10>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<S10>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 1
                                        * Referenced by: '<S10>/Step'
                                        */
  real_T CANStatus_P1_Size[2];         /* Computed Parameter: CANStatus_P1_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P1;                 /* Expression: moduleId
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P2_Size[2];         /* Computed Parameter: CANStatus_P2_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P2;                 /* Expression: sampleTime
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P3_Size[2];         /* Computed Parameter: CANStatus_P3_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P3;                 /* Expression: channel
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P4_Size[2];         /* Computed Parameter: CANStatus_P4_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P4;                 /* Expression: busRecovery
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P5_Size[2];         /* Computed Parameter: CANStatus_P5_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P5;                 /* Expression: avgBusLoad
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P6_Size[2];         /* Computed Parameter: CANStatus_P6_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P6;                 /* Expression: opMode
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P7_Size[2];         /* Computed Parameter: CANStatus_P7_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P7;                 /* Expression: brp
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P8_Size[2];         /* Computed Parameter: CANStatus_P8_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P8;                 /* Expression: timeSegment1
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P9_Size[2];         /* Computed Parameter: CANStatus_P9_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P9;                 /* Expression: timeSegment2
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P10_Size[2];        /* Computed Parameter: CANStatus_P10_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P10;                /* Expression: synchronisationJumpWidth
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P11_Size[2];        /* Computed Parameter: CANStatus_P11_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P11;                /* Expression: dataTSEG1
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P12_Size[2];        /* Computed Parameter: CANStatus_P12_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P12;                /* Expression: dataTSEG2
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P13_Size[2];        /* Computed Parameter: CANStatus_P13_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P13;                /* Expression: dataSJW
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P14_Size[2];        /* Computed Parameter: CANStatus_P14_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P14;                /* Expression: txPending
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P15_Size[2];        /* Computed Parameter: CANStatus_P15_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P15;                /* Expression: dataOverrunTx
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P16_Size[2];        /* Computed Parameter: CANStatus_P16_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P16;                /* Expression: receiving
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P17_Size[2];        /* Computed Parameter: CANStatus_P17_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P17;                /* Expression: RxQueueEmpty
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P18_Size[2];        /* Computed Parameter: CANStatus_P18_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P18;                /* Expression: dataOverrunRcv
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P19_Size[2];        /* Computed Parameter: CANStatus_P19_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P19;                /* Expression: errWarnLimit
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P20_Size[2];        /* Computed Parameter: CANStatus_P20_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P20;                /* Expression: errPassLimit
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P21_Size[2];        /* Computed Parameter: CANStatus_P21_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P21;                /* Expression: errBusOff
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P22_Size[2];        /* Computed Parameter: CANStatus_P22_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P22;                /* Expression: busRecoveryCounter
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P23_Size[2];        /* Computed Parameter: CANStatus_P23_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P23;                /* Expression: initModeAct
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P24_Size[2];        /* Computed Parameter: CANStatus_P24_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P24;                /* Expression: busCouplingErr
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P25_Size[2];        /* Computed Parameter: CANStatus_P25_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P25;                /* Expression: transceiverErr
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P26_Size[2];        /* Computed Parameter: CANStatus_P26_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P26;                /* Expression: controllerCpuLoad
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P27_Size[2];        /* Computed Parameter: CANStatus_P27_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P27;                /* Expression: controllerLiveCount
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P28_Size[2];        /* Computed Parameter: CANStatus_P28_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P28;                /* Expression: rxBufferLevel
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P29_Size[2];        /* Computed Parameter: CANStatus_P29_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P29;                /* Expression: txBufferLevel
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P30_Size[2];        /* Computed Parameter: CANStatus_P30_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P30;                /* Expression: arrayOutput
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P31_Size[2];        /* Computed Parameter: CANStatus_P31_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P31;                /* Expression: moduleType
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P32_Size[2];        /* Computed Parameter: CANStatus_P32_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P32;                /* Expression: qtyStatBlk
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P33_Size[2];        /* Computed Parameter: CANStatus_P33_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P33;                /* Expression: ptIdx
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P34_Size[2];        /* Computed Parameter: CANStatus_P34_Size
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T CANStatus_P34;                /* Expression: isFDMod
                                        * Referenced by: '<Root>/CAN Status'
                                        */
  real_T Read1_Amp;                    /* Expression: 1
                                        * Referenced by: '<S7>/Read 1'
                                        */
  real_T Read1_Period;                 /* Computed Parameter: Read1_Period
                                        * Referenced by: '<S7>/Read 1'
                                        */
  real_T Read1_Duty;                   /* Computed Parameter: Read1_Duty
                                        * Referenced by: '<S7>/Read 1'
                                        */
  real_T Read1_PhaseDelay;             /* Expression: 3.001
                                        * Referenced by: '<S7>/Read 1'
                                        */
  real_T Read2_Amp;                    /* Expression: 1
                                        * Referenced by: '<S7>/Read 2'
                                        */
  real_T Read2_Period;                 /* Computed Parameter: Read2_Period
                                        * Referenced by: '<S7>/Read 2'
                                        */
  real_T Read2_Duty;                   /* Computed Parameter: Read2_Duty
                                        * Referenced by: '<S7>/Read 2'
                                        */
  real_T Read2_PhaseDelay;             /* Expression: 3.003
                                        * Referenced by: '<S7>/Read 2'
                                        */
  real_T r_ref_Value;                  /* Expression: 0.5496031746031746
                                        * Referenced by: '<Root>/r_ref'
                                        */
  real_T phi_ref_Value;                /* Expression: -0.001478432282003728
                                        * Referenced by: '<Root>/phi_ref'
                                        */
  real_T Multiply1_Gain;               /* Expression: 180/pi
                                        * Referenced by: '<Root>/Multiply1'
                                        */
  real_T Multiply2_Gain;               /* Expression: 180/pi
                                        * Referenced by: '<Root>/Multiply2'
                                        */
  real_T Multiply_Gain;                /* Expression: 180/pi
                                        * Referenced by: '<Root>/Multiply'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant2'
                                        */
  real_T Write1_Amp;                   /* Expression: 1
                                        * Referenced by: '<S7>/Write 1'
                                        */
  real_T Write1_Period;                /* Computed Parameter: Write1_Period
                                        * Referenced by: '<S7>/Write 1'
                                        */
  real_T Write1_Duty;                  /* Computed Parameter: Write1_Duty
                                        * Referenced by: '<S7>/Write 1'
                                        */
  real_T Write1_PhaseDelay;            /* Expression: 3
                                        * Referenced by: '<S7>/Write 1'
                                        */
  real_T Constant6_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant6'
                                        */
  real_T Write2_Amp;                   /* Expression: 1
                                        * Referenced by: '<S7>/Write 2'
                                        */
  real_T Write2_Period;                /* Computed Parameter: Write2_Period
                                        * Referenced by: '<S7>/Write 2'
                                        */
  real_T Write2_Duty;                  /* Computed Parameter: Write2_Duty
                                        * Referenced by: '<S7>/Write 2'
                                        */
  real_T Write2_PhaseDelay;            /* Expression: 3.002
                                        * Referenced by: '<S7>/Write 2'
                                        */
  uint8_T Constant_Value;              /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S11>/Constant'
                                        */
  uint8_T Constant1_Value;             /* Computed Parameter: Constant1_Value
                                        * Referenced by: '<S11>/Constant1'
                                        */
  uint8_T Constant2_Value_d;           /* Computed Parameter: Constant2_Value_d
                                        * Referenced by: '<S11>/Constant2'
                                        */
  uint8_T Constant3_Value;             /* Computed Parameter: Constant3_Value
                                        * Referenced by: '<S11>/Constant3'
                                        */
  uint8_T Constant4_Value;             /* Computed Parameter: Constant4_Value
                                        * Referenced by: '<S11>/Constant4'
                                        */
  uint8_T Constant5_Value;             /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S11>/Constant5'
                                        */
  uint8_T Constant6_Value_b;           /* Computed Parameter: Constant6_Value_b
                                        * Referenced by: '<S11>/Constant6'
                                        */
  uint8_T Constant7_Value;             /* Computed Parameter: Constant7_Value
                                        * Referenced by: '<S11>/Constant7'
                                        */
  uint8_T Constant_Value_c;            /* Computed Parameter: Constant_Value_c
                                        * Referenced by: '<S12>/Constant'
                                        */
  uint8_T Constant1_Value_g;           /* Computed Parameter: Constant1_Value_g
                                        * Referenced by: '<S12>/Constant1'
                                        */
  uint8_T Constant2_Value_b;           /* Computed Parameter: Constant2_Value_b
                                        * Referenced by: '<S12>/Constant2'
                                        */
  uint8_T Constant3_Value_e;           /* Computed Parameter: Constant3_Value_e
                                        * Referenced by: '<S12>/Constant3'
                                        */
  uint8_T Constant4_Value_k;           /* Computed Parameter: Constant4_Value_k
                                        * Referenced by: '<S12>/Constant4'
                                        */
  uint8_T Constant5_Value_j;           /* Computed Parameter: Constant5_Value_j
                                        * Referenced by: '<S12>/Constant5'
                                        */
  uint8_T Constant6_Value_o;           /* Computed Parameter: Constant6_Value_o
                                        * Referenced by: '<S12>/Constant6'
                                        */
  uint8_T Constant7_Value_e;           /* Computed Parameter: Constant7_Value_e
                                        * Referenced by: '<S12>/Constant7'
                                        */
  test_EnabledSubsystem_cal_type test_EnabledSubsystem_d_cal;/* '<S15>/Enabled Subsystem' */
  test_EnabledSubsystem_cal_type test_EnabledSubsystem_cal;/* '<S13>/Enabled Subsystem' */
} test_cal_type;

/* Storage class 'PageSwitching' */

/* Storage class 'PageSwitching' */
extern test_cal_type test_cal_impl;
extern test_cal_type *test_cal;

#endif                                 /* RTW_HEADER_test_cal_h_ */
