/*
 * test.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "test".
 *
 * Model version              : 1.226
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Fri May 13 16:28:52 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_test_h_
#define RTW_HEADER_test_h_
#include <stddef.h>
#include <cstring>
#include <cmath>
#include <math.h>
#include <string.h>
#include <logsrv.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "verify/verifyIntrf.h"
#include "can_message.h"
#include "test_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Child system includes */
#include "test_cal.h"
#include "rt_zcfcn.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetSampleHitArray
#define rtmGetSampleHitArray(rtm)      ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmGetStepSize
#define rtmGetStepSize(rtm)            ((rtm)->Timing.stepSize)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
#define rtmGet_TimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef rtmGetTimeOfLastOutput
#define rtmGetTimeOfLastOutput(rtm)    ((rtm)->Timing.timeOfLastOutput)
#endif

/* user code (top of export header file) */
#include "can_message.h"

/* Block signals for system '<S13>/Enabled Subsystem' */
typedef struct {
  real_T motorID;       /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MP_8H;         /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MP_8L;         /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MS_8H;         /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MS_4L;         /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MC_4H;         /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MC_8L;         /* '<S18>/BusConversion_InsertedFor_Out1_at_inport_0' */
} B_EnabledSubsystem_test_T;

/* Block states (default storage) for system '<S13>/Enabled Subsystem' */
typedef struct {
  int8_T EnabledSubsystem_SubsysRanBC; /* '<S13>/Enabled Subsystem' */
} DW_EnabledSubsystem_test_T;

/* Block signals for system '<S13>/MATLAB Function2' */
typedef struct {
  real_T final_pos;                    /* '<S13>/MATLAB Function2' */
  real_T final_vel;                    /* '<S13>/MATLAB Function2' */
  real_T final_i;                      /* '<S13>/MATLAB Function2' */
} B_MATLABFunction2_test_T;

/* Block signals for system '<S14>/MATLAB Function' */
typedef struct {
  real_T P8H;                          /* '<S14>/MATLAB Function' */
  real_T V8H;                          /* '<S14>/MATLAB Function' */
  real_T KP4H;                         /* '<S14>/MATLAB Function' */
  real_T KD8H;                         /* '<S14>/MATLAB Function' */
  real_T T4H;                          /* '<S14>/MATLAB Function' */
  uint8_T P8L;                         /* '<S14>/MATLAB Function' */
  uint8_T V4L;                         /* '<S14>/MATLAB Function' */
  uint8_T KP8L;                        /* '<S14>/MATLAB Function' */
  uint8_T KD4L;                        /* '<S14>/MATLAB Function' */
  uint8_T T8L;                         /* '<S14>/MATLAB Function' */
} B_MATLABFunction_test_T;

/* Block signals (default storage) */
typedef struct {
  CAN_DATATYPE CANPack3;               /* '<S16>/CAN Pack3' */
  CAN_DATATYPE CANRead1_o2;            /* '<S15>/CAN Read1' */
  CAN_DATATYPE CANPack3_m;             /* '<S14>/CAN Pack3' */
  CAN_DATATYPE CANRead1_o2_h;          /* '<S13>/CAN Read1' */
  CAN_DATATYPE CANPack1;               /* '<S12>/CAN Pack1' */
  CAN_DATATYPE CANPack1_n;             /* '<S11>/CAN Pack1' */
  real_T Step3;                        /* '<S10>/Step3' */
  real_T Step;                         /* '<S10>/Step' */
  real_T busload;                      /* '<Root>/CAN Status' */
  real_T w;                            /* '<Root>/CAN Status' */
  real_T e;                            /* '<Root>/CAN Status' */
  real_T r1;                           /* '<S7>/Read 1' */
  real_T r2;                           /* '<S7>/Read 2' */
  real_T Clock;                        /* '<Root>/Clock' */
  real_T theta2position;               /* '<Root>/Multiply1' */
  real_T phi_actual;                   /* '<Root>/Multiply2' */
  real_T theta1position;               /* '<Root>/Multiply' */
  real_T w1;                           /* '<S7>/Write 1' */
  real_T w2;                           /* '<S7>/Write 2' */
  real_T dr;                           /* '<Root>/to_dPolar1' */
  real_T dphi;                         /* '<Root>/to_dPolar1' */
  real_T r;                            /* '<Root>/to_Polar1' */
  real_T phi;                          /* '<Root>/to_Polar1' */
  real_T motorID;                      /* '<S15>/CAN Unpack3' */
  real_T MP_8H;                        /* '<S15>/CAN Unpack3' */
  real_T MP_8L;                        /* '<S15>/CAN Unpack3' */
  real_T MS_8H;                        /* '<S15>/CAN Unpack3' */
  real_T MS_4L;                        /* '<S15>/CAN Unpack3' */
  real_T MC_4H;                        /* '<S15>/CAN Unpack3' */
  real_T MC_8L;                        /* '<S15>/CAN Unpack3' */
  real_T motorID_k;                    /* '<S13>/CAN Unpack3' */
  real_T MP_8H_o;                      /* '<S13>/CAN Unpack3' */
  real_T MP_8L_m;                      /* '<S13>/CAN Unpack3' */
  real_T MS_8H_j;                      /* '<S13>/CAN Unpack3' */
  real_T MS_4L_e;                      /* '<S13>/CAN Unpack3' */
  real_T MC_4H_d;                      /* '<S13>/CAN Unpack3' */
  real_T MC_8L_d;                      /* '<S13>/CAN Unpack3' */
  real_T tau1;                         /* '<Root>/MATLAB Function8' */
  real_T tau2;                         /* '<Root>/MATLAB Function8' */
  real_T w_c[2];                       /* '<Root>/MATLAB Function7' */
  real_T E[2];                         /* '<Root>/MATLAB Function6' */
  real_T dE[2];                        /* '<Root>/MATLAB Function6' */
  real_T JT11;                         /* '<Root>/MATLAB Function5' */
  real_T JT12;                         /* '<Root>/MATLAB Function5' */
  real_T JT21;                         /* '<Root>/MATLAB Function5' */
  real_T JT22;                         /* '<Root>/MATLAB Function5' */
  real_T turn_off;                     /* '<Root>/MATLAB Function3' */
  real_T knee_distance;                /* '<Root>/MATLAB Function3' */
  uint8_T TmpSignalConversionAtCANPack1In[8];
  uint8_T TmpSignalConversionAtCANPack1_b[8];
  boolean_T CANRead1_o1;               /* '<S15>/CAN Read1' */
  boolean_T Compare;                   /* '<S21>/Compare' */
  boolean_T CANRead1_o1_a;             /* '<S13>/CAN Read1' */
  boolean_T Compare_l;                 /* '<S17>/Compare' */
  B_MATLABFunction_test_T sf_MATLABFunction_k;/* '<S16>/MATLAB Function' */
  B_MATLABFunction2_test_T sf_MATLABFunction2_f;/* '<S15>/MATLAB Function2' */
  B_EnabledSubsystem_test_T EnabledSubsystem_d;/* '<S15>/Enabled Subsystem' */
  B_MATLABFunction_test_T sf_MATLABFunction;/* '<S14>/MATLAB Function' */
  B_MATLABFunction2_test_T sf_MATLABFunction2;/* '<S13>/MATLAB Function2' */
  B_EnabledSubsystem_test_T EnabledSubsystem;/* '<S13>/Enabled Subsystem' */
} B_test_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  void *CANsetup_PWORK;                /* '<S6>/CAN setup' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_CANSt;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_CAN_m;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_CAN_e;   /* synthesized block */

  struct {
    void *LoggedData[2];
  } Scope2_PWORK;                      /* '<Root>/Scope2' */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MATLA;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_e;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_g;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Multi;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Mul_l;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Mul_d;   /* synthesized block */

  void *CANWrite1_PWORK;               /* '<S16>/CAN Write1' */
  void *CANRead1_PWORK;                /* '<S15>/CAN Read1' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_b;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MA_gp;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_h;   /* synthesized block */

  void *CANWrite1_PWORK_g;             /* '<S14>/CAN Write1' */
  void *CANRead1_PWORK_k;              /* '<S13>/CAN Read1' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MA_bm;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_M_gpl;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MA_h1;   /* synthesized block */

  void *CANWrite1_PWORK_k;             /* '<S12>/CAN Write1' */
  void *CANWrite1_PWORK_e;             /* '<S11>/CAN Write1' */
  int32_T clockTickCounter;            /* '<S7>/Read 1' */
  int32_T clockTickCounter_i;          /* '<S7>/Read 2' */
  int32_T clockTickCounter_h;          /* '<S7>/Write 1' */
  int32_T clockTickCounter_m;          /* '<S7>/Write 2' */
  int_T CANStatus_IWORK[34];           /* '<Root>/CAN Status' */
  int_T CANPack3_ModeSignalID;         /* '<S16>/CAN Pack3' */
  int_T CANUnpack3_ModeSignalID;       /* '<S15>/CAN Unpack3' */
  int_T CANUnpack3_StatusPortID;       /* '<S15>/CAN Unpack3' */
  int_T CANPack3_ModeSignalID_h;       /* '<S14>/CAN Pack3' */
  int_T CANUnpack3_ModeSignalID_f;     /* '<S13>/CAN Unpack3' */
  int_T CANUnpack3_StatusPortID_f;     /* '<S13>/CAN Unpack3' */
  int8_T Motor3WriteTHETA1_SubsysRanBC;/* '<S7>/Motor 3 Write - THETA1' */
  int8_T Motor3ReadTHETA1_SubsysRanBC; /* '<S7>/Motor 3 Read - THETA1' */
  int8_T Motor2WriteTHETA2_SubsysRanBC;/* '<S7>/Motor 2 Write - THETA2' */
  int8_T Motor2ReadTHETA2_SubsysRanBC; /* '<S7>/Motor 2 Read - THETA2' */
  int8_T EnterMotorControlModeM3_SubsysR;/* '<S10>/Enter Motor Control Mode M3' */
  int8_T EnterMotorControlModeM2_SubsysR;/* '<S10>/Enter Motor Control Mode M2' */
  DW_EnabledSubsystem_test_T EnabledSubsystem_d;/* '<S15>/Enabled Subsystem' */
  DW_EnabledSubsystem_test_T EnabledSubsystem;/* '<S13>/Enabled Subsystem' */
} DW_test_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState Motor3WriteTHETA1_Trig_ZCE;/* '<S7>/Motor 3 Write - THETA1' */
  ZCSigState Motor3ReadTHETA1_Trig_ZCE;/* '<S7>/Motor 3 Read - THETA1' */
  ZCSigState Motor2WriteTHETA2_Trig_ZCE;/* '<S7>/Motor 2 Write - THETA2' */
  ZCSigState Motor2ReadTHETA2_Trig_ZCE;/* '<S7>/Motor 2 Read - THETA2' */
  ZCSigState EnterMotorControlModeM3_Trig_ZC;/* '<S10>/Enter Motor Control Mode M3' */
  ZCSigState EnterMotorControlModeM2_Trig_ZC;/* '<S10>/Enter Motor Control Mode M2' */
} PrevZCX_test_T;

/* Real-time Model Data Structure */
struct tag_RTM_test_T {
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[2];
    SimStruct childSFunctions[8];
    SimStruct *childSFunctionPtrs[8];
    struct _ssBlkInfo2 blkInfo2[8];
    struct _ssSFcnModelMethods2 methods2[8];
    struct _ssSFcnModelMethods3 methods3[8];
    struct _ssSFcnModelMethods4 methods4[8];
    struct _ssStatesInfo2 statesInfo2[8];
    ssPeriodicStatesInfo periodicStatesInfo[8];
    struct _ssPortInfo2 inputOutputPortInfo2[8];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn3;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn4;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn5;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[3];
      mxArray *params[3];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn6;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[3];
      struct _ssOutPortUnit outputPortUnits[3];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[3];
      uint_T attribs[34];
      mxArray *params[34];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn7;
  } NonInlinedSFcns;

  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T options;
    int_T numContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[2];
    time_T offsetTimesArray[2];
    int_T sampleTimeTaskIDArray[2];
    int_T sampleHitArray[2];
    int_T perTaskSampleHitsArray[4];
    time_T tArray[2];
  } Timing;
};

/* Block signals (default storage) */
#ifdef __cplusplus

extern "C" {

#endif

  extern B_test_T test_B;

#ifdef __cplusplus

}
#endif

/* Block states (default storage) */
extern DW_test_T test_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_test_T test_PrevZCX;

#ifdef __cplusplus

extern "C" {

#endif

  /* Model entry point functions */
  extern void test_initialize(void);
  extern void test_step(void);
  extern void test_terminate(void);

#ifdef __cplusplus

}
#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_test_T *const test_M;

#ifdef __cplusplus

}
#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'test'
 * '<S1>'   : 'test/MATLAB Function3'
 * '<S2>'   : 'test/MATLAB Function5'
 * '<S3>'   : 'test/MATLAB Function6'
 * '<S4>'   : 'test/MATLAB Function7'
 * '<S5>'   : 'test/MATLAB Function8'
 * '<S6>'   : 'test/Motor Setup'
 * '<S7>'   : 'test/Subsystem1'
 * '<S8>'   : 'test/to_Polar1'
 * '<S9>'   : 'test/to_dPolar1'
 * '<S10>'  : 'test/Motor Setup/Motor Setup'
 * '<S11>'  : 'test/Motor Setup/Motor Setup/Enter Motor Control Mode M2'
 * '<S12>'  : 'test/Motor Setup/Motor Setup/Enter Motor Control Mode M3'
 * '<S13>'  : 'test/Subsystem1/Motor 2 Read - THETA2'
 * '<S14>'  : 'test/Subsystem1/Motor 2 Write - THETA2'
 * '<S15>'  : 'test/Subsystem1/Motor 3 Read - THETA1'
 * '<S16>'  : 'test/Subsystem1/Motor 3 Write - THETA1'
 * '<S17>'  : 'test/Subsystem1/Motor 2 Read - THETA2/Compare To Constant'
 * '<S18>'  : 'test/Subsystem1/Motor 2 Read - THETA2/Enabled Subsystem'
 * '<S19>'  : 'test/Subsystem1/Motor 2 Read - THETA2/MATLAB Function2'
 * '<S20>'  : 'test/Subsystem1/Motor 2 Write - THETA2/MATLAB Function'
 * '<S21>'  : 'test/Subsystem1/Motor 3 Read - THETA1/Compare To Constant'
 * '<S22>'  : 'test/Subsystem1/Motor 3 Read - THETA1/Enabled Subsystem'
 * '<S23>'  : 'test/Subsystem1/Motor 3 Read - THETA1/MATLAB Function2'
 * '<S24>'  : 'test/Subsystem1/Motor 3 Write - THETA1/MATLAB Function'
 */
#endif                                 /* RTW_HEADER_test_h_ */
