/*
 * TestIC_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TestIC".
 *
 * Model version              : 1.158
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Tue May 10 12:41:35 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TestIC_private_h_
#define RTW_HEADER_TestIC_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "TestIC.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

extern CAN_DATATYPE CAN_DATATYPE_GROUND;
extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern void* slrtRegisterSignalToLoggingService(uintptr_t sigAddr);
extern "C" void sg_IO602_IO691_write_s(SimStruct *rts);
extern "C" void sg_IO602_IO691_read_s(SimStruct *rts);
extern "C" void sg_IO602_IO691_setup_s(SimStruct *rts);
extern "C" void sg_IO602_IO691_status_s(SimStruct *rts);
extern void TestIC_EnabledSubsystem_Init(B_EnabledSubsystem_TestIC_T *localB,
  TestI_EnabledSubsystem_cal_type *TestIC_PageSwitching_arg);
extern void TestIC_EnabledSubsystem(boolean_T rtu_Enable, real_T rtu_In1, real_T
  rtu_In1_p, real_T rtu_In1_m, real_T rtu_In1_c, real_T rtu_In1_k, real_T
  rtu_In1_o, real_T rtu_In1_i, B_EnabledSubsystem_TestIC_T *localB,
  DW_EnabledSubsystem_TestIC_T *localDW);
extern void TestIC_MATLABFunction2(real_T rtu_pos_h, real_T rtu_pos_l, real_T
  rtu_vel_h, real_T rtu_vel_l, real_T rtu_i_h, real_T rtu_i_l,
  B_MATLABFunction2_TestIC_T *localB);
extern void TestIC_MATLABFunction(real_T rtu_p_des, real_T rtu_t_ff,
  B_MATLABFunction_TestIC_T *localB);

#endif                                 /* RTW_HEADER_TestIC_private_h_ */
