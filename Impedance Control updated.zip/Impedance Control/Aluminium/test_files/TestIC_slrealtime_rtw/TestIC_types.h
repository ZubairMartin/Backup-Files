/*
 * TestIC_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TestIC".
 *
 * Model version              : 1.158
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Tue May 10 12:41:35 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TestIC_types_h_
#define RTW_HEADER_TestIC_types_h_
#include "rtwtypes.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_struct_Qf6qpjnCSySZJkQhCiHVS_
#define DEFINED_TYPEDEF_FOR_struct_Qf6qpjnCSySZJkQhCiHVS_

typedef struct {
  real_T motor_ID;
  real_T MP_8H;
  real_T MP_8L;
  real_T MS_8H;
  real_T MS_4L;
  real_T MC_4H;
  real_T MC_8L;
} struct_Qf6qpjnCSySZJkQhCiHVS;

#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_TestIC_T RT_MODEL_TestIC_T;

#endif                                 /* RTW_HEADER_TestIC_types_h_ */
