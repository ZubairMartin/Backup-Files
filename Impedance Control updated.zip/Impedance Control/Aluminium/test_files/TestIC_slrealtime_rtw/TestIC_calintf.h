#ifndef TESTIC_CALINTF_H
#define TESTIC_CALINTF_H
#include "SegmentInfo.hpp"

namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif
