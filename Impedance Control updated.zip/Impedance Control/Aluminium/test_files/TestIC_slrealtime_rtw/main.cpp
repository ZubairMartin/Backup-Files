/* Main generated for Simulink Real-Time model TestIC */
#include <ModelInfo.hpp>
#include "TestIC.h"
#include "TestIC_calintf.h"

/* Task descriptors */
slrealtime::TaskInfo task_1( 0u, std::bind(TestIC_step), slrealtime::TaskInfo::PERIODIC, 0.001, 0, 40);

/* Model descriptor */
slrealtime::ModelInfo TestIC_Info =
{
    "TestIC",
    TestIC_initialize,
    TestIC_terminate,
    []()->char const*& { return TestIC_M->errorStatus; },
    []()->unsigned char& { return TestIC_M->Timing.stopRequestedFlag; },
    { task_1 },
    slrealtime::getSegmentVector()
};

int main(int argc, char *argv[]) {
    return slrealtime::runModel(argc, argv, TestIC_Info);
}
