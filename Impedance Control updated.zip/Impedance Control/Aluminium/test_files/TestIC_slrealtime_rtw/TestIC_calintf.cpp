#include "TestIC_calintf.h"
#include "TestIC.h"
#include "TestIC_cal.h"

extern TestIC_cal_type TestIC_cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    {
      (void*)&TestIC_cal_impl, (void**)&TestIC_cal, sizeof(TestIC_cal_type), 2
    } };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime
