/*
 * TestIC.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TestIC".
 *
 * Model version              : 1.158
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Tue May 10 12:41:35 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "TestIC.h"
#include "TestIC_private.h"

/* Block signals (default storage) */
B_TestIC_T TestIC_B;

/* Block states (default storage) */
DW_TestIC_T TestIC_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_TestIC_T TestIC_PrevZCX;

/* Real-time model */
RT_MODEL_TestIC_T TestIC_M_ = RT_MODEL_TestIC_T();
RT_MODEL_TestIC_T *const TestIC_M = &TestIC_M_;

/*
 * System initialize for enable system:
 *    '<S14>/Enabled Subsystem'
 *    '<S16>/Enabled Subsystem'
 */
void TestIC_EnabledSubsystem_Init(B_EnabledSubsystem_TestIC_T *localB,
  TestI_EnabledSubsystem_cal_type *TestIC_PageSwitching_arg)
{
  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->motorID = 0.0;

  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->MP_8H = TestIC_PageSwitching_arg->Out1_Y0.MP_8H;

  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->MP_8L = TestIC_PageSwitching_arg->Out1_Y0.MP_8L;

  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->MS_8H = TestIC_PageSwitching_arg->Out1_Y0.MS_8H;

  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->MS_4L = TestIC_PageSwitching_arg->Out1_Y0.MS_4L;

  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->MC_4H = TestIC_PageSwitching_arg->Out1_Y0.MC_4H;

  /* SystemInitialize for SignalConversion generated from: '<S19>/Out1' incorporates:
   *  Outport: '<S19>/Out1'
   */
  localB->MC_8L = TestIC_PageSwitching_arg->Out1_Y0.MC_8L;
}

/*
 * Output and update for enable system:
 *    '<S14>/Enabled Subsystem'
 *    '<S16>/Enabled Subsystem'
 */
void TestIC_EnabledSubsystem(boolean_T rtu_Enable, real_T rtu_In1, real_T
  rtu_In1_p, real_T rtu_In1_m, real_T rtu_In1_c, real_T rtu_In1_k, real_T
  rtu_In1_o, real_T rtu_In1_i, B_EnabledSubsystem_TestIC_T *localB,
  DW_EnabledSubsystem_TestIC_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S14>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S19>/Enable'
   */
  if (rtu_Enable) {
    /* SignalConversion generated from: '<S19>/Out1' */
    localB->motorID = rtu_In1;

    /* SignalConversion generated from: '<S19>/Out1' */
    localB->MP_8H = rtu_In1_p;

    /* SignalConversion generated from: '<S19>/Out1' */
    localB->MP_8L = rtu_In1_m;

    /* SignalConversion generated from: '<S19>/Out1' */
    localB->MS_8H = rtu_In1_c;

    /* SignalConversion generated from: '<S19>/Out1' */
    localB->MS_4L = rtu_In1_k;

    /* SignalConversion generated from: '<S19>/Out1' */
    localB->MC_4H = rtu_In1_o;

    /* SignalConversion generated from: '<S19>/Out1' */
    localB->MC_8L = rtu_In1_i;
    localDW->EnabledSubsystem_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S14>/Enabled Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S14>/MATLAB Function2'
 *    '<S16>/MATLAB Function2'
 */
void TestIC_MATLABFunction2(real_T rtu_pos_h, real_T rtu_pos_l, real_T rtu_vel_h,
  real_T rtu_vel_l, real_T rtu_i_h, real_T rtu_i_l, B_MATLABFunction2_TestIC_T
  *localB)
{
  localB->final_pos = (static_cast<real_T>(static_cast<uint64_T>
    (static_cast<real_T>(static_cast<uint64_T>(rtu_pos_h) << 8)) |
    static_cast<uint64_T>(rtu_pos_l)) * 25.0 / 65535.0 - 12.5) * 4.0 *
    3.1415926535897931 / 12.5;
  localB->final_vel = static_cast<real_T>(static_cast<uint64_T>
    (static_cast<real_T>(static_cast<uint64_T>(rtu_vel_h) << 4)) |
    static_cast<uint64_T>(rtu_vel_l)) * 46.48 / 4095.0 - 23.24;
  localB->final_i = static_cast<real_T>(static_cast<uint64_T>(static_cast<real_T>
    (static_cast<uint64_T>(rtu_i_h) << 8)) | static_cast<uint64_T>(rtu_i_l)) *
    108.0 / 4095.0 - 54.0;
}

/*
 * Output and update for atomic system:
 *    '<S15>/MATLAB Function'
 *    '<S17>/MATLAB Function'
 */
void TestIC_MATLABFunction(real_T rtu_p_des, real_T rtu_t_ff,
  B_MATLABFunction_TestIC_T *localB)
{
  real_T kd_int;
  real_T kp_int;
  real_T p_int;
  real_T t_int;
  real_T v_int;
  t_int = rtu_p_des;
  if (-12.5 < t_int) {
    p_int = t_int;
  } else {
    p_int = -12.5;
  }

  t_int = p_int;
  if (t_int > 12.5) {
    p_int = 12.5;
  }

  t_int = rtu_p_des;
  if (-50.0 < t_int) {
    v_int = t_int;
  } else {
    v_int = -50.0;
  }

  t_int = v_int;
  if (t_int > 50.0) {
    v_int = 50.0;
  }

  t_int = rtu_p_des;
  if (0.0 < t_int) {
    kp_int = t_int;
  } else {
    kp_int = 0.0;
  }

  t_int = kp_int;
  if (t_int > 500.0) {
    kp_int = 500.0;
  }

  t_int = rtu_p_des;
  if (0.0 < t_int) {
    kd_int = t_int;
  } else {
    kd_int = 0.0;
  }

  t_int = kd_int;
  if (t_int > 5.0) {
    kd_int = 5.0;
  }

  t_int = rtu_t_ff;
  if (!(-65.0 < t_int)) {
    t_int = -65.0;
  }

  if (t_int > 65.0) {
    t_int = 65.0;
  }

  p_int = (p_int - -12.5) * 2621.44;
  v_int = (v_int - -50.0) * 40.96;
  kp_int *= 8.192;
  kd_int *= 819.2;
  t_int = (t_int - -65.0) * 31.507692307692309;
  localB->P8H = static_cast<real_T>(static_cast<uint64_T>(p_int) >> 8);
  localB->P8L = static_cast<uint8_T>(p_int);
  localB->V8H = static_cast<real_T>(static_cast<uint64_T>(v_int) >> 4);
  localB->V4L = static_cast<uint8_T>(static_cast<uint8_T>(v_int) & 15);
  localB->KP4H = static_cast<real_T>(static_cast<uint64_T>(kp_int) >> 8);
  localB->KP8L = static_cast<uint8_T>(kp_int);
  localB->KD8H = static_cast<real_T>(static_cast<uint64_T>(kd_int) >> 4);
  localB->KD4L = static_cast<uint8_T>(static_cast<uint8_T>(kd_int) & 15);
  localB->T4H = static_cast<real_T>(static_cast<uint64_T>(t_int) >> 8);
  localB->T8L = static_cast<uint8_T>(t_int);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T tmp;
  int32_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u1 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u0 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(tmp_0), static_cast<real_T>(tmp));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

/* Model step function */
void TestIC_step(void)
{
  real_T ab_a;
  real_T ac_a;
  real_T bc_a;
  real_T cc_a;
  real_T cf_a;
  real_T db_a;
  real_T dc_a;
  real_T ec_a;
  real_T fc_a;
  real_T gb_a;
  real_T hb_a;
  real_T ib_a;
  real_T ic_a;
  real_T jb_a;
  real_T kb_a;
  real_T lb_a;
  real_T mb_a;
  real_T nb_a;
  real_T ob_a;
  real_T pb_a;
  real_T qb_a;
  real_T rb_a;
  real_T sb_a;
  real_T t10;
  real_T t11;
  real_T t12;
  real_T t13;
  real_T t18;
  real_T t19;
  real_T t20;
  real_T t21;
  real_T t22;
  real_T t23;
  real_T t24;
  real_T t25;
  real_T t35_im;
  real_T t35_re;
  real_T t37;
  real_T t39;
  real_T t47;
  real_T t6;
  real_T t7;
  real_T t8;
  real_T t9;
  real_T tb_a;
  real_T u;
  real_T ub_a;
  real_T v_a;
  real_T vb_a;
  real_T ve_a;
  real_T w_a;
  real_T wb_a;
  real_T x_a;
  real_T xb_a;
  real_T y;
  real_T y_0;
  real_T y_1;
  real_T y_2;
  real_T y_3;
  real_T y_4;
  real_T y_5;
  real_T y_a;
  real_T yb_a;
  real_T ye_a;
  ZCEventType zcEvent;

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.EnterMotorControlModeM2_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.EnterMotorControlModeM3_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.SetOriginM2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.SetOriginM3_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.EnabledSubsystem.EnabledSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.Motor2ReadTHETA2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.Motor2WriteTHETA2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.Motor3ReadTHETA1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestIC_DW.Motor3WriteTHETA1_SubsysRanBC);

  /* S-Function (sg_IO602_IO691_setup_s): '<S7>/CAN setup' */

  /* Level2 S-Function Block: '<S7>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[8];
    sfcnOutputs(rts,0);
  }

  /* Step: '<S9>/Step3' */
  t19 = TestIC_M->Timing.t[0];
  if (t19 < TestIC_cal->Step3_Time) {
    /* Step: '<S9>/Step3' */
    TestIC_B.Step3 = TestIC_cal->Step3_Y0;
  } else {
    /* Step: '<S9>/Step3' */
    TestIC_B.Step3 = TestIC_cal->Step3_YFinal;
  }

  /* End of Step: '<S9>/Step3' */

  /* Outputs for Triggered SubSystem: '<S9>/Enter Motor Control Mode M2' incorporates:
   *  TriggerPort: '<S10>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestIC_PrevZCX.EnterMotorControlModeM2_Trig_ZC,
                     (TestIC_B.Step3));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S10>/CAN Pack1' incorporates:
     *  Constant: '<S10>/Constant'
     *  Constant: '<S10>/Constant1'
     *  Constant: '<S10>/Constant2'
     *  Constant: '<S10>/Constant3'
     *  Constant: '<S10>/Constant4'
     *  Constant: '<S10>/Constant5'
     *  Constant: '<S10>/Constant6'
     *  Constant: '<S10>/Constant7'
     */
    TestIC_B.TmpSignalConversionAtCANPac_bhh[0] = TestIC_cal->Constant_Value;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[1] = TestIC_cal->Constant1_Value;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[2] = TestIC_cal->Constant2_Value_d;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[3] = TestIC_cal->Constant3_Value;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[4] = TestIC_cal->Constant4_Value;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[5] = TestIC_cal->Constant5_Value;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[6] = TestIC_cal->Constant6_Value_b;
    TestIC_B.TmpSignalConversionAtCANPac_bhh[7] = TestIC_cal->Constant7_Value;

    /* S-Function (scanpack): '<S10>/CAN Pack1' */
    /* S-Function (scanpack): '<S10>/CAN Pack1' */
    TestIC_B.CANPack1_n.ID = 2U;
    TestIC_B.CANPack1_n.Length = 8U;
    TestIC_B.CANPack1_n.Extended = 0U;
    TestIC_B.CANPack1_n.Remote = 0;
    TestIC_B.CANPack1_n.Data[0] = 0;
    TestIC_B.CANPack1_n.Data[1] = 0;
    TestIC_B.CANPack1_n.Data[2] = 0;
    TestIC_B.CANPack1_n.Data[3] = 0;
    TestIC_B.CANPack1_n.Data[4] = 0;
    TestIC_B.CANPack1_n.Data[5] = 0;
    TestIC_B.CANPack1_n.Data[6] = 0;
    TestIC_B.CANPack1_n.Data[7] = 0;

    {
      (void) std::memcpy((TestIC_B.CANPack1_n.Data),
                         &TestIC_B.TmpSignalConversionAtCANPac_bhh[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S10>/CAN Write1' */

    /* Level2 S-Function Block: '<S10>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[0];
      sfcnOutputs(rts,0);
    }

    TestIC_DW.EnterMotorControlModeM2_SubsysR = 4;
  }

  /* End of Outputs for SubSystem: '<S9>/Enter Motor Control Mode M2' */

  /* Step: '<S9>/Step' */
  t19 = TestIC_M->Timing.t[0];
  if (t19 < TestIC_cal->Step_Time) {
    /* Step: '<S9>/Step' */
    TestIC_B.Step = TestIC_cal->Step_Y0;
  } else {
    /* Step: '<S9>/Step' */
    TestIC_B.Step = TestIC_cal->Step_YFinal;
  }

  /* End of Step: '<S9>/Step' */

  /* Outputs for Triggered SubSystem: '<S9>/Enter Motor Control Mode M3' incorporates:
   *  TriggerPort: '<S11>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestIC_PrevZCX.EnterMotorControlModeM3_Trig_ZC,
                     (TestIC_B.Step));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S11>/CAN Pack1' incorporates:
     *  Constant: '<S11>/Constant'
     *  Constant: '<S11>/Constant1'
     *  Constant: '<S11>/Constant2'
     *  Constant: '<S11>/Constant3'
     *  Constant: '<S11>/Constant4'
     *  Constant: '<S11>/Constant5'
     *  Constant: '<S11>/Constant6'
     *  Constant: '<S11>/Constant7'
     */
    TestIC_B.TmpSignalConversionAtCANPack_bh[0] = TestIC_cal->Constant_Value_c;
    TestIC_B.TmpSignalConversionAtCANPack_bh[1] = TestIC_cal->Constant1_Value_g;
    TestIC_B.TmpSignalConversionAtCANPack_bh[2] = TestIC_cal->Constant2_Value_b;
    TestIC_B.TmpSignalConversionAtCANPack_bh[3] = TestIC_cal->Constant3_Value_e;
    TestIC_B.TmpSignalConversionAtCANPack_bh[4] = TestIC_cal->Constant4_Value_k;
    TestIC_B.TmpSignalConversionAtCANPack_bh[5] = TestIC_cal->Constant5_Value_j;
    TestIC_B.TmpSignalConversionAtCANPack_bh[6] = TestIC_cal->Constant6_Value_o;
    TestIC_B.TmpSignalConversionAtCANPack_bh[7] = TestIC_cal->Constant7_Value_e;

    /* S-Function (scanpack): '<S11>/CAN Pack1' */
    /* S-Function (scanpack): '<S11>/CAN Pack1' */
    TestIC_B.CANPack1_i.ID = 3U;
    TestIC_B.CANPack1_i.Length = 8U;
    TestIC_B.CANPack1_i.Extended = 0U;
    TestIC_B.CANPack1_i.Remote = 0;
    TestIC_B.CANPack1_i.Data[0] = 0;
    TestIC_B.CANPack1_i.Data[1] = 0;
    TestIC_B.CANPack1_i.Data[2] = 0;
    TestIC_B.CANPack1_i.Data[3] = 0;
    TestIC_B.CANPack1_i.Data[4] = 0;
    TestIC_B.CANPack1_i.Data[5] = 0;
    TestIC_B.CANPack1_i.Data[6] = 0;
    TestIC_B.CANPack1_i.Data[7] = 0;

    {
      (void) std::memcpy((TestIC_B.CANPack1_i.Data),
                         &TestIC_B.TmpSignalConversionAtCANPack_bh[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S11>/CAN Write1' */

    /* Level2 S-Function Block: '<S11>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[1];
      sfcnOutputs(rts,0);
    }

    TestIC_DW.EnterMotorControlModeM3_SubsysR = 4;
  }

  /* End of Outputs for SubSystem: '<S9>/Enter Motor Control Mode M3' */

  /* Step: '<S9>/Step4' */
  t19 = TestIC_M->Timing.t[0];
  if (t19 < TestIC_cal->Step4_Time) {
    /* Step: '<S9>/Step4' */
    TestIC_B.Step4 = TestIC_cal->Step4_Y0;
  } else {
    /* Step: '<S9>/Step4' */
    TestIC_B.Step4 = TestIC_cal->Step4_YFinal;
  }

  /* End of Step: '<S9>/Step4' */

  /* Outputs for Triggered SubSystem: '<S9>/Set Origin M2' incorporates:
   *  TriggerPort: '<S12>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&TestIC_PrevZCX.SetOriginM2_Trig_ZCE,
                     (TestIC_B.Step4));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S12>/CAN Pack1' incorporates:
     *  Constant: '<S12>/Constant'
     *  Constant: '<S12>/Constant1'
     *  Constant: '<S12>/Constant2'
     *  Constant: '<S12>/Constant3'
     *  Constant: '<S12>/Constant4'
     *  Constant: '<S12>/Constant5'
     *  Constant: '<S12>/Constant6'
     *  Constant: '<S12>/Constant7'
     */
    TestIC_B.TmpSignalConversionAtCANPack1_b[0] = TestIC_cal->Constant_Value_d;
    TestIC_B.TmpSignalConversionAtCANPack1_b[1] = TestIC_cal->Constant1_Value_p;
    TestIC_B.TmpSignalConversionAtCANPack1_b[2] = TestIC_cal->Constant2_Value_c;
    TestIC_B.TmpSignalConversionAtCANPack1_b[3] = TestIC_cal->Constant3_Value_l;
    TestIC_B.TmpSignalConversionAtCANPack1_b[4] = TestIC_cal->Constant4_Value_o;
    TestIC_B.TmpSignalConversionAtCANPack1_b[5] = TestIC_cal->Constant5_Value_a;
    TestIC_B.TmpSignalConversionAtCANPack1_b[6] = TestIC_cal->Constant6_Value_i;
    TestIC_B.TmpSignalConversionAtCANPack1_b[7] = TestIC_cal->Constant7_Value_k;

    /* S-Function (scanpack): '<S12>/CAN Pack1' */
    /* S-Function (scanpack): '<S12>/CAN Pack1' */
    TestIC_B.CANPack1_p.ID = 2U;
    TestIC_B.CANPack1_p.Length = 8U;
    TestIC_B.CANPack1_p.Extended = 0U;
    TestIC_B.CANPack1_p.Remote = 0;
    TestIC_B.CANPack1_p.Data[0] = 0;
    TestIC_B.CANPack1_p.Data[1] = 0;
    TestIC_B.CANPack1_p.Data[2] = 0;
    TestIC_B.CANPack1_p.Data[3] = 0;
    TestIC_B.CANPack1_p.Data[4] = 0;
    TestIC_B.CANPack1_p.Data[5] = 0;
    TestIC_B.CANPack1_p.Data[6] = 0;
    TestIC_B.CANPack1_p.Data[7] = 0;

    {
      (void) std::memcpy((TestIC_B.CANPack1_p.Data),
                         &TestIC_B.TmpSignalConversionAtCANPack1_b[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S12>/CAN Write1' */

    /* Level2 S-Function Block: '<S12>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[2];
      sfcnOutputs(rts,0);
    }

    TestIC_DW.SetOriginM2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S9>/Set Origin M2' */

  /* Step: '<S9>/Step1' */
  t19 = TestIC_M->Timing.t[0];
  if (t19 < TestIC_cal->Step1_Time) {
    /* Step: '<S9>/Step1' */
    TestIC_B.Step1 = TestIC_cal->Step1_Y0;
  } else {
    /* Step: '<S9>/Step1' */
    TestIC_B.Step1 = TestIC_cal->Step1_YFinal;
  }

  /* End of Step: '<S9>/Step1' */

  /* Outputs for Triggered SubSystem: '<S9>/Set Origin M3' incorporates:
   *  TriggerPort: '<S13>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&TestIC_PrevZCX.SetOriginM3_Trig_ZCE,
                     (TestIC_B.Step1));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S13>/CAN Pack1' incorporates:
     *  Constant: '<S13>/Constant'
     *  Constant: '<S13>/Constant1'
     *  Constant: '<S13>/Constant2'
     *  Constant: '<S13>/Constant3'
     *  Constant: '<S13>/Constant4'
     *  Constant: '<S13>/Constant5'
     *  Constant: '<S13>/Constant6'
     *  Constant: '<S13>/Constant7'
     */
    TestIC_B.TmpSignalConversionAtCANPack1In[0] = TestIC_cal->Constant_Value_n;
    TestIC_B.TmpSignalConversionAtCANPack1In[1] = TestIC_cal->Constant1_Value_j;
    TestIC_B.TmpSignalConversionAtCANPack1In[2] = TestIC_cal->Constant2_Value_j;
    TestIC_B.TmpSignalConversionAtCANPack1In[3] = TestIC_cal->Constant3_Value_f;
    TestIC_B.TmpSignalConversionAtCANPack1In[4] = TestIC_cal->Constant4_Value_c;
    TestIC_B.TmpSignalConversionAtCANPack1In[5] = TestIC_cal->Constant5_Value_g;
    TestIC_B.TmpSignalConversionAtCANPack1In[6] = TestIC_cal->Constant6_Value_od;
    TestIC_B.TmpSignalConversionAtCANPack1In[7] = TestIC_cal->Constant7_Value_n;

    /* S-Function (scanpack): '<S13>/CAN Pack1' */
    /* S-Function (scanpack): '<S13>/CAN Pack1' */
    TestIC_B.CANPack1.ID = 3U;
    TestIC_B.CANPack1.Length = 8U;
    TestIC_B.CANPack1.Extended = 0U;
    TestIC_B.CANPack1.Remote = 0;
    TestIC_B.CANPack1.Data[0] = 0;
    TestIC_B.CANPack1.Data[1] = 0;
    TestIC_B.CANPack1.Data[2] = 0;
    TestIC_B.CANPack1.Data[3] = 0;
    TestIC_B.CANPack1.Data[4] = 0;
    TestIC_B.CANPack1.Data[5] = 0;
    TestIC_B.CANPack1.Data[6] = 0;
    TestIC_B.CANPack1.Data[7] = 0;

    {
      (void) std::memcpy((TestIC_B.CANPack1.Data),
                         &TestIC_B.TmpSignalConversionAtCANPack1In[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S13>/CAN Write1' */

    /* Level2 S-Function Block: '<S13>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[3];
      sfcnOutputs(rts,0);
    }

    TestIC_DW.SetOriginM3_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S9>/Set Origin M3' */

  /* S-Function (sg_IO602_IO691_status_s): '<Root>/CAN Status' */

  /* Level2 S-Function Block: '<Root>/CAN Status' (sg_IO602_IO691_status_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[9];
    sfcnOutputs(rts,0);
  }

  /* DiscretePulseGenerator: '<S8>/Read 1' */
  TestIC_B.r1 = (TestIC_DW.clockTickCounter < TestIC_cal->Read1_Duty) &&
    (TestIC_DW.clockTickCounter >= 0) ? TestIC_cal->Read1_Amp : 0.0;

  /* DiscretePulseGenerator: '<S8>/Read 1' */
  if (TestIC_DW.clockTickCounter >= TestIC_cal->Read1_Period - 1.0) {
    TestIC_DW.clockTickCounter = 0;
  } else {
    TestIC_DW.clockTickCounter++;
  }

  /* Outputs for Triggered SubSystem: '<S8>/Motor 3 Read - THETA1' incorporates:
   *  TriggerPort: '<S16>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestIC_PrevZCX.Motor3ReadTHETA1_Trig_ZCE,
                     (TestIC_B.r1));
  if (zcEvent != NO_ZCEVENT) {
    /* S-Function (sg_IO602_IO691_read_s): '<S16>/CAN Read1' */

    /* Level2 S-Function Block: '<S16>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[6];
      sfcnOutputs(rts,0);
    }

    /* S-Function (scanunpack): '<S16>/CAN Unpack3' */
    {
      /* S-Function (scanunpack): '<S16>/CAN Unpack3' */
      if ((8 == TestIC_B.CANRead1_o2.Length) && (TestIC_B.CANRead1_o2.ID !=
           INVALID_CAN_ID) ) {
        if ((0 == TestIC_B.CANRead1_o2.ID) && (0U ==
             TestIC_B.CANRead1_o2.Extended) ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)(TestIC_B.CANRead1_o2.Data
                      [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.motorID = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)(TestIC_B.CANRead1_o2.Data
                      [1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MP_8H = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 16
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)(TestIC_B.CANRead1_o2.Data
                      [2]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MP_8L = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)(TestIC_B.CANRead1_o2.Data
                      [3]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MS_8H = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 36
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                      (TestIC_B.CANRead1_o2.Data[4]) & (uint8_T)(0xF0U)) >> 4);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MS_4L = result;
              }
            }

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 32
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)
                      (TestIC_B.CANRead1_o2.Data[4]) & (uint8_T)(0xFU));
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MC_4H = result;
              }
            }

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 40
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)(TestIC_B.CANRead1_o2.Data
                      [5]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MC_8L = result;
              }
            }
          }
        }
      }
    }

    /* RelationalOperator: '<S22>/Compare' incorporates:
     *  Constant: '<S22>/Constant'
     */
    TestIC_B.Compare = (TestIC_B.motorID ==
                        TestIC_cal->CompareToConstant_const_b);

    /* Outputs for Enabled SubSystem: '<S16>/Enabled Subsystem' */
    TestIC_EnabledSubsystem(TestIC_B.Compare, TestIC_B.motorID, TestIC_B.MP_8H,
      TestIC_B.MP_8L, TestIC_B.MS_8H, TestIC_B.MS_4L, TestIC_B.MC_4H,
      TestIC_B.MC_8L, &TestIC_B.EnabledSubsystem_d,
      &TestIC_DW.EnabledSubsystem_d);

    /* End of Outputs for SubSystem: '<S16>/Enabled Subsystem' */

    /* MATLAB Function: '<S16>/MATLAB Function2' */
    TestIC_MATLABFunction2(TestIC_B.EnabledSubsystem_d.MP_8H,
      TestIC_B.EnabledSubsystem_d.MP_8L, TestIC_B.EnabledSubsystem_d.MS_8H,
      TestIC_B.EnabledSubsystem_d.MS_4L, TestIC_B.EnabledSubsystem_d.MC_4H,
      TestIC_B.EnabledSubsystem_d.MC_8L, &TestIC_B.sf_MATLABFunction2_f);
    TestIC_DW.Motor3ReadTHETA1_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S8>/Motor 3 Read - THETA1' */

  /* DiscretePulseGenerator: '<S8>/Read 2' */
  TestIC_B.r2 = (TestIC_DW.clockTickCounter_i < TestIC_cal->Read2_Duty) &&
    (TestIC_DW.clockTickCounter_i >= 0) ? TestIC_cal->Read2_Amp : 0.0;

  /* DiscretePulseGenerator: '<S8>/Read 2' */
  if (TestIC_DW.clockTickCounter_i >= TestIC_cal->Read2_Period - 1.0) {
    TestIC_DW.clockTickCounter_i = 0;
  } else {
    TestIC_DW.clockTickCounter_i++;
  }

  /* Outputs for Triggered SubSystem: '<S8>/Motor 2 Read - THETA2' incorporates:
   *  TriggerPort: '<S14>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestIC_PrevZCX.Motor2ReadTHETA2_Trig_ZCE,
                     (TestIC_B.r2));
  if (zcEvent != NO_ZCEVENT) {
    /* S-Function (sg_IO602_IO691_read_s): '<S14>/CAN Read1' */

    /* Level2 S-Function Block: '<S14>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[4];
      sfcnOutputs(rts,0);
    }

    /* S-Function (scanunpack): '<S14>/CAN Unpack3' */
    {
      /* S-Function (scanunpack): '<S14>/CAN Unpack3' */
      if ((8 == TestIC_B.CANRead1_o2_h.Length) && (TestIC_B.CANRead1_o2_h.ID !=
           INVALID_CAN_ID) ) {
        if ((0 == TestIC_B.CANRead1_o2_h.ID) && (0U ==
             TestIC_B.CANRead1_o2_h.Extended) ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.motorID_k = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MP_8H_o = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 16
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[2]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MP_8L_m = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[3]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MS_8H_j = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 36
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[4]) & (uint8_T)(0xF0U)) >> 4);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MS_4L_e = result;
              }
            }

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 32
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[4]) & (uint8_T)(0xFU));
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MC_4H_d = result;
              }
            }

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 40
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestIC_B.CANRead1_o2_h.Data[5]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestIC_B.MC_8L_d = result;
              }
            }
          }
        }
      }
    }

    /* RelationalOperator: '<S18>/Compare' incorporates:
     *  Constant: '<S18>/Constant'
     */
    TestIC_B.Compare_l = (TestIC_B.motorID_k ==
                          TestIC_cal->CompareToConstant_const);

    /* Outputs for Enabled SubSystem: '<S14>/Enabled Subsystem' */
    TestIC_EnabledSubsystem(TestIC_B.Compare_l, TestIC_B.motorID_k,
      TestIC_B.MP_8H_o, TestIC_B.MP_8L_m, TestIC_B.MS_8H_j, TestIC_B.MS_4L_e,
      TestIC_B.MC_4H_d, TestIC_B.MC_8L_d, &TestIC_B.EnabledSubsystem,
      &TestIC_DW.EnabledSubsystem);

    /* End of Outputs for SubSystem: '<S14>/Enabled Subsystem' */

    /* MATLAB Function: '<S14>/MATLAB Function2' */
    TestIC_MATLABFunction2(TestIC_B.EnabledSubsystem.MP_8H,
      TestIC_B.EnabledSubsystem.MP_8L, TestIC_B.EnabledSubsystem.MS_8H,
      TestIC_B.EnabledSubsystem.MS_4L, TestIC_B.EnabledSubsystem.MC_4H,
      TestIC_B.EnabledSubsystem.MC_8L, &TestIC_B.sf_MATLABFunction2_o);
    TestIC_DW.Motor2ReadTHETA2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S8>/Motor 2 Read - THETA2' */

  /* MATLAB Function: '<Root>/Conversion' */
  t19 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t20 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t11 = (std::cos((rt_atan2d_snf(std::sin
            (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
            -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
             1.5707963267948966) * 0.18, std::abs((std::cos
              (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
              0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt(t19 * t19 + t20 *
             t20) * 1.6666666666666667)) + 0.066869026139001891) *
         -0.33672954507613351 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos
          + 1.5707963267948966) * 0.18) + 0.06;
  t10 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t8 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                 (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                 0.18) + 0.12);
  t9 = std::sin((rt_atan2d_snf(std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos
    - 1.5707963267948966) * -0.18 - std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18, std::
    abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
         0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt(t10 * t10 + t8 *
    t8) * 1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 +
    std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
    0.18;
  TestIC_B.r = t11 * t11 + t9 * t9;
  TestIC_B.r = std::sqrt(TestIC_B.r);
  t12 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t13 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t18 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t21 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t35_re = (((std::cos((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t12 * t12 + t13 * t13) *
    1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351 + std::
              sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t18 * t18 + t21 * t21) *
    1.6666666666666667)) + 0.066869026139001891) * 0.0) + std::cos
             (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
             0.18) + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
             1.5707963267948966) * 0.0) + 0.06;
  t35_im = std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t18 * t18 + t21 * t21) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18;
  TestIC_B.phi = 1.5707963267948966 - rt_atan2d_snf(t35_im, t35_re);

  /* MATLAB Function: '<Root>/Conversion1' */
  t19 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t20 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t11 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t10 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t8 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t9 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                 (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                 0.18) + 0.12);
  t12 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t13 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t18 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t21 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t6 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t7 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                 (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                 0.18) + 0.12);
  t22 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t23 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t24 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t25 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t37 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t39 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t47 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t35_re = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                     (TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18) + 0.12);
  t35_im = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966)
    * 0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18;
  v_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  w_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  x_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  y_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ab_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  y_a = (std::cos((rt_atan2d_snf(std::sin
            (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
            -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
             1.5707963267948966) * 0.18, std::abs((std::cos
              (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
              0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt(y_a * y_a + ab_a *
             ab_a) * 1.6666666666666667)) + 0.066869026139001891) *
         -0.33672954507613351 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos
          + 1.5707963267948966) * 0.18) + 0.06;
  ab_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  db_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ab_a = std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(ab_a * ab_a + db_a * db_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18;
  db_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  gb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  hb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ib_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  jb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  kb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  lb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  mb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  nb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ob_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  pb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  qb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  rb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  sb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  tb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ub_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  vb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  wb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  xb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  yb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ac_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  bc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  cc_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  dc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ec_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  fc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ec_a = (std::cos((rt_atan2d_snf(std::sin
             (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
             -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
              1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
              0.12)) + std::acos(std::sqrt(ec_a * ec_a + fc_a * fc_a) *
             1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351
          + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.06;
  fc_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ic_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  fc_a = std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(fc_a * fc_a + ic_a * ic_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18;
  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y = -1.0;
  } else if (u > 0.0) {
    y = 1.0;
  } else if (u == 0.0) {
    y = 0.0;
  } else {
    y = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_0 = -1.0;
  } else if (u > 0.0) {
    y_0 = 1.0;
  } else if (u == 0.0) {
    y_0 = 0.0;
  } else {
    y_0 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_1 = -1.0;
  } else if (u > 0.0) {
    y_1 = 1.0;
  } else if (u == 0.0) {
    y_1 = 0.0;
  } else {
    y_1 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_2 = -1.0;
  } else if (u > 0.0) {
    y_2 = 1.0;
  } else if (u == 0.0) {
    y_2 = 0.0;
  } else {
    y_2 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_3 = -1.0;
  } else if (u > 0.0) {
    y_3 = 1.0;
  } else if (u == 0.0) {
    y_3 = 0.0;
  } else {
    y_3 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_4 = -1.0;
  } else if (u > 0.0) {
    y_4 = 1.0;
  } else if (u == 0.0) {
    y_4 = 0.0;
  } else {
    y_4 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_5 = -1.0;
  } else if (u > 0.0) {
    y_5 = 1.0;
  } else if (u == 0.0) {
    y_5 = 0.0;
  } else {
    y_5 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    u = -1.0;
  } else if (u > 0.0) {
    u = 1.0;
  } else if (u == 0.0) {
    u = 0.0;
  } else {
    u = (rtNaN);
  }

  TestIC_B.dr = ((std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18 - (((std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
    0.36 - std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                     (TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18) + 0.12) * y * std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.36) *
    (1.0 / std::sqrt(t8 * t8 + t9 * t9)) / std::sqrt((t12 * t12 *
    -2.7777777777777777 - t13 * t13 * 2.7777777777777777) + 1.0) *
    0.83333333333333337 + (1.0 / (t21 * t21) * y_0 * std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * (std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18 / std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) + 0.12)) * (t18 * t18) / (t6
    * t6 + t7 * t7)) * std::cos((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t11 * t11 + t10 * t10) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351) * (std::
    sin((rt_atan2d_snf(std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * -0.18 - std::sin
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12)) + std::acos(std::sqrt(t19 * t19 + t20 * t20) * 1.6666666666666667)) +
        0.066869026139001891) * 0.33672954507613351 + std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) * 2.0
                 - ((((std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::sin
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) * std::cos
                      (TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.36 - std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12) * y_1 * std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.36) * (1.0 / std::sqrt(t24 * t24 + t25 * t25)) / std::
                     sqrt((t37 * t37 * -2.7777777777777777 - t39 * t39 *
    2.7777777777777777) + 1.0) * 0.83333333333333337 + (1.0 / (t35_re * t35_re) *
    y_2 * std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * (std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) * 0.18 + std::cos
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18 / std::
    abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
         0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) * (t47 * t47) / (t35_im * t35_im + v_a *
    v_a)) * std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t22 * t22 + t23 * t23) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
                    sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) * ((std::cos((rt_atan2d_snf
    (std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
     -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12)) + std::acos(std::sqrt(w_a * w_a + x_a * x_a) * 1.6666666666666667)) +
    0.066869026139001891) * -0.33672954507613351 + std::cos
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.06) * 2.0) * TestIC_B.sf_MATLABFunction2_o.final_vel / std::sqrt(y_a * y_a
    + ab_a * ab_a) / 2.0 - ((((std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos
    - 1.5707963267948966) * 0.18 + std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) * std::
    cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.36 -
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12) * y_3 * std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.36) *
    (1.0 / std::sqrt(hb_a * hb_a + ib_a * ib_a)) / std::sqrt((jb_a * jb_a *
    -2.7777777777777777 - kb_a * kb_a * 2.7777777777777777) + 1.0) *
    0.83333333333333337 + (1.0 / (mb_a * mb_a) * y_4 * std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * (std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    0.18 + std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966)
    * 0.18 / std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) + 0.12)) * (lb_a * lb_a) /
    (nb_a * nb_a + ob_a * ob_a)) * std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(db_a * db_a + gb_a * gb_a) *
    1.6666666666666667)) + 0.066869026139001891) * ((std::cos((rt_atan2d_snf(std::
    sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 -
    std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
    0.18, std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                    (TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt
    (pb_a * pb_a + qb_a * qb_a) * 1.6666666666666667)) + 0.066869026139001891) *
    -0.33672954507613351 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.06) * 0.673459090152267 + (((std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.36 - std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                     (TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18) + 0.12) * y_5 * std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.36) *
    (1.0 / std::sqrt(vb_a * vb_a + wb_a * wb_a)) / std::sqrt((xb_a * xb_a *
    -2.7777777777777777 - yb_a * yb_a * 2.7777777777777777) + 1.0) *
    0.83333333333333337 + (1.0 / (bc_a * bc_a) * u * std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * (std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    0.18 + std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966)
    * 0.18 / std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) + 0.12)) * (ac_a * ac_a) /
    (cc_a * cc_a + dc_a * dc_a)) * ((std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(tb_a * tb_a + ub_a * ub_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    std::cos((rt_atan2d_snf(std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * -0.18 - std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18, std::
    abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
         0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt(rb_a * rb_a +
    sb_a * sb_a) * 1.6666666666666667)) + 0.066869026139001891)) *
    0.673459090152267) * TestIC_B.sf_MATLABFunction2_f.final_vel / std::sqrt
    (ec_a * ec_a + fc_a * fc_a) / 2.0;
  t19 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t20 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t11 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t10 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t8 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t9 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                 (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                 0.18) + 0.12);
  t12 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t13 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t18 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t21 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t6 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t7 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                 (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                 0.18) + 0.12);
  t22 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t23 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t24 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t25 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t37 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t39 = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  t47 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  t35_re = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                     (TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18) + 0.12);
  t35_im = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                     (TestIC_B.sf_MATLABFunction2_o.final_pos +
                      1.5707963267948966) * 0.18) + 0.12);
  v_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  w_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  x_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                  (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                  * 0.18) + 0.12);
  y_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ab_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  y_a = (std::cos((rt_atan2d_snf(std::sin
            (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
            -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
             1.5707963267948966) * 0.18, std::abs((std::cos
              (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
              0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt(y_a * y_a + ab_a *
             ab_a) * 1.6666666666666667)) + 0.066869026139001891) *
         -0.33672954507613351 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos
          + 1.5707963267948966) * 0.18) + 0.06;
  ab_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  db_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ab_a = (std::cos((rt_atan2d_snf(std::sin
             (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
             -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
              1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
              0.12)) + std::acos(std::sqrt(ab_a * ab_a + db_a * db_a) *
             1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351
          + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.06;
  db_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  gb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  db_a = (std::cos((rt_atan2d_snf(std::sin
             (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
             -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
              1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
              0.12)) + std::acos(std::sqrt(db_a * db_a + gb_a * gb_a) *
             1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351
          + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.06;
  gb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  hb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  gb_a = std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(gb_a * gb_a + hb_a * hb_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18;
  hb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ib_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  jb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  kb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  lb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  mb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  nb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ob_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  pb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  qb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  rb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  sb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  tb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ub_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  vb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  wb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  xb_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  yb_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ac_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  bc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  cc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  dc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ec_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  fc_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ic_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ve_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ic_a = (std::cos((rt_atan2d_snf(std::sin
             (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
             -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
              1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
              0.12)) + std::acos(std::sqrt(ic_a * ic_a + ve_a * ve_a) *
             1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351
          + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.06;
  ve_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  ye_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ve_a = (std::cos((rt_atan2d_snf(std::sin
             (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
             -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
              1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
              0.12)) + std::acos(std::sqrt(ve_a * ve_a + ye_a * ye_a) *
             1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351
          + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.06;
  ye_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  cf_a = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                   (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
                   * 0.18) + 0.12);
  ye_a = (std::cos((rt_atan2d_snf(std::sin
             (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
             -0.18 - std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
              1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
              0.12)) + std::acos(std::sqrt(ye_a * ye_a + cf_a * cf_a) *
             1.6666666666666667)) + 0.066869026139001891) * -0.33672954507613351
          + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) + 0.06;
  cf_a = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18;
  y = std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                0.18) + 0.12);
  cf_a = std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(cf_a * cf_a + y * y) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18;
  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y = -1.0;
  } else if (u > 0.0) {
    y = 1.0;
  } else if (u == 0.0) {
    y = 0.0;
  } else {
    y = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_0 = -1.0;
  } else if (u > 0.0) {
    y_0 = 1.0;
  } else if (u == 0.0) {
    y_0 = 0.0;
  } else {
    y_0 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_1 = -1.0;
  } else if (u > 0.0) {
    y_1 = 1.0;
  } else if (u == 0.0) {
    y_1 = 0.0;
  } else {
    y_1 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_2 = -1.0;
  } else if (u > 0.0) {
    y_2 = 1.0;
  } else if (u == 0.0) {
    y_2 = 0.0;
  } else {
    y_2 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_3 = -1.0;
  } else if (u > 0.0) {
    y_3 = 1.0;
  } else if (u == 0.0) {
    y_3 = 0.0;
  } else {
    y_3 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_4 = -1.0;
  } else if (u > 0.0) {
    y_4 = 1.0;
  } else if (u == 0.0) {
    y_4 = 0.0;
  } else {
    y_4 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    y_5 = -1.0;
  } else if (u > 0.0) {
    y_5 = 1.0;
  } else if (u == 0.0) {
    y_5 = 0.0;
  } else {
    y_5 = (rtNaN);
  }

  u = (std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) + 0.12;
  if (u < 0.0) {
    u = -1.0;
  } else if (u > 0.0) {
    u = 1.0;
  } else if (u == 0.0) {
    u = 0.0;
  } else {
    u = (rtNaN);
  }

  TestIC_B.dphi = ((((std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::sin
                      (TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) * std::cos
                     (TestIC_B.sf_MATLABFunction2_f.final_pos -
                      1.5707963267948966) * 0.36 - std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12) * y * std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.36) * (1.0 / std::sqrt(t11 * t11 + t10 * t10)) / std::
                    sqrt((t8 * t8 * -2.7777777777777777 - t9 * t9 *
    2.7777777777777777) + 1.0) * 0.83333333333333337 + (1.0 / (t13 * t13) * y_0 *
    std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
    (std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
     0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) * 0.18 + std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 / std::
    abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
         0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) * (t12 * t12) / (t18 * t18 + t21 * t21))
                   * std::cos((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t19 * t19 + t20 * t20) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 / ((std::
    cos((rt_atan2d_snf(std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * -0.18 - std::sin
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12)) + std::acos(std::sqrt(t6 * t6 + t7 * t7) * 1.6666666666666667)) +
        0.066869026139001891) * -0.33672954507613351 + std::cos
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.06) - (((std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
                        1.5707963267948966) * 0.18 + std::sin
               (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
               0.18) * std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.36 - std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12) * y_1 * std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.36) * (1.0 / std::sqrt(t37 * t37 + t39 * t39)) / std::
             sqrt((t47 * t47 * -2.7777777777777777 - t35_re * t35_re *
                   2.7777777777777777) + 1.0) * 0.83333333333333337 + (1.0 /
    (v_a * v_a) * y_2 * std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * (std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    0.18 + std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966)
    * 0.18 / std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) + 0.12)) * (t35_im * t35_im)
             / (w_a * w_a + x_a * x_a)) * ((std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(t24 * t24 + t25 * t25) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    std::sin((rt_atan2d_snf(std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * -0.18 - std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18, std::
    abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
         0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) + std::acos(std::sqrt(t22 * t22 + t23 *
    t23) * 1.6666666666666667)) + 0.066869026139001891)) / (y_a * y_a) *
                   0.33672954507613351) *
    TestIC_B.sf_MATLABFunction2_f.final_vel * (ab_a * ab_a) / (db_a * db_a +
    gb_a * gb_a) - (((((std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::sin
                        (TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) * std::cos
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.36 - std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12) * y_5 * std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.36) * (1.0 / std::sqrt(xb_a * xb_a + yb_a * yb_a)) /
                      std::sqrt((ac_a * ac_a * -2.7777777777777777 - bc_a * bc_a
    * 2.7777777777777777) + 1.0) * 0.83333333333333337 + (1.0 / (dc_a * dc_a) *
    u * std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
    (std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
     0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                     1.5707963267948966) * 0.18) * 0.18 + std::cos
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18 / std::
    abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
         0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) + 0.12)) * (cc_a * cc_a) / (ec_a * ec_a + fc_a *
    fc_a)) * std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(vb_a * vb_a + wb_a * wb_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
                     sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
    1.5707963267948966) * 0.18) * (std::sin((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(tb_a * tb_a + ub_a * ub_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) /
                    (ic_a * ic_a) + (std::cos
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18 -
    (((std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) *
       0.18 + std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos +
                       1.5707963267948966) * 0.18) * std::cos
      (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.36 -
      std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
                0.18) + 0.12) * y_3 * std::sin
      (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.36) *
     (1.0 / std::sqrt(jb_a * jb_a + kb_a * kb_a)) / std::sqrt((lb_a * lb_a *
    -2.7777777777777777 - mb_a * mb_a * 2.7777777777777777) + 1.0) *
     0.83333333333333337 + (1.0 / (ob_a * ob_a) * y_4 * std::sin
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * (std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) *
    0.18 + std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966)
    * 0.18 / std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * 0.18 + std::cos
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18) + 0.12)) * (nb_a * nb_a) /
     (pb_a * pb_a + qb_a * qb_a)) * std::cos((rt_atan2d_snf(std::sin
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * -0.18 - std::
    sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18,
    std::abs((std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos -
                       1.5707963267948966) * 0.18 + std::cos
              (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) *
              0.18) + 0.12)) + std::acos(std::sqrt(hb_a * hb_a + ib_a * ib_a) *
    1.6666666666666667)) + 0.066869026139001891) * 0.33672954507613351) / ((std::
    cos((rt_atan2d_snf(std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos -
    1.5707963267948966) * -0.18 - std::sin
                       (TestIC_B.sf_MATLABFunction2_o.final_pos +
                        1.5707963267948966) * 0.18, std::abs((std::cos
    (TestIC_B.sf_MATLABFunction2_f.final_pos - 1.5707963267948966) * 0.18 + std::
    cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.12)) + std::acos(std::sqrt(rb_a * rb_a + sb_a * sb_a) * 1.6666666666666667))
        + 0.066869026139001891) * -0.33672954507613351 + std::cos
    (TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966) * 0.18) +
    0.06)) * TestIC_B.sf_MATLABFunction2_o.final_vel * (ve_a * ve_a) / (ye_a *
    ye_a + cf_a * cf_a);

  /* End of MATLAB Function: '<Root>/Conversion1' */

  /* MATLAB Function: '<Root>/MATLAB Function1' */
  TestIC_B.E[0] = 0.4714 - TestIC_B.r;
  TestIC_B.E[1] = 0.0012 - TestIC_B.phi;
  TestIC_B.dE[0] = 0.0 - TestIC_B.dr;
  TestIC_B.dE[1] = 0.0 - TestIC_B.dphi;

  /* MATLAB Function: '<Root>/MATLAB Function2' */
  TestIC_B.w_b[0] = 100.0 * TestIC_B.E[0] + 0.2 * TestIC_B.dE[0];
  TestIC_B.w_b[1] = 10.0 * TestIC_B.E[1] + 0.1 * TestIC_B.dE[1];

  /* MATLAB Function: '<Root>/MATLAB Function' */
  t6 = std::cos(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966);
  t7 = std::sin(TestIC_B.sf_MATLABFunction2_o.final_pos + 1.5707963267948966);
  t8 = std::cos(TestIC_B.sf_MATLABFunction2_f.final_pos + -1.5707963267948966);
  t9 = std::sin(TestIC_B.sf_MATLABFunction2_f.final_pos + -1.5707963267948966);
  t10 = t6 * 0.18;
  t11 = t7 * 0.18;
  t12 = t8 * 0.18;
  t13 = t9 * 0.18;
  t18 = t11 + t13;
  t20 = (t10 + t12) + 0.12;
  t19 = t18 * t18;
  t21 = std::abs(t20);
  if (t20 < 0.0) {
    t22 = -1.0;
  } else if (t20 > 0.0) {
    t22 = 1.0;
  } else if (t20 == 0.0) {
    t22 = 0.0;
  } else {
    t22 = (rtNaN);
  }

  t23 = t21 * t21;
  t24 = 1.0 / t21;
  t35_re = (-(t7 * 0.0) + -(t9 * 0.0)) + t21;
  t35_im = -(t7 * 0.18) + -(t9 * 0.18);
  t25 = 1.0 / t23;
  t20 = t19 + t23;
  t37 = 1.0 / t20;
  t20 = std::sqrt(t20);
  t39 = 1.0 / t20;
  t47 = 1.0 / std::sqrt((-(t19 * 2.7777777777777777) + -(t23 *
    2.7777777777777777)) + 1.0);
  t20 = (std::acos(t20 * 1.6666666666666667) + rt_atan2d_snf(t35_im, t35_re)) +
    0.066869026139001891;
  t19 = std::cos(t20);
  t20 = std::sin(t20);
  t6 = (-(t7 * t21 * t22 * 0.36) + t6 * t18 * 0.36) * (t39 * t47) *
    0.83333333333333337 + (t11 * t18 * t22 * t25 + t10 * t24) * (t23 * t37);
  t8 = (-(t9 * t21 * t22 * 0.36) + t8 * t18 * 0.36) * (t39 * t47) *
    0.83333333333333337 + (t13 * t18 * t22 * t25 + t12 * t24) * (t23 * t37);
  t9 = t19 * 0.33672954507613351;
  t18 = t20 * 0.33672954507613351;
  t12 = t11 + t18;
  t13 = t19 * t6 * -0.33672954507613351 + t10;
  t10 = (t10 + -t9) + 0.06;
  t11 += t18 * t6;
  t18 = t10 * t10;
  t21 = 1.0 / t10;
  t6 = 1.0 / t18;
  t22 = t12 * t12 + t18;
  t7 = 1.0 / t22;
  t22 = 1.0 / std::sqrt(t22);
  TestIC_B.J11 = (t19 * t12 * t8 * 0.673459090152267 + t20 * t10 * t8 *
                  0.673459090152267) * t22 * -0.5;
  TestIC_B.J21 = (t9 * t21 * t8 - t20 * t12 * t6 * t8 * 0.33672954507613351) *
    (t18 * t7);
  TestIC_B.J12 = (t12 * t13 * 2.0 - t10 * t11 * 2.0) * t22 / 2.0;
  TestIC_B.J22 = (t12 * t6 * t11 + t21 * t13) * (-t18 * t7);

  /* End of MATLAB Function: '<Root>/MATLAB Function' */

  /* MATLAB Function: '<Root>/MATLAB Function4' */
  t10 = TestIC_B.J11;
  t19 = TestIC_B.J21;
  t20 = TestIC_B.J12;
  t11 = TestIC_B.J22;
  t8 = t10 * TestIC_B.w_b[0];
  t8 += t19 * TestIC_B.w_b[1];
  t10 = t8;
  t8 = t20 * TestIC_B.w_b[0];
  t8 += t11 * TestIC_B.w_b[1];
  TestIC_B.t1 = t10;
  TestIC_B.t2 = t8;

  /* Gain: '<Root>/Multiply1' */
  TestIC_B.theta2position = TestIC_cal->Multiply1_Gain *
    TestIC_B.sf_MATLABFunction2_o.final_pos;

  /* Gain: '<Root>/Multiply' */
  TestIC_B.theta1position = TestIC_cal->Multiply_Gain *
    TestIC_B.sf_MATLABFunction2_f.final_pos;

  /* DiscretePulseGenerator: '<S8>/Write 1' */
  TestIC_B.w1 = (TestIC_DW.clockTickCounter_h < TestIC_cal->Write1_Duty) &&
    (TestIC_DW.clockTickCounter_h >= 0) ? TestIC_cal->Write1_Amp : 0.0;

  /* DiscretePulseGenerator: '<S8>/Write 1' */
  if (TestIC_DW.clockTickCounter_h >= TestIC_cal->Write1_Period - 1.0) {
    TestIC_DW.clockTickCounter_h = 0;
  } else {
    TestIC_DW.clockTickCounter_h++;
  }

  /* Outputs for Triggered SubSystem: '<S8>/Motor 3 Write - THETA1' incorporates:
   *  TriggerPort: '<S17>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestIC_PrevZCX.Motor3WriteTHETA1_Trig_ZCE,
                     (TestIC_B.w1));
  if (zcEvent != NO_ZCEVENT) {
    /* MATLAB Function: '<S17>/MATLAB Function' incorporates:
     *  Constant: '<S8>/Constant2'
     */
    TestIC_MATLABFunction(TestIC_cal->Constant2_Value, TestIC_B.t1,
                          &TestIC_B.sf_MATLABFunction_kk);

    /* S-Function (scanpack): '<S17>/CAN Pack3' */
    /* S-Function (scanpack): '<S17>/CAN Pack3' */
    TestIC_B.CANPack3.ID = 3U;
    TestIC_B.CANPack3.Length = 8U;
    TestIC_B.CANPack3.Extended = 0U;
    TestIC_B.CANPack3.Remote = 0;
    TestIC_B.CANPack3.Data[0] = 0;
    TestIC_B.CANPack3.Data[1] = 0;
    TestIC_B.CANPack3.Data[2] = 0;
    TestIC_B.CANPack3.Data[3] = 0;
    TestIC_B.CANPack3.Data[4] = 0;
    TestIC_B.CANPack3.Data[5] = 0;
    TestIC_B.CANPack3.Data[6] = 0;
    TestIC_B.CANPack3.Data[7] = 0;

    {
      /* --------------- START Packing signal 0 ------------------
       *  startBit                = 0
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_kk.P8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[0] = TestIC_B.CANPack3.Data[0] | (uint8_T)
                (packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 1 ------------------
       *  startBit                = 8
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_kk.P8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestIC_B.CANPack3.Data[1] = TestIC_B.CANPack3.Data[1] | (uint8_T)
                (packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 2 ------------------
       *  startBit                = 16
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_kk.V8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[2] = TestIC_B.CANPack3.Data[2] | (uint8_T)
                (packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 3 ------------------
       *  startBit                = 28
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_kk.V4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[3] = TestIC_B.CANPack3.Data[3] | (uint8_T)
                ((uint8_T)((uint8_T)(packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 4 ------------------
       *  startBit                = 24
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_kk.KP4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[3] = TestIC_B.CANPack3.Data[3] | (uint8_T)
                ((uint8_T)(packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 5 ------------------
       *  startBit                = 32
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_kk.KP8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestIC_B.CANPack3.Data[4] = TestIC_B.CANPack3.Data[4] | (uint8_T)
                (packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 6 ------------------
       *  startBit                = 40
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_kk.KD8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[5] = TestIC_B.CANPack3.Data[5] | (uint8_T)
                (packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 7 ------------------
       *  startBit                = 52
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_kk.KD4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[6] = TestIC_B.CANPack3.Data[6] | (uint8_T)
                ((uint8_T)((uint8_T)(packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 8 ------------------
       *  startBit                = 48
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_kk.T4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3.Data[6] = TestIC_B.CANPack3.Data[6] | (uint8_T)
                ((uint8_T)(packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 9 ------------------
       *  startBit                = 56
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_kk.T8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestIC_B.CANPack3.Data[7] = TestIC_B.CANPack3.Data[7] | (uint8_T)
                (packedValue);
            }
          }
        }
      }
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S17>/CAN Write1' */

    /* Level2 S-Function Block: '<S17>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[7];
      sfcnOutputs(rts,0);
    }

    TestIC_DW.Motor3WriteTHETA1_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S8>/Motor 3 Write - THETA1' */

  /* DiscretePulseGenerator: '<S8>/Write 2' */
  TestIC_B.w2 = (TestIC_DW.clockTickCounter_m < TestIC_cal->Write2_Duty) &&
    (TestIC_DW.clockTickCounter_m >= 0) ? TestIC_cal->Write2_Amp : 0.0;

  /* DiscretePulseGenerator: '<S8>/Write 2' */
  if (TestIC_DW.clockTickCounter_m >= TestIC_cal->Write2_Period - 1.0) {
    TestIC_DW.clockTickCounter_m = 0;
  } else {
    TestIC_DW.clockTickCounter_m++;
  }

  /* Outputs for Triggered SubSystem: '<S8>/Motor 2 Write - THETA2' incorporates:
   *  TriggerPort: '<S15>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestIC_PrevZCX.Motor2WriteTHETA2_Trig_ZCE,
                     (TestIC_B.w2));
  if (zcEvent != NO_ZCEVENT) {
    /* MATLAB Function: '<S15>/MATLAB Function' incorporates:
     *  Constant: '<S8>/Constant6'
     */
    TestIC_MATLABFunction(TestIC_cal->Constant6_Value, TestIC_B.t2,
                          &TestIC_B.sf_MATLABFunction_k);

    /* S-Function (scanpack): '<S15>/CAN Pack3' */
    /* S-Function (scanpack): '<S15>/CAN Pack3' */
    TestIC_B.CANPack3_m.ID = 2U;
    TestIC_B.CANPack3_m.Length = 8U;
    TestIC_B.CANPack3_m.Extended = 0U;
    TestIC_B.CANPack3_m.Remote = 0;
    TestIC_B.CANPack3_m.Data[0] = 0;
    TestIC_B.CANPack3_m.Data[1] = 0;
    TestIC_B.CANPack3_m.Data[2] = 0;
    TestIC_B.CANPack3_m.Data[3] = 0;
    TestIC_B.CANPack3_m.Data[4] = 0;
    TestIC_B.CANPack3_m.Data[5] = 0;
    TestIC_B.CANPack3_m.Data[6] = 0;
    TestIC_B.CANPack3_m.Data[7] = 0;

    {
      /* --------------- START Packing signal 0 ------------------
       *  startBit                = 0
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_k.P8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[0] = TestIC_B.CANPack3_m.Data[0] |
                (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 1 ------------------
       *  startBit                = 8
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_k.P8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestIC_B.CANPack3_m.Data[1] = TestIC_B.CANPack3_m.Data[1] |
                (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 2 ------------------
       *  startBit                = 16
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_k.V8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[2] = TestIC_B.CANPack3_m.Data[2] |
                (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 3 ------------------
       *  startBit                = 28
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_k.V4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[3] = TestIC_B.CANPack3_m.Data[3] |
                (uint8_T)((uint8_T)((uint8_T)(packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 4 ------------------
       *  startBit                = 24
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_k.KP4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[3] = TestIC_B.CANPack3_m.Data[3] |
                (uint8_T)((uint8_T)(packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 5 ------------------
       *  startBit                = 32
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_k.KP8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestIC_B.CANPack3_m.Data[4] = TestIC_B.CANPack3_m.Data[4] |
                (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 6 ------------------
       *  startBit                = 40
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_k.KD8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[5] = TestIC_B.CANPack3_m.Data[5] |
                (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 7 ------------------
       *  startBit                = 52
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_k.KD4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[6] = TestIC_B.CANPack3_m.Data[6] |
                (uint8_T)((uint8_T)((uint8_T)(packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 8 ------------------
       *  startBit                = 48
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestIC_B.sf_MATLABFunction_k.T4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestIC_B.CANPack3_m.Data[6] = TestIC_B.CANPack3_m.Data[6] |
                (uint8_T)((uint8_T)(packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 9 ------------------
       *  startBit                = 56
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestIC_B.sf_MATLABFunction_k.T8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestIC_B.CANPack3_m.Data[7] = TestIC_B.CANPack3_m.Data[7] |
                (uint8_T)(packedValue);
            }
          }
        }
      }
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S15>/CAN Write1' */

    /* Level2 S-Function Block: '<S15>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[5];
      sfcnOutputs(rts,0);
    }

    TestIC_DW.Motor2WriteTHETA2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S8>/Motor 2 Write - THETA2' */

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++TestIC_M->Timing.clockTick0)) {
    ++TestIC_M->Timing.clockTickH0;
  }

  TestIC_M->Timing.t[0] = TestIC_M->Timing.clockTick0 *
    TestIC_M->Timing.stepSize0 + TestIC_M->Timing.clockTickH0 *
    TestIC_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void TestIC_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  rtsiSetSolverName(&TestIC_M->solverInfo,"FixedStepDiscrete");
  TestIC_M->solverInfoPtr = (&TestIC_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = TestIC_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    TestIC_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    TestIC_M->Timing.sampleTimes = (&TestIC_M->Timing.sampleTimesArray[0]);
    TestIC_M->Timing.offsetTimes = (&TestIC_M->Timing.offsetTimesArray[0]);

    /* task periods */
    TestIC_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    TestIC_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(TestIC_M, &TestIC_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = TestIC_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    TestIC_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(TestIC_M, -1);
  TestIC_M->Timing.stepSize0 = 0.001;
  TestIC_M->solverInfoPtr = (&TestIC_M->solverInfo);
  TestIC_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&TestIC_M->solverInfo, 0.001);
  rtsiSetSolverMode(&TestIC_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) std::memset((static_cast<void *>(&TestIC_B)), 0,
                     sizeof(B_TestIC_T));

  {
    TestIC_B.CANPack3 = CAN_DATATYPE_GROUND;
    TestIC_B.CANRead1_o2 = CAN_DATATYPE_GROUND;
    TestIC_B.CANPack3_m = CAN_DATATYPE_GROUND;
    TestIC_B.CANRead1_o2_h = CAN_DATATYPE_GROUND;
    TestIC_B.CANPack1 = CAN_DATATYPE_GROUND;
    TestIC_B.CANPack1_p = CAN_DATATYPE_GROUND;
    TestIC_B.CANPack1_i = CAN_DATATYPE_GROUND;
    TestIC_B.CANPack1_n = CAN_DATATYPE_GROUND;
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&TestIC_DW), 0,
                     sizeof(DW_TestIC_T));

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &TestIC_M->NonInlinedSFcns.sfcnInfo;
    TestIC_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(TestIC_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &TestIC_M->Sizes.numSampTimes);
    TestIC_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr(TestIC_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,TestIC_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(TestIC_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(TestIC_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(TestIC_M));
    rtssSetStepSizePtr(sfcnInfo, &TestIC_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(TestIC_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo, &TestIC_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &TestIC_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &TestIC_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &TestIC_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo, &TestIC_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &TestIC_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &TestIC_M->solverInfoPtr);
  }

  TestIC_M->Sizes.numSFcns = (10);

  /* register each child */
  {
    (void) std::memset(static_cast<void *>
                       (&TestIC_M->NonInlinedSFcns.childSFunctions[0]), 0,
                       10*sizeof(SimStruct));
    TestIC_M->childSfunctions = (&TestIC_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 10; i++) {
        TestIC_M->childSfunctions[i] =
          (&TestIC_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: TestIC/<S10>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn0.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn0.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestIC_B.CANPack1_n);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestIC/Motor Setup/Motor Setup/Enter Motor Control Mode M2/CAN Write1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANWrite1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANWrite1_PWORK_e);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANWrite1_PWORK_e);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestIC/<S11>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn1.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestIC_B.CANPack1_i);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestIC/Motor Setup/Motor Setup/Enter Motor Control Mode M3/CAN Write1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANWrite1_P1_Size_e);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANWrite1_PWORK_k);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANWrite1_PWORK_k);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestIC/<S12>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn2.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn2.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestIC_B.CANPack1_p);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts, "TestIC/Motor Setup/Motor Setup/Set Origin M2/CAN Write1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANWrite1_P1_Size_o);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANWrite1_PWORK_p);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANWrite1_PWORK_p);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestIC/<S13>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn3.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn3.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestIC_B.CANPack1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts, "TestIC/Motor Setup/Motor Setup/Set Origin M3/CAN Write1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANWrite1_P1_Size_o2);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANWrite1_PWORK_n);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANWrite1_PWORK_n);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestIC/<S14>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn4.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn4.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *) &TestIC_B.CANRead1_o1_a));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &TestIC_B.CANRead1_o2_h));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts, "TestIC/Subsystem1/Motor 2 Read - THETA2/CAN Read1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANRead1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANRead1_PWORK_k);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANRead1_PWORK_k);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: TestIC/<S15>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[5]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[5]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn5.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn5.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestIC_B.CANPack3_m);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts, "TestIC/Subsystem1/Motor 2 Write - THETA2/CAN Write1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANWrite1_P1_Size_m);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANWrite1_PWORK_g);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn5.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn5.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANWrite1_PWORK_g);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestIC/<S16>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[6]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[6]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn6.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn6.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *) &TestIC_B.CANRead1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *) &TestIC_B.CANRead1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts, "TestIC/Subsystem1/Motor 3 Read - THETA1/CAN Read1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANRead1_P1_Size_f);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANRead1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn6.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn6.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANRead1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: TestIC/<S17>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[7]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[7]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn7.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn7.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestIC_B.CANPack3);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts, "TestIC/Subsystem1/Motor 3 Write - THETA1/CAN Write1");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANWrite1_P1_Size_oy);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANWrite1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn7.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn7.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANWrite1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestIC/<S7>/CAN setup (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[8]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[8]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* path info */
      ssSetModelName(rts, "CAN setup");
      ssSetPath(rts, "TestIC/Motor Setup/CAN setup");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANsetup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)TestIC_cal->CANsetup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)TestIC_cal->CANsetup_P3_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestIC_DW.CANsetup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn8.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn8.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANsetup_PWORK);
      }

      /* registration */
      sg_IO602_IO691_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: TestIC/<Root>/CAN Status (sg_IO602_IO691_status_s) */
    {
      SimStruct *rts = TestIC_M->childSfunctions[9];

      /* timing info */
      time_T *sfcnPeriod = TestIC_M->NonInlinedSFcns.Sfcn9.sfcnPeriod;
      time_T *sfcnOffset = TestIC_M->NonInlinedSFcns.Sfcn9.sfcnOffset;
      int_T *sfcnTsMap = TestIC_M->NonInlinedSFcns.Sfcn9.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestIC_M->NonInlinedSFcns.blkInfo2[9]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestIC_M->NonInlinedSFcns.inputOutputPortInfo2[9]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestIC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestIC_M->NonInlinedSFcns.methods2[9]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestIC_M->NonInlinedSFcns.methods3[9]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestIC_M->NonInlinedSFcns.methods4[9]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestIC_M->NonInlinedSFcns.statesInfo2[9]);
        ssSetPeriodicStatesInfo(rts,
          &TestIC_M->NonInlinedSFcns.periodicStatesInfo[9]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn9.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 3);
        _ssSetPortInfo2ForOutputUnits(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn9.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &TestIC_M->NonInlinedSFcns.Sfcn9.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &TestIC_B.busload));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &TestIC_B.w));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *) &TestIC_B.e));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Status");
      ssSetPath(rts, "TestIC/CAN Status");
      ssSetRTModel(rts,TestIC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestIC_M->NonInlinedSFcns.Sfcn9.params;
        ssSetSFcnParamsCount(rts, 34);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestIC_cal->CANStatus_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)TestIC_cal->CANStatus_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)TestIC_cal->CANStatus_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)TestIC_cal->CANStatus_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)TestIC_cal->CANStatus_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)TestIC_cal->CANStatus_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)TestIC_cal->CANStatus_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)TestIC_cal->CANStatus_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)TestIC_cal->CANStatus_P9_Size);
        ssSetSFcnParam(rts, 9, (mxArray*)TestIC_cal->CANStatus_P10_Size);
        ssSetSFcnParam(rts, 10, (mxArray*)TestIC_cal->CANStatus_P11_Size);
        ssSetSFcnParam(rts, 11, (mxArray*)TestIC_cal->CANStatus_P12_Size);
        ssSetSFcnParam(rts, 12, (mxArray*)TestIC_cal->CANStatus_P13_Size);
        ssSetSFcnParam(rts, 13, (mxArray*)TestIC_cal->CANStatus_P14_Size);
        ssSetSFcnParam(rts, 14, (mxArray*)TestIC_cal->CANStatus_P15_Size);
        ssSetSFcnParam(rts, 15, (mxArray*)TestIC_cal->CANStatus_P16_Size);
        ssSetSFcnParam(rts, 16, (mxArray*)TestIC_cal->CANStatus_P17_Size);
        ssSetSFcnParam(rts, 17, (mxArray*)TestIC_cal->CANStatus_P18_Size);
        ssSetSFcnParam(rts, 18, (mxArray*)TestIC_cal->CANStatus_P19_Size);
        ssSetSFcnParam(rts, 19, (mxArray*)TestIC_cal->CANStatus_P20_Size);
        ssSetSFcnParam(rts, 20, (mxArray*)TestIC_cal->CANStatus_P21_Size);
        ssSetSFcnParam(rts, 21, (mxArray*)TestIC_cal->CANStatus_P22_Size);
        ssSetSFcnParam(rts, 22, (mxArray*)TestIC_cal->CANStatus_P23_Size);
        ssSetSFcnParam(rts, 23, (mxArray*)TestIC_cal->CANStatus_P24_Size);
        ssSetSFcnParam(rts, 24, (mxArray*)TestIC_cal->CANStatus_P25_Size);
        ssSetSFcnParam(rts, 25, (mxArray*)TestIC_cal->CANStatus_P26_Size);
        ssSetSFcnParam(rts, 26, (mxArray*)TestIC_cal->CANStatus_P27_Size);
        ssSetSFcnParam(rts, 27, (mxArray*)TestIC_cal->CANStatus_P28_Size);
        ssSetSFcnParam(rts, 28, (mxArray*)TestIC_cal->CANStatus_P29_Size);
        ssSetSFcnParam(rts, 29, (mxArray*)TestIC_cal->CANStatus_P30_Size);
        ssSetSFcnParam(rts, 30, (mxArray*)TestIC_cal->CANStatus_P31_Size);
        ssSetSFcnParam(rts, 31, (mxArray*)TestIC_cal->CANStatus_P32_Size);
        ssSetSFcnParam(rts, 32, (mxArray*)TestIC_cal->CANStatus_P33_Size);
        ssSetSFcnParam(rts, 33, (mxArray*)TestIC_cal->CANStatus_P34_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &TestIC_DW.CANStatus_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn9.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestIC_M->NonInlinedSFcns.Sfcn9.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 34);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestIC_DW.CANStatus_IWORK[0]);
      }

      /* registration */
      sg_IO602_IO691_status_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);

      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Start for S-Function (sg_IO602_IO691_setup_s): '<S7>/CAN setup' */
  /* Level2 S-Function Block: '<S7>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[8];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (sg_IO602_IO691_status_s): '<Root>/CAN Status' */
  /* Level2 S-Function Block: '<Root>/CAN Status' (sg_IO602_IO691_status_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[9];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for DiscretePulseGenerator: '<S8>/Read 1' */
  TestIC_DW.clockTickCounter = -3001;

  /* Start for DiscretePulseGenerator: '<S8>/Read 2' */
  TestIC_DW.clockTickCounter_i = -3003;

  /* Start for DiscretePulseGenerator: '<S8>/Write 1' */
  TestIC_DW.clockTickCounter_h = -3000;

  /* Start for DiscretePulseGenerator: '<S8>/Write 2' */
  TestIC_DW.clockTickCounter_m = -3001;
  TestIC_PrevZCX.EnterMotorControlModeM2_Trig_ZC = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.EnterMotorControlModeM3_Trig_ZC = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.SetOriginM2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.SetOriginM3_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.Motor2ReadTHETA2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.Motor2WriteTHETA2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.Motor3ReadTHETA1_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestIC_PrevZCX.Motor3WriteTHETA1_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* Start for S-Function (sg_IO602_IO691_write_s): '<S10>/CAN Write1' */
  /* Level2 S-Function Block: '<S10>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S9>/Enter Motor Control Mode M2' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S11>/CAN Write1' */
  /* Level2 S-Function Block: '<S11>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S9>/Enter Motor Control Mode M3' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S12>/CAN Write1' */
  /* Level2 S-Function Block: '<S12>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S9>/Set Origin M2' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S13>/CAN Write1' */
  /* Level2 S-Function Block: '<S13>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[3];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S9>/Set Origin M3' */
  /* Start for S-Function (sg_IO602_IO691_read_s): '<S16>/CAN Read1' */
  /* Level2 S-Function Block: '<S16>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[6];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (scanunpack): '<S16>/CAN Unpack3' */

  /*-----------S-Function Block: <S16>/CAN Unpack3 -----------------*/

  /* SystemInitialize for Enabled SubSystem: '<S16>/Enabled Subsystem' */
  TestIC_EnabledSubsystem_Init(&TestIC_B.EnabledSubsystem_d,
    &TestIC_cal->TestIC_EnabledSubsystem_d_cal);

  /* End of SystemInitialize for SubSystem: '<S16>/Enabled Subsystem' */

  /* SystemInitialize for Outport: '<S16>/motor 3 position' */
  TestIC_B.sf_MATLABFunction2_f.final_pos = TestIC_cal->motor3position_Y0;

  /* SystemInitialize for Outport: '<S16>/motor 3 velocity' */
  TestIC_B.sf_MATLABFunction2_f.final_vel = TestIC_cal->motor3velocity_Y0;

  /* End of SystemInitialize for SubSystem: '<S8>/Motor 3 Read - THETA1' */
  /* Start for S-Function (sg_IO602_IO691_read_s): '<S14>/CAN Read1' */
  /* Level2 S-Function Block: '<S14>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[4];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (scanunpack): '<S14>/CAN Unpack3' */

  /*-----------S-Function Block: <S14>/CAN Unpack3 -----------------*/

  /* SystemInitialize for Enabled SubSystem: '<S14>/Enabled Subsystem' */
  TestIC_EnabledSubsystem_Init(&TestIC_B.EnabledSubsystem,
    &TestIC_cal->TestIC_EnabledSubsystem_cal);

  /* End of SystemInitialize for SubSystem: '<S14>/Enabled Subsystem' */

  /* SystemInitialize for Outport: '<S14>/motor 2 position' */
  TestIC_B.sf_MATLABFunction2_o.final_pos = TestIC_cal->motor2position_Y0;

  /* SystemInitialize for Outport: '<S14>/motor 2 velocity' */
  TestIC_B.sf_MATLABFunction2_o.final_vel = TestIC_cal->motor2velocity_Y0;

  /* End of SystemInitialize for SubSystem: '<S8>/Motor 2 Read - THETA2' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S17>/CAN Write1' */
  /* Level2 S-Function Block: '<S17>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[7];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S8>/Motor 3 Write - THETA1' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S15>/CAN Write1' */
  /* Level2 S-Function Block: '<S15>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[5];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S8>/Motor 2 Write - THETA2' */
}

/* Model terminate function */
void TestIC_terminate(void)
{
  /* Terminate for S-Function (sg_IO602_IO691_setup_s): '<S7>/CAN setup' */
  /* Level2 S-Function Block: '<S7>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[8];
    sfcnTerminate(rts);
  }

  /* Terminate for Triggered SubSystem: '<S9>/Enter Motor Control Mode M2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S10>/CAN Write1' */
  /* Level2 S-Function Block: '<S10>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/Enter Motor Control Mode M2' */

  /* Terminate for Triggered SubSystem: '<S9>/Enter Motor Control Mode M3' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S11>/CAN Write1' */
  /* Level2 S-Function Block: '<S11>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/Enter Motor Control Mode M3' */

  /* Terminate for Triggered SubSystem: '<S9>/Set Origin M2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S12>/CAN Write1' */
  /* Level2 S-Function Block: '<S12>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/Set Origin M2' */

  /* Terminate for Triggered SubSystem: '<S9>/Set Origin M3' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S13>/CAN Write1' */
  /* Level2 S-Function Block: '<S13>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/Set Origin M3' */

  /* Terminate for S-Function (sg_IO602_IO691_status_s): '<Root>/CAN Status' */
  /* Level2 S-Function Block: '<Root>/CAN Status' (sg_IO602_IO691_status_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[9];
    sfcnTerminate(rts);
  }

  /* Terminate for Triggered SubSystem: '<S8>/Motor 3 Read - THETA1' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S16>/CAN Read1' */
  /* Level2 S-Function Block: '<S16>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S8>/Motor 3 Read - THETA1' */

  /* Terminate for Triggered SubSystem: '<S8>/Motor 2 Read - THETA2' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S14>/CAN Read1' */
  /* Level2 S-Function Block: '<S14>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S8>/Motor 2 Read - THETA2' */

  /* Terminate for Triggered SubSystem: '<S8>/Motor 3 Write - THETA1' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S17>/CAN Write1' */
  /* Level2 S-Function Block: '<S17>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S8>/Motor 3 Write - THETA1' */

  /* Terminate for Triggered SubSystem: '<S8>/Motor 2 Write - THETA2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S15>/CAN Write1' */
  /* Level2 S-Function Block: '<S15>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestIC_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S8>/Motor 2 Write - THETA2' */
}
