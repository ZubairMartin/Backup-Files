#include "MAIN_calintf.h"
#include "MAIN.h"
#include "MAIN_cal.h"

extern MAIN_cal_type MAIN_cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    {
      (void*)&MAIN_cal_impl, (void**)&MAIN_cal, sizeof(MAIN_cal_type), 2
    } };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime
