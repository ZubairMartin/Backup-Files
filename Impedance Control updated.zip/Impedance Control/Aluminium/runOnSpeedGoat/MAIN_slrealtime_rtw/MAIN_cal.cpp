#include "MAIN.h"

/* Storage class 'PageSwitching' */

/* Storage class 'PageSwitching' */
MAIN_cal_type MAIN_cal_impl = {
  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S17>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_b
   * Referenced by: '<S21>/Constant'
   */
  3.0,

  /* Computed Parameter: CANWrite1_P1_Size
   * Referenced by: '<S11>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S11>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_e
   * Referenced by: '<S12>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S12>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: motor2position_Y0
   * Referenced by: '<S13>/motor 2 position'
   */
  0.0,

  /* Computed Parameter: motor2velocity_Y0
   * Referenced by: '<S13>/motor 2 velocity'
   */
  0.0,

  /* Computed Parameter: CANRead1_P1_Size
   * Referenced by: '<S13>/CAN Read1'
   */
  { 1.0, 6.0 },

  /* Expression: [initValues(1:4) messageType initValues(6)]
   * Referenced by: '<S13>/CAN Read1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0 },

  /* Computed Parameter: CANWrite1_P1_Size_m
   * Referenced by: '<S14>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S14>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: motor3position_Y0
   * Referenced by: '<S15>/motor 3 position'
   */
  0.0,

  /* Computed Parameter: motor3velocity_Y0
   * Referenced by: '<S15>/motor 3 velocity'
   */
  0.0,

  /* Computed Parameter: CANRead1_P1_Size_f
   * Referenced by: '<S15>/CAN Read1'
   */
  { 1.0, 6.0 },

  /* Expression: [initValues(1:4) messageType initValues(6)]
   * Referenced by: '<S15>/CAN Read1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0 },

  /* Computed Parameter: CANWrite1_P1_Size_o
   * Referenced by: '<S16>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S16>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANsetup_P1_Size
   * Referenced by: '<S6>/CAN setup'
   */
  { 1.0, 40.0 },

  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S6>/CAN setup'
   */
  { 691.0, 1.0, -1.0, -1.0, 2.0, 2.0, 8.0, 31.0, 8.0, 2.0, 8.0, 31.0, 8.0, 1.0,
    2.0, 8.0, 31.0, 8.0, 2.0, 8.0, 31.0, 8.0, 1.0, 2.0, 8.0, 31.0, 8.0, 2.0, 2.0,
    5.0, 2.0, 1.0, 2.0, 8.0, 31.0, 8.0, 2.0, 2.0, 5.0, 2.0 },

  /* Computed Parameter: CANsetup_P2_Size
   * Referenced by: '<S6>/CAN setup'
   */
  { 1.0, 1.0 },

  /* Expression: initStruct
   * Referenced by: '<S6>/CAN setup'
   */
  0.0,

  /* Computed Parameter: CANsetup_P3_Size
   * Referenced by: '<S6>/CAN setup'
   */
  { 1.0, 31.0 },

  /* Expression: termStruct
   * Referenced by: '<S6>/CAN setup'
   */
  { 2.0, 0.0, 1.0, 0.0, 2.0, 8.0, 0.0, 255.0, 255.0, 255.0, 255.0, 255.0, 255.0,
    255.0, 253.0, 0.001, 0.0, 1.0, 0.0, 3.0, 8.0, 0.0, 255.0, 255.0, 255.0,
    255.0, 255.0, 255.0, 255.0, 253.0, 0.001 },

  /* Expression: 1.0
   * Referenced by: '<S10>/Step3'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S10>/Step3'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S10>/Step3'
   */
  1.0,

  /* Expression: 0.5
   * Referenced by: '<S10>/Step'
   */
  0.5,

  /* Expression: 0
   * Referenced by: '<S10>/Step'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S10>/Step'
   */
  1.0,

  /* Computed Parameter: CANStatus_P1_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: moduleId
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P2_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: sampleTime
   * Referenced by: '<Root>/CAN Status'
   */
  -1.0,

  /* Computed Parameter: CANStatus_P3_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: channel
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P4_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: busRecovery
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P5_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: avgBusLoad
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P6_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: opMode
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P7_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: brp
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P8_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: timeSegment1
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P9_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: timeSegment2
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P10_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: synchronisationJumpWidth
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P11_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: dataTSEG1
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P12_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: dataTSEG2
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P13_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: dataSJW
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P14_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: txPending
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P15_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: dataOverrunTx
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P16_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: receiving
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P17_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: RxQueueEmpty
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P18_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: dataOverrunRcv
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P19_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: errWarnLimit
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P20_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: errPassLimit
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P21_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: errBusOff
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P22_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: busRecoveryCounter
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P23_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: initModeAct
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P24_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: busCouplingErr
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P25_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: transceiverErr
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P26_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: controllerCpuLoad
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P27_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: controllerLiveCount
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P28_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: rxBufferLevel
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P29_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: txBufferLevel
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P30_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: arrayOutput
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P31_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: moduleType
   * Referenced by: '<Root>/CAN Status'
   */
  691.0,

  /* Computed Parameter: CANStatus_P32_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: qtyStatBlk
   * Referenced by: '<Root>/CAN Status'
   */
  1.0,

  /* Computed Parameter: CANStatus_P33_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: ptIdx
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Computed Parameter: CANStatus_P34_Size
   * Referenced by: '<Root>/CAN Status'
   */
  { 1.0, 1.0 },

  /* Expression: isFDMod
   * Referenced by: '<Root>/CAN Status'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S7>/Read 1'
   */
  1.0,

  /* Computed Parameter: Read1_Period
   * Referenced by: '<S7>/Read 1'
   */
  4.0,

  /* Computed Parameter: Read1_Duty
   * Referenced by: '<S7>/Read 1'
   */
  2.0,

  /* Expression: 3.001
   * Referenced by: '<S7>/Read 1'
   */
  3.001,

  /* Expression: 1
   * Referenced by: '<S7>/Read 2'
   */
  1.0,

  /* Computed Parameter: Read2_Period
   * Referenced by: '<S7>/Read 2'
   */
  4.0,

  /* Computed Parameter: Read2_Duty
   * Referenced by: '<S7>/Read 2'
   */
  2.0,

  /* Expression: 3.003
   * Referenced by: '<S7>/Read 2'
   */
  3.003,

  /* Expression: 0.4
   * Referenced by: '<Root>/r_ref'
   */
  0.4,

  /* Expression: 0.008
   * Referenced by: '<Root>/phi_ref'
   */
  0.008,

  /* Expression: 180/pi
   * Referenced by: '<Root>/Multiply1'
   */
  57.295779513082323,

  /* Expression: 180/pi
   * Referenced by: '<Root>/Multiply2'
   */
  57.295779513082323,

  /* Expression: 180/pi
   * Referenced by: '<Root>/Multiply'
   */
  57.295779513082323,

  /* Expression: 0
   * Referenced by: '<S7>/Constant2'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S7>/Write 1'
   */
  1.0,

  /* Computed Parameter: Write1_Period
   * Referenced by: '<S7>/Write 1'
   */
  4.0,

  /* Computed Parameter: Write1_Duty
   * Referenced by: '<S7>/Write 1'
   */
  2.0,

  /* Expression: 3
   * Referenced by: '<S7>/Write 1'
   */
  3.0,

  /* Expression: 0
   * Referenced by: '<S7>/Constant6'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S7>/Write 2'
   */
  1.0,

  /* Computed Parameter: Write2_Period
   * Referenced by: '<S7>/Write 2'
   */
  4.0,

  /* Computed Parameter: Write2_Duty
   * Referenced by: '<S7>/Write 2'
   */
  2.0,

  /* Expression: 3.002
   * Referenced by: '<S7>/Write 2'
   */
  3.002,

  /* Computed Parameter: Constant_Value
   * Referenced by: '<S11>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value
   * Referenced by: '<S11>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_d
   * Referenced by: '<S11>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value
   * Referenced by: '<S11>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value
   * Referenced by: '<S11>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value
   * Referenced by: '<S11>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_b
   * Referenced by: '<S11>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value
   * Referenced by: '<S11>/Constant7'
   */
  252U,

  /* Computed Parameter: Constant_Value_c
   * Referenced by: '<S12>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_g
   * Referenced by: '<S12>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_b
   * Referenced by: '<S12>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_e
   * Referenced by: '<S12>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_k
   * Referenced by: '<S12>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_j
   * Referenced by: '<S12>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_o
   * Referenced by: '<S12>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_e
   * Referenced by: '<S12>/Constant7'
   */
  252U,

  /* Start of '<S15>/Enabled Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S22>/Out1'
     */
    {
      0.0,                             /* motor_ID */
      0.0,                             /* MP_8H */
      0.0,                             /* MP_8L */
      0.0,                             /* MS_8H */
      0.0,                             /* MS_4L */
      0.0,                             /* MC_4H */
      0.0                              /* MC_8L */
    }
  }
  ,

  /* End of '<S15>/Enabled Subsystem' */

  /* Start of '<S13>/Enabled Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S18>/Out1'
     */
    {
      0.0,                             /* motor_ID */
      0.0,                             /* MP_8H */
      0.0,                             /* MP_8L */
      0.0,                             /* MS_8H */
      0.0,                             /* MS_4L */
      0.0,                             /* MC_4H */
      0.0                              /* MC_8L */
    }
  }
  /* End of '<S13>/Enabled Subsystem' */
};

MAIN_cal_type *MAIN_cal = &MAIN_cal_impl;
