#include "test_calintf.h"
#include "test.h"
#include "test_cal.h"

extern test_cal_type test_cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    {
      (void*)&test_cal_impl, (void**)&test_cal, sizeof(test_cal_type), 2
    } };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime
