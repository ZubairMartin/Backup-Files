/* Main generated for Simulink Real-Time model test */
#include <ModelInfo.hpp>
#include "test.h"
#include "test_calintf.h"

/* Task descriptors */
slrealtime::TaskInfo task_1( 0u, std::bind(test_step), slrealtime::TaskInfo::PERIODIC, 0.001, 0, 40);

/* Model descriptor */
slrealtime::ModelInfo test_Info =
{
    "test",
    test_initialize,
    test_terminate,
    []()->char const*& { return test_M->errorStatus; },
    []()->unsigned char& { return test_M->Timing.stopRequestedFlag; },
    { task_1 },
    slrealtime::getSegmentVector()
};

int main(int argc, char *argv[]) {
    return slrealtime::runModel(argc, argv, test_Info);
}
