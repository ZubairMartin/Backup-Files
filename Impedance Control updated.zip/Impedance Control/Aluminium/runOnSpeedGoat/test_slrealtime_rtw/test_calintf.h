#ifndef TEST_CALINTF_H
#define TEST_CALINTF_H
#include "SegmentInfo.hpp"

namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif
