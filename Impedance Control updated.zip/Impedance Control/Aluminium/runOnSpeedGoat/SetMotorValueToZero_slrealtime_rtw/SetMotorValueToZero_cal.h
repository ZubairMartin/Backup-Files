#ifndef RTW_HEADER_SetMotorValueToZero_cal_h_
#define RTW_HEADER_SetMotorValueToZero_cal_h_
#include "rtwtypes.h"
#include "SetMotorValueToZero_types.h"

/* Storage class 'PageSwitching', for system '<Root>' */
typedef struct {
  real_T CANWrite1_P1_Size[2];         /* Computed Parameter: CANWrite1_P1_Size
                                        * Referenced by: '<S3>/CAN Write1'
                                        */
  real_T CANWrite1_P1[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S3>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_e[2];      /* Computed Parameter: CANWrite1_P1_Size_e
                                       * Referenced by: '<S4>/CAN Write1'
                                       */
  real_T CANWrite1_P1_e[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S4>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_o[2];      /* Computed Parameter: CANWrite1_P1_Size_o
                                       * Referenced by: '<S5>/CAN Write1'
                                       */
  real_T CANWrite1_P1_n[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S5>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_o2[2];    /* Computed Parameter: CANWrite1_P1_Size_o2
                                      * Referenced by: '<S6>/CAN Write1'
                                      */
  real_T CANWrite1_P1_b[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S6>/CAN Write1'
      */
  real_T CANsetup_P1_Size[2];          /* Computed Parameter: CANsetup_P1_Size
                                        * Referenced by: '<S1>/CAN setup'
                                        */
  real_T CANsetup_P1[40];
  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S1>/CAN setup'
   */
  real_T CANsetup_P2_Size[2];          /* Computed Parameter: CANsetup_P2_Size
                                        * Referenced by: '<S1>/CAN setup'
                                        */
  real_T CANsetup_P2;                  /* Expression: initStruct
                                        * Referenced by: '<S1>/CAN setup'
                                        */
  real_T CANsetup_P3_Size[2];          /* Computed Parameter: CANsetup_P3_Size
                                        * Referenced by: '<S1>/CAN setup'
                                        */
  real_T CANsetup_P3[31];              /* Expression: termStruct
                                        * Referenced by: '<S1>/CAN setup'
                                        */
  real_T Step3_Time;                   /* Expression: 2
                                        * Referenced by: '<S2>/Step3'
                                        */
  real_T Step3_Y0;                     /* Expression: 0
                                        * Referenced by: '<S2>/Step3'
                                        */
  real_T Step3_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S2>/Step3'
                                        */
  real_T Step_Time;                    /* Expression: 1.0
                                        * Referenced by: '<S2>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<S2>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 1
                                        * Referenced by: '<S2>/Step'
                                        */
  real_T Step4_Time;                   /* Expression: 1.5
                                        * Referenced by: '<S2>/Step4'
                                        */
  real_T Step4_Y0;                     /* Expression: 0
                                        * Referenced by: '<S2>/Step4'
                                        */
  real_T Step4_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S2>/Step4'
                                        */
  real_T Step1_Time;                   /* Expression: 0.5
                                        * Referenced by: '<S2>/Step1'
                                        */
  real_T Step1_Y0;                     /* Expression: 0
                                        * Referenced by: '<S2>/Step1'
                                        */
  real_T Step1_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S2>/Step1'
                                        */
  uint8_T Constant_Value;              /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S3>/Constant'
                                        */
  uint8_T Constant1_Value;             /* Computed Parameter: Constant1_Value
                                        * Referenced by: '<S3>/Constant1'
                                        */
  uint8_T Constant2_Value;             /* Computed Parameter: Constant2_Value
                                        * Referenced by: '<S3>/Constant2'
                                        */
  uint8_T Constant3_Value;             /* Computed Parameter: Constant3_Value
                                        * Referenced by: '<S3>/Constant3'
                                        */
  uint8_T Constant4_Value;             /* Computed Parameter: Constant4_Value
                                        * Referenced by: '<S3>/Constant4'
                                        */
  uint8_T Constant5_Value;             /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S3>/Constant5'
                                        */
  uint8_T Constant6_Value;             /* Computed Parameter: Constant6_Value
                                        * Referenced by: '<S3>/Constant6'
                                        */
  uint8_T Constant7_Value;             /* Computed Parameter: Constant7_Value
                                        * Referenced by: '<S3>/Constant7'
                                        */
  uint8_T Constant_Value_c;            /* Computed Parameter: Constant_Value_c
                                        * Referenced by: '<S4>/Constant'
                                        */
  uint8_T Constant1_Value_g;           /* Computed Parameter: Constant1_Value_g
                                        * Referenced by: '<S4>/Constant1'
                                        */
  uint8_T Constant2_Value_b;           /* Computed Parameter: Constant2_Value_b
                                        * Referenced by: '<S4>/Constant2'
                                        */
  uint8_T Constant3_Value_e;           /* Computed Parameter: Constant3_Value_e
                                        * Referenced by: '<S4>/Constant3'
                                        */
  uint8_T Constant4_Value_k;           /* Computed Parameter: Constant4_Value_k
                                        * Referenced by: '<S4>/Constant4'
                                        */
  uint8_T Constant5_Value_j;           /* Computed Parameter: Constant5_Value_j
                                        * Referenced by: '<S4>/Constant5'
                                        */
  uint8_T Constant6_Value_o;           /* Computed Parameter: Constant6_Value_o
                                        * Referenced by: '<S4>/Constant6'
                                        */
  uint8_T Constant7_Value_e;           /* Computed Parameter: Constant7_Value_e
                                        * Referenced by: '<S4>/Constant7'
                                        */
  uint8_T Constant_Value_d;            /* Computed Parameter: Constant_Value_d
                                        * Referenced by: '<S5>/Constant'
                                        */
  uint8_T Constant1_Value_p;           /* Computed Parameter: Constant1_Value_p
                                        * Referenced by: '<S5>/Constant1'
                                        */
  uint8_T Constant2_Value_c;           /* Computed Parameter: Constant2_Value_c
                                        * Referenced by: '<S5>/Constant2'
                                        */
  uint8_T Constant3_Value_l;           /* Computed Parameter: Constant3_Value_l
                                        * Referenced by: '<S5>/Constant3'
                                        */
  uint8_T Constant4_Value_o;           /* Computed Parameter: Constant4_Value_o
                                        * Referenced by: '<S5>/Constant4'
                                        */
  uint8_T Constant5_Value_a;           /* Computed Parameter: Constant5_Value_a
                                        * Referenced by: '<S5>/Constant5'
                                        */
  uint8_T Constant6_Value_i;           /* Computed Parameter: Constant6_Value_i
                                        * Referenced by: '<S5>/Constant6'
                                        */
  uint8_T Constant7_Value_k;           /* Computed Parameter: Constant7_Value_k
                                        * Referenced by: '<S5>/Constant7'
                                        */
  uint8_T Constant_Value_n;            /* Computed Parameter: Constant_Value_n
                                        * Referenced by: '<S6>/Constant'
                                        */
  uint8_T Constant1_Value_j;           /* Computed Parameter: Constant1_Value_j
                                        * Referenced by: '<S6>/Constant1'
                                        */
  uint8_T Constant2_Value_j;           /* Computed Parameter: Constant2_Value_j
                                        * Referenced by: '<S6>/Constant2'
                                        */
  uint8_T Constant3_Value_f;           /* Computed Parameter: Constant3_Value_f
                                        * Referenced by: '<S6>/Constant3'
                                        */
  uint8_T Constant4_Value_c;           /* Computed Parameter: Constant4_Value_c
                                        * Referenced by: '<S6>/Constant4'
                                        */
  uint8_T Constant5_Value_g;           /* Computed Parameter: Constant5_Value_g
                                        * Referenced by: '<S6>/Constant5'
                                        */
  uint8_T Constant6_Value_od;          /* Computed Parameter: Constant6_Value_od
                                        * Referenced by: '<S6>/Constant6'
                                        */
  uint8_T Constant7_Value_n;           /* Computed Parameter: Constant7_Value_n
                                        * Referenced by: '<S6>/Constant7'
                                        */
} SetMotorValueToZero_cal_type;

/* Storage class 'PageSwitching' */

/* Storage class 'PageSwitching' */
extern SetMotorValueToZero_cal_type SetMotorValueToZero_cal_impl;
extern SetMotorValueToZero_cal_type *SetMotorValueToZero_cal;

#endif                               /* RTW_HEADER_SetMotorValueToZero_cal_h_ */
