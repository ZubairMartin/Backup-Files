#include "SetMotorValueToZero.h"

/* Storage class 'PageSwitching' */

/* Storage class 'PageSwitching' */
SetMotorValueToZero_cal_type SetMotorValueToZero_cal_impl = {
  /* Computed Parameter: CANWrite1_P1_Size
   * Referenced by: '<S3>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S3>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_e
   * Referenced by: '<S4>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S4>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_o
   * Referenced by: '<S5>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S5>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_o2
   * Referenced by: '<S6>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S6>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANsetup_P1_Size
   * Referenced by: '<S1>/CAN setup'
   */
  { 1.0, 40.0 },

  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S1>/CAN setup'
   */
  { 691.0, 1.0, -1.0, -1.0, 2.0, 2.0, 8.0, 31.0, 8.0, 2.0, 8.0, 31.0, 8.0, 1.0,
    2.0, 8.0, 31.0, 8.0, 2.0, 8.0, 31.0, 8.0, 1.0, 2.0, 8.0, 31.0, 8.0, 2.0, 2.0,
    5.0, 2.0, 1.0, 2.0, 8.0, 31.0, 8.0, 2.0, 2.0, 5.0, 2.0 },

  /* Computed Parameter: CANsetup_P2_Size
   * Referenced by: '<S1>/CAN setup'
   */
  { 1.0, 1.0 },

  /* Expression: initStruct
   * Referenced by: '<S1>/CAN setup'
   */
  0.0,

  /* Computed Parameter: CANsetup_P3_Size
   * Referenced by: '<S1>/CAN setup'
   */
  { 1.0, 31.0 },

  /* Expression: termStruct
   * Referenced by: '<S1>/CAN setup'
   */
  { 2.0, 0.0, 1.0, 0.0, 2.0, 8.0, 0.0, 255.0, 255.0, 255.0, 255.0, 255.0, 255.0,
    255.0, 253.0, 0.001, 0.0, 1.0, 0.0, 3.0, 8.0, 0.0, 255.0, 255.0, 255.0,
    255.0, 255.0, 255.0, 255.0, 253.0, 0.001 },

  /* Expression: 2
   * Referenced by: '<S2>/Step3'
   */
  2.0,

  /* Expression: 0
   * Referenced by: '<S2>/Step3'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Step3'
   */
  1.0,

  /* Expression: 1.0
   * Referenced by: '<S2>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S2>/Step'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Step'
   */
  1.0,

  /* Expression: 1.5
   * Referenced by: '<S2>/Step4'
   */
  1.5,

  /* Expression: 0
   * Referenced by: '<S2>/Step4'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Step4'
   */
  1.0,

  /* Expression: 0.5
   * Referenced by: '<S2>/Step1'
   */
  0.5,

  /* Expression: 0
   * Referenced by: '<S2>/Step1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Step1'
   */
  1.0,

  /* Computed Parameter: Constant_Value
   * Referenced by: '<S3>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value
   * Referenced by: '<S3>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value
   * Referenced by: '<S3>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value
   * Referenced by: '<S3>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value
   * Referenced by: '<S3>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value
   * Referenced by: '<S3>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value
   * Referenced by: '<S3>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value
   * Referenced by: '<S3>/Constant7'
   */
  252U,

  /* Computed Parameter: Constant_Value_c
   * Referenced by: '<S4>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_g
   * Referenced by: '<S4>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_b
   * Referenced by: '<S4>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_e
   * Referenced by: '<S4>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_k
   * Referenced by: '<S4>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_j
   * Referenced by: '<S4>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_o
   * Referenced by: '<S4>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_e
   * Referenced by: '<S4>/Constant7'
   */
  252U,

  /* Computed Parameter: Constant_Value_d
   * Referenced by: '<S5>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_p
   * Referenced by: '<S5>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_c
   * Referenced by: '<S5>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_l
   * Referenced by: '<S5>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_o
   * Referenced by: '<S5>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_a
   * Referenced by: '<S5>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_i
   * Referenced by: '<S5>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_k
   * Referenced by: '<S5>/Constant7'
   */
  254U,

  /* Computed Parameter: Constant_Value_n
   * Referenced by: '<S6>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_j
   * Referenced by: '<S6>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_j
   * Referenced by: '<S6>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_f
   * Referenced by: '<S6>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_c
   * Referenced by: '<S6>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_g
   * Referenced by: '<S6>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_od
   * Referenced by: '<S6>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_n
   * Referenced by: '<S6>/Constant7'
   */
  254U
};

SetMotorValueToZero_cal_type *SetMotorValueToZero_cal =
  &SetMotorValueToZero_cal_impl;
