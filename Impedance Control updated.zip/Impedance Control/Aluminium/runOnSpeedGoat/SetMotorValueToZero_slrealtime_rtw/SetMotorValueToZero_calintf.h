#ifndef SETMOTORVALUETOZERO_CALINTF_H
#define SETMOTORVALUETOZERO_CALINTF_H
#include "SegmentInfo.hpp"

namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif
