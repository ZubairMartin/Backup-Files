/* Main generated for Simulink Real-Time model SetMotorValueToZero */
#include <ModelInfo.hpp>
#include "SetMotorValueToZero.h"
#include "SetMotorValueToZero_calintf.h"

/* Task descriptors */
slrealtime::TaskInfo task_1( 0u, std::bind(SetMotorValueToZero_step), slrealtime::TaskInfo::PERIODIC, 0.001, 0, 40);

/* Model descriptor */
slrealtime::ModelInfo SetMotorValueToZero_Info =
{
    "SetMotorValueToZero",
    SetMotorValueToZero_initialize,
    SetMotorValueToZero_terminate,
    []()->char const*& { return SetMotorValueToZero_M->errorStatus; },
    []()->unsigned char& { return SetMotorValueToZero_M->Timing.stopRequestedFlag; },
    { task_1 },
    slrealtime::getSegmentVector()
};

int main(int argc, char *argv[]) {
    return slrealtime::runModel(argc, argv, SetMotorValueToZero_Info);
}
