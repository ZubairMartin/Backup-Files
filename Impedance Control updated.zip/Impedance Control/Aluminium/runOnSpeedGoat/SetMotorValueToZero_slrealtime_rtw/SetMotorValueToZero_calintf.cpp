#include "SetMotorValueToZero_calintf.h"
#include "SetMotorValueToZero.h"
#include "SetMotorValueToZero_cal.h"

extern SetMotorValueToZero_cal_type SetMotorValueToZero_cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    {
      (void*)&SetMotorValueToZero_cal_impl, (void**)&SetMotorValueToZero_cal,
        sizeof(SetMotorValueToZero_cal_type), 2
    } };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime
