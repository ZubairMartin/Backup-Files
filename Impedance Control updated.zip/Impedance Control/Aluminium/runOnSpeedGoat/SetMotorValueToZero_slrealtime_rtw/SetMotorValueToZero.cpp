/*
 * SetMotorValueToZero.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SetMotorValueToZero".
 *
 * Model version              : 1.225
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Fri May 13 16:15:32 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SetMotorValueToZero.h"
#include "SetMotorValueToZero_private.h"

/* Block signals (default storage) */
B_SetMotorValueToZero_T SetMotorValueToZero_B;

/* Block states (default storage) */
DW_SetMotorValueToZero_T SetMotorValueToZero_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_SetMotorValueToZero_T SetMotorValueToZero_PrevZCX;

/* Real-time model */
RT_MODEL_SetMotorValueToZero_T SetMotorValueToZero_M_ =
  RT_MODEL_SetMotorValueToZero_T();
RT_MODEL_SetMotorValueToZero_T *const SetMotorValueToZero_M =
  &SetMotorValueToZero_M_;

/* Model step function */
void SetMotorValueToZero_step(void)
{
  real_T currentTime;
  ZCEventType zcEvent;

  /* Reset subsysRan breadcrumbs */
  srClearBC(SetMotorValueToZero_DW.EnterMotorControlModeM2_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC(SetMotorValueToZero_DW.EnterMotorControlModeM3_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC(SetMotorValueToZero_DW.SetOriginM2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(SetMotorValueToZero_DW.SetOriginM3_SubsysRanBC);

  /* S-Function (sg_IO602_IO691_setup_s): '<S1>/CAN setup' */

  /* Level2 S-Function Block: '<S1>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[4];
    sfcnOutputs(rts,0);
  }

  /* Step: '<S2>/Step3' */
  currentTime = SetMotorValueToZero_M->Timing.t[0];
  if (currentTime < SetMotorValueToZero_cal->Step3_Time) {
    /* Step: '<S2>/Step3' */
    SetMotorValueToZero_B.Step3 = SetMotorValueToZero_cal->Step3_Y0;
  } else {
    /* Step: '<S2>/Step3' */
    SetMotorValueToZero_B.Step3 = SetMotorValueToZero_cal->Step3_YFinal;
  }

  /* End of Step: '<S2>/Step3' */

  /* Outputs for Triggered SubSystem: '<S2>/Enter Motor Control Mode M2' incorporates:
   *  TriggerPort: '<S3>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &SetMotorValueToZero_PrevZCX.EnterMotorControlModeM2_Trig_ZC,
                     (SetMotorValueToZero_B.Step3));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S3>/CAN Pack1' incorporates:
     *  Constant: '<S3>/Constant'
     *  Constant: '<S3>/Constant1'
     *  Constant: '<S3>/Constant2'
     *  Constant: '<S3>/Constant3'
     *  Constant: '<S3>/Constant4'
     *  Constant: '<S3>/Constant5'
     *  Constant: '<S3>/Constant6'
     *  Constant: '<S3>/Constant7'
     */
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[0] =
      SetMotorValueToZero_cal->Constant_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[1] =
      SetMotorValueToZero_cal->Constant1_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[2] =
      SetMotorValueToZero_cal->Constant2_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[3] =
      SetMotorValueToZero_cal->Constant3_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[4] =
      SetMotorValueToZero_cal->Constant4_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[5] =
      SetMotorValueToZero_cal->Constant5_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[6] =
      SetMotorValueToZero_cal->Constant6_Value;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh[7] =
      SetMotorValueToZero_cal->Constant7_Value;

    /* S-Function (scanpack): '<S3>/CAN Pack1' */
    /* S-Function (scanpack): '<S3>/CAN Pack1' */
    SetMotorValueToZero_B.CANPack1_n.ID = 2U;
    SetMotorValueToZero_B.CANPack1_n.Length = 8U;
    SetMotorValueToZero_B.CANPack1_n.Extended = 0U;
    SetMotorValueToZero_B.CANPack1_n.Remote = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[0] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[1] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[2] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[3] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[4] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[5] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[6] = 0;
    SetMotorValueToZero_B.CANPack1_n.Data[7] = 0;

    {
      (void) std::memcpy((SetMotorValueToZero_B.CANPack1_n.Data),
                         &SetMotorValueToZero_B.TmpSignalConversionAtCANPac_bhh
                         [0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S3>/CAN Write1' */

    /* Level2 S-Function Block: '<S3>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[0];
      sfcnOutputs(rts,0);
    }

    SetMotorValueToZero_DW.EnterMotorControlModeM2_SubsysR = 4;
  }

  /* End of Outputs for SubSystem: '<S2>/Enter Motor Control Mode M2' */

  /* Step: '<S2>/Step' */
  currentTime = SetMotorValueToZero_M->Timing.t[0];
  if (currentTime < SetMotorValueToZero_cal->Step_Time) {
    /* Step: '<S2>/Step' */
    SetMotorValueToZero_B.Step = SetMotorValueToZero_cal->Step_Y0;
  } else {
    /* Step: '<S2>/Step' */
    SetMotorValueToZero_B.Step = SetMotorValueToZero_cal->Step_YFinal;
  }

  /* End of Step: '<S2>/Step' */

  /* Outputs for Triggered SubSystem: '<S2>/Enter Motor Control Mode M3' incorporates:
   *  TriggerPort: '<S4>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &SetMotorValueToZero_PrevZCX.EnterMotorControlModeM3_Trig_ZC,
                     (SetMotorValueToZero_B.Step));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S4>/CAN Pack1' incorporates:
     *  Constant: '<S4>/Constant'
     *  Constant: '<S4>/Constant1'
     *  Constant: '<S4>/Constant2'
     *  Constant: '<S4>/Constant3'
     *  Constant: '<S4>/Constant4'
     *  Constant: '<S4>/Constant5'
     *  Constant: '<S4>/Constant6'
     *  Constant: '<S4>/Constant7'
     */
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[0] =
      SetMotorValueToZero_cal->Constant_Value_c;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[1] =
      SetMotorValueToZero_cal->Constant1_Value_g;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[2] =
      SetMotorValueToZero_cal->Constant2_Value_b;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[3] =
      SetMotorValueToZero_cal->Constant3_Value_e;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[4] =
      SetMotorValueToZero_cal->Constant4_Value_k;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[5] =
      SetMotorValueToZero_cal->Constant5_Value_j;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[6] =
      SetMotorValueToZero_cal->Constant6_Value_o;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh[7] =
      SetMotorValueToZero_cal->Constant7_Value_e;

    /* S-Function (scanpack): '<S4>/CAN Pack1' */
    /* S-Function (scanpack): '<S4>/CAN Pack1' */
    SetMotorValueToZero_B.CANPack1_i.ID = 3U;
    SetMotorValueToZero_B.CANPack1_i.Length = 8U;
    SetMotorValueToZero_B.CANPack1_i.Extended = 0U;
    SetMotorValueToZero_B.CANPack1_i.Remote = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[0] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[1] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[2] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[3] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[4] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[5] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[6] = 0;
    SetMotorValueToZero_B.CANPack1_i.Data[7] = 0;

    {
      (void) std::memcpy((SetMotorValueToZero_B.CANPack1_i.Data),
                         &SetMotorValueToZero_B.TmpSignalConversionAtCANPack_bh
                         [0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S4>/CAN Write1' */

    /* Level2 S-Function Block: '<S4>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[1];
      sfcnOutputs(rts,0);
    }

    SetMotorValueToZero_DW.EnterMotorControlModeM3_SubsysR = 4;
  }

  /* End of Outputs for SubSystem: '<S2>/Enter Motor Control Mode M3' */

  /* Step: '<S2>/Step4' */
  currentTime = SetMotorValueToZero_M->Timing.t[0];
  if (currentTime < SetMotorValueToZero_cal->Step4_Time) {
    /* Step: '<S2>/Step4' */
    SetMotorValueToZero_B.Step4 = SetMotorValueToZero_cal->Step4_Y0;
  } else {
    /* Step: '<S2>/Step4' */
    SetMotorValueToZero_B.Step4 = SetMotorValueToZero_cal->Step4_YFinal;
  }

  /* End of Step: '<S2>/Step4' */

  /* Outputs for Triggered SubSystem: '<S2>/Set Origin M2' incorporates:
   *  TriggerPort: '<S5>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &SetMotorValueToZero_PrevZCX.SetOriginM2_Trig_ZCE,
                     (SetMotorValueToZero_B.Step4));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S5>/CAN Pack1' incorporates:
     *  Constant: '<S5>/Constant'
     *  Constant: '<S5>/Constant1'
     *  Constant: '<S5>/Constant2'
     *  Constant: '<S5>/Constant3'
     *  Constant: '<S5>/Constant4'
     *  Constant: '<S5>/Constant5'
     *  Constant: '<S5>/Constant6'
     *  Constant: '<S5>/Constant7'
     */
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[0] =
      SetMotorValueToZero_cal->Constant_Value_d;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[1] =
      SetMotorValueToZero_cal->Constant1_Value_p;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[2] =
      SetMotorValueToZero_cal->Constant2_Value_c;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[3] =
      SetMotorValueToZero_cal->Constant3_Value_l;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[4] =
      SetMotorValueToZero_cal->Constant4_Value_o;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[5] =
      SetMotorValueToZero_cal->Constant5_Value_a;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[6] =
      SetMotorValueToZero_cal->Constant6_Value_i;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b[7] =
      SetMotorValueToZero_cal->Constant7_Value_k;

    /* S-Function (scanpack): '<S5>/CAN Pack1' */
    /* S-Function (scanpack): '<S5>/CAN Pack1' */
    SetMotorValueToZero_B.CANPack1_p.ID = 2U;
    SetMotorValueToZero_B.CANPack1_p.Length = 8U;
    SetMotorValueToZero_B.CANPack1_p.Extended = 0U;
    SetMotorValueToZero_B.CANPack1_p.Remote = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[0] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[1] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[2] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[3] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[4] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[5] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[6] = 0;
    SetMotorValueToZero_B.CANPack1_p.Data[7] = 0;

    {
      (void) std::memcpy((SetMotorValueToZero_B.CANPack1_p.Data),
                         &SetMotorValueToZero_B.TmpSignalConversionAtCANPack1_b
                         [0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S5>/CAN Write1' */

    /* Level2 S-Function Block: '<S5>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[2];
      sfcnOutputs(rts,0);
    }

    SetMotorValueToZero_DW.SetOriginM2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S2>/Set Origin M2' */

  /* Step: '<S2>/Step1' */
  currentTime = SetMotorValueToZero_M->Timing.t[0];
  if (currentTime < SetMotorValueToZero_cal->Step1_Time) {
    /* Step: '<S2>/Step1' */
    SetMotorValueToZero_B.Step1 = SetMotorValueToZero_cal->Step1_Y0;
  } else {
    /* Step: '<S2>/Step1' */
    SetMotorValueToZero_B.Step1 = SetMotorValueToZero_cal->Step1_YFinal;
  }

  /* End of Step: '<S2>/Step1' */

  /* Outputs for Triggered SubSystem: '<S2>/Set Origin M3' incorporates:
   *  TriggerPort: '<S6>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &SetMotorValueToZero_PrevZCX.SetOriginM3_Trig_ZCE,
                     (SetMotorValueToZero_B.Step1));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S6>/CAN Pack1' incorporates:
     *  Constant: '<S6>/Constant'
     *  Constant: '<S6>/Constant1'
     *  Constant: '<S6>/Constant2'
     *  Constant: '<S6>/Constant3'
     *  Constant: '<S6>/Constant4'
     *  Constant: '<S6>/Constant5'
     *  Constant: '<S6>/Constant6'
     *  Constant: '<S6>/Constant7'
     */
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[0] =
      SetMotorValueToZero_cal->Constant_Value_n;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[1] =
      SetMotorValueToZero_cal->Constant1_Value_j;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[2] =
      SetMotorValueToZero_cal->Constant2_Value_j;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[3] =
      SetMotorValueToZero_cal->Constant3_Value_f;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[4] =
      SetMotorValueToZero_cal->Constant4_Value_c;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[5] =
      SetMotorValueToZero_cal->Constant5_Value_g;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[6] =
      SetMotorValueToZero_cal->Constant6_Value_od;
    SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In[7] =
      SetMotorValueToZero_cal->Constant7_Value_n;

    /* S-Function (scanpack): '<S6>/CAN Pack1' */
    /* S-Function (scanpack): '<S6>/CAN Pack1' */
    SetMotorValueToZero_B.CANPack1.ID = 3U;
    SetMotorValueToZero_B.CANPack1.Length = 8U;
    SetMotorValueToZero_B.CANPack1.Extended = 0U;
    SetMotorValueToZero_B.CANPack1.Remote = 0;
    SetMotorValueToZero_B.CANPack1.Data[0] = 0;
    SetMotorValueToZero_B.CANPack1.Data[1] = 0;
    SetMotorValueToZero_B.CANPack1.Data[2] = 0;
    SetMotorValueToZero_B.CANPack1.Data[3] = 0;
    SetMotorValueToZero_B.CANPack1.Data[4] = 0;
    SetMotorValueToZero_B.CANPack1.Data[5] = 0;
    SetMotorValueToZero_B.CANPack1.Data[6] = 0;
    SetMotorValueToZero_B.CANPack1.Data[7] = 0;

    {
      (void) std::memcpy((SetMotorValueToZero_B.CANPack1.Data),
                         &SetMotorValueToZero_B.TmpSignalConversionAtCANPack1In
                         [0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S6>/CAN Write1' */

    /* Level2 S-Function Block: '<S6>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[3];
      sfcnOutputs(rts,0);
    }

    SetMotorValueToZero_DW.SetOriginM3_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S2>/Set Origin M3' */

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++SetMotorValueToZero_M->Timing.clockTick0)) {
    ++SetMotorValueToZero_M->Timing.clockTickH0;
  }

  SetMotorValueToZero_M->Timing.t[0] = SetMotorValueToZero_M->Timing.clockTick0 *
    SetMotorValueToZero_M->Timing.stepSize0 +
    SetMotorValueToZero_M->Timing.clockTickH0 *
    SetMotorValueToZero_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void SetMotorValueToZero_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  rtsiSetSolverName(&SetMotorValueToZero_M->solverInfo,"FixedStepDiscrete");
  SetMotorValueToZero_M->solverInfoPtr = (&SetMotorValueToZero_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = SetMotorValueToZero_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    SetMotorValueToZero_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    SetMotorValueToZero_M->Timing.sampleTimes =
      (&SetMotorValueToZero_M->Timing.sampleTimesArray[0]);
    SetMotorValueToZero_M->Timing.offsetTimes =
      (&SetMotorValueToZero_M->Timing.offsetTimesArray[0]);

    /* task periods */
    SetMotorValueToZero_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    SetMotorValueToZero_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(SetMotorValueToZero_M, &SetMotorValueToZero_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = SetMotorValueToZero_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    SetMotorValueToZero_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(SetMotorValueToZero_M, -1);
  SetMotorValueToZero_M->Timing.stepSize0 = 0.001;
  SetMotorValueToZero_M->solverInfoPtr = (&SetMotorValueToZero_M->solverInfo);
  SetMotorValueToZero_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&SetMotorValueToZero_M->solverInfo, 0.001);
  rtsiSetSolverMode(&SetMotorValueToZero_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) std::memset((static_cast<void *>(&SetMotorValueToZero_B)), 0,
                     sizeof(B_SetMotorValueToZero_T));

  {
    SetMotorValueToZero_B.CANPack1 = CAN_DATATYPE_GROUND;
    SetMotorValueToZero_B.CANPack1_p = CAN_DATATYPE_GROUND;
    SetMotorValueToZero_B.CANPack1_i = CAN_DATATYPE_GROUND;
    SetMotorValueToZero_B.CANPack1_n = CAN_DATATYPE_GROUND;
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&SetMotorValueToZero_DW), 0,
                     sizeof(DW_SetMotorValueToZero_T));

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &SetMotorValueToZero_M->NonInlinedSFcns.sfcnInfo;
    SetMotorValueToZero_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(SetMotorValueToZero_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &SetMotorValueToZero_M->Sizes.numSampTimes);
    SetMotorValueToZero_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (SetMotorValueToZero_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,SetMotorValueToZero_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(SetMotorValueToZero_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(SetMotorValueToZero_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (SetMotorValueToZero_M));
    rtssSetStepSizePtr(sfcnInfo, &SetMotorValueToZero_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(SetMotorValueToZero_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &SetMotorValueToZero_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &SetMotorValueToZero_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &SetMotorValueToZero_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &SetMotorValueToZero_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &SetMotorValueToZero_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &SetMotorValueToZero_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &SetMotorValueToZero_M->solverInfoPtr);
  }

  SetMotorValueToZero_M->Sizes.numSFcns = (5);

  /* register each child */
  {
    (void) std::memset(static_cast<void *>
                       (&SetMotorValueToZero_M->NonInlinedSFcns.childSFunctions
                        [0]), 0,
                       5*sizeof(SimStruct));
    SetMotorValueToZero_M->childSfunctions =
      (&SetMotorValueToZero_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 5; i++) {
        SetMotorValueToZero_M->childSfunctions[i] =
          (&SetMotorValueToZero_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: SetMotorValueToZero/<S3>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &SetMotorValueToZero_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &SetMotorValueToZero_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, SetMotorValueToZero_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &SetMotorValueToZero_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &SetMotorValueToZero_B.CANPack1_n);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "SetMotorValueToZero/Motor Setup/Motor Setup/Enter Motor Control Mode M2/CAN Write1");
      ssSetRTModel(rts,SetMotorValueToZero_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       SetMotorValueToZero_cal->CANWrite1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &SetMotorValueToZero_DW.CANWrite1_PWORK_e);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &SetMotorValueToZero_DW.CANWrite1_PWORK_e);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: SetMotorValueToZero/<S4>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &SetMotorValueToZero_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &SetMotorValueToZero_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, SetMotorValueToZero_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &SetMotorValueToZero_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &SetMotorValueToZero_B.CANPack1_i);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "SetMotorValueToZero/Motor Setup/Motor Setup/Enter Motor Control Mode M3/CAN Write1");
      ssSetRTModel(rts,SetMotorValueToZero_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       SetMotorValueToZero_cal->CANWrite1_P1_Size_e);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &SetMotorValueToZero_DW.CANWrite1_PWORK_k);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &SetMotorValueToZero_DW.CANWrite1_PWORK_k);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: SetMotorValueToZero/<S5>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &SetMotorValueToZero_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &SetMotorValueToZero_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, SetMotorValueToZero_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &SetMotorValueToZero_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &SetMotorValueToZero_B.CANPack1_p);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "SetMotorValueToZero/Motor Setup/Motor Setup/Set Origin M2/CAN Write1");
      ssSetRTModel(rts,SetMotorValueToZero_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       SetMotorValueToZero_cal->CANWrite1_P1_Size_o);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &SetMotorValueToZero_DW.CANWrite1_PWORK_p);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &SetMotorValueToZero_DW.CANWrite1_PWORK_p);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: SetMotorValueToZero/<S6>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &SetMotorValueToZero_M->NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &SetMotorValueToZero_M->NonInlinedSFcns.inputOutputPortInfo2[3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, SetMotorValueToZero_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &SetMotorValueToZero_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &SetMotorValueToZero_B.CANPack1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "SetMotorValueToZero/Motor Setup/Motor Setup/Set Origin M3/CAN Write1");
      ssSetRTModel(rts,SetMotorValueToZero_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       SetMotorValueToZero_cal->CANWrite1_P1_Size_o2);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &SetMotorValueToZero_DW.CANWrite1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &SetMotorValueToZero_DW.CANWrite1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: SetMotorValueToZero/<S1>/CAN setup (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts = SetMotorValueToZero_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        SetMotorValueToZero_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = SetMotorValueToZero_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &SetMotorValueToZero_M->NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &SetMotorValueToZero_M->NonInlinedSFcns.inputOutputPortInfo2[4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, SetMotorValueToZero_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &SetMotorValueToZero_M->
                           NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &SetMotorValueToZero_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &SetMotorValueToZero_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* path info */
      ssSetModelName(rts, "CAN setup");
      ssSetPath(rts, "SetMotorValueToZero/Motor Setup/CAN setup");
      ssSetRTModel(rts,SetMotorValueToZero_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       SetMotorValueToZero_cal->CANsetup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       SetMotorValueToZero_cal->CANsetup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       SetMotorValueToZero_cal->CANsetup_P3_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &SetMotorValueToZero_DW.CANsetup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &SetMotorValueToZero_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &SetMotorValueToZero_DW.CANsetup_PWORK);
      }

      /* registration */
      sg_IO602_IO691_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Start for S-Function (sg_IO602_IO691_setup_s): '<S1>/CAN setup' */
  /* Level2 S-Function Block: '<S1>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[4];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  SetMotorValueToZero_PrevZCX.EnterMotorControlModeM2_Trig_ZC =
    UNINITIALIZED_ZCSIG;
  SetMotorValueToZero_PrevZCX.EnterMotorControlModeM3_Trig_ZC =
    UNINITIALIZED_ZCSIG;
  SetMotorValueToZero_PrevZCX.SetOriginM2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  SetMotorValueToZero_PrevZCX.SetOriginM3_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* SystemInitialize for Triggered SubSystem: '<S2>/Enter Motor Control Mode M2' */

  /* Start for S-Function (sg_IO602_IO691_write_s): '<S3>/CAN Write1' */
  /* Level2 S-Function Block: '<S3>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S2>/Enter Motor Control Mode M2' */

  /* SystemInitialize for Triggered SubSystem: '<S2>/Enter Motor Control Mode M3' */

  /* Start for S-Function (sg_IO602_IO691_write_s): '<S4>/CAN Write1' */
  /* Level2 S-Function Block: '<S4>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S2>/Enter Motor Control Mode M3' */

  /* SystemInitialize for Triggered SubSystem: '<S2>/Set Origin M2' */

  /* Start for S-Function (sg_IO602_IO691_write_s): '<S5>/CAN Write1' */
  /* Level2 S-Function Block: '<S5>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S2>/Set Origin M2' */

  /* SystemInitialize for Triggered SubSystem: '<S2>/Set Origin M3' */

  /* Start for S-Function (sg_IO602_IO691_write_s): '<S6>/CAN Write1' */
  /* Level2 S-Function Block: '<S6>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[3];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S2>/Set Origin M3' */
}

/* Model terminate function */
void SetMotorValueToZero_terminate(void)
{
  /* Terminate for S-Function (sg_IO602_IO691_setup_s): '<S1>/CAN setup' */
  /* Level2 S-Function Block: '<S1>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Terminate for Triggered SubSystem: '<S2>/Enter Motor Control Mode M2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S3>/CAN Write1' */
  /* Level2 S-Function Block: '<S3>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S2>/Enter Motor Control Mode M2' */

  /* Terminate for Triggered SubSystem: '<S2>/Enter Motor Control Mode M3' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S4>/CAN Write1' */
  /* Level2 S-Function Block: '<S4>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S2>/Enter Motor Control Mode M3' */

  /* Terminate for Triggered SubSystem: '<S2>/Set Origin M2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S5>/CAN Write1' */
  /* Level2 S-Function Block: '<S5>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S2>/Set Origin M2' */

  /* Terminate for Triggered SubSystem: '<S2>/Set Origin M3' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S6>/CAN Write1' */
  /* Level2 S-Function Block: '<S6>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = SetMotorValueToZero_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S2>/Set Origin M3' */
}
