/*
 * TestKinematics.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TestKinematics".
 *
 * Model version              : 1.84
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Thu May  5 12:05:50 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TestKinematics_h_
#define RTW_HEADER_TestKinematics_h_
#include <stddef.h>
#include <cstring>
#include <cfloat>
#include <cmath>
#include <math.h>
#include <string.h>
#include <logsrv.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "verify/verifyIntrf.h"
#include "can_message.h"
#include "TestKinematics_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Child system includes */
#include "TestKinematics_cal.h"
#include "rt_zcfcn.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetSampleHitArray
#define rtmGetSampleHitArray(rtm)      ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmGetStepSize
#define rtmGetStepSize(rtm)            ((rtm)->Timing.stepSize)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
#define rtmGet_TimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef rtmGetTimeOfLastOutput
#define rtmGetTimeOfLastOutput(rtm)    ((rtm)->Timing.timeOfLastOutput)
#endif

/* user code (top of export header file) */
#include "can_message.h"

/* Block signals for system '<S10>/Enabled Subsystem' */
typedef struct {
  real_T motorID;       /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MP_8H;         /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MP_8L;         /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MS_8H;         /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MS_4L;         /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MC_4H;         /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
  real_T MC_8L;         /* '<S15>/BusConversion_InsertedFor_Out1_at_inport_0' */
} B_EnabledSubsystem_TestKinema_T;

/* Block states (default storage) for system '<S10>/Enabled Subsystem' */
typedef struct {
  int8_T EnabledSubsystem_SubsysRanBC; /* '<S10>/Enabled Subsystem' */
} DW_EnabledSubsystem_TestKinem_T;

/* Block signals for system '<S10>/MATLAB Function2' */
typedef struct {
  real_T final_pos;                    /* '<S10>/MATLAB Function2' */
  real_T final_vel;                    /* '<S10>/MATLAB Function2' */
  real_T final_i;                      /* '<S10>/MATLAB Function2' */
} B_MATLABFunction2_TestKinemat_T;

/* Block signals for system '<S11>/MATLAB Function' */
typedef struct {
  real_T P8H;                          /* '<S11>/MATLAB Function' */
  real_T V8H;                          /* '<S11>/MATLAB Function' */
  real_T KP4H;                         /* '<S11>/MATLAB Function' */
  real_T KD8H;                         /* '<S11>/MATLAB Function' */
  real_T T4H;                          /* '<S11>/MATLAB Function' */
  uint8_T P8L;                         /* '<S11>/MATLAB Function' */
  uint8_T V4L;                         /* '<S11>/MATLAB Function' */
  uint8_T KP8L;                        /* '<S11>/MATLAB Function' */
  uint8_T KD4L;                        /* '<S11>/MATLAB Function' */
  uint8_T T8L;                         /* '<S11>/MATLAB Function' */
} B_MATLABFunction_TestKinemati_T;

/* Block signals (default storage) */
typedef struct {
  CAN_DATATYPE CANPack3;               /* '<S13>/CAN Pack3' */
  CAN_DATATYPE CANRead1_o2;            /* '<S12>/CAN Read1' */
  CAN_DATATYPE CANPack3_m;             /* '<S11>/CAN Pack3' */
  CAN_DATATYPE CANRead1_o2_d;          /* '<S10>/CAN Read1' */
  CAN_DATATYPE CANPack1;               /* '<S9>/CAN Pack1' */
  CAN_DATATYPE CANPack1_p;             /* '<S8>/CAN Pack1' */
  CAN_DATATYPE CANPack1_j;             /* '<S7>/CAN Pack1' */
  CAN_DATATYPE CANPack1_j3;            /* '<S6>/CAN Pack1' */
  real_T Step3;                        /* '<S5>/Step3' */
  real_T Step;                         /* '<S5>/Step' */
  real_T Step4;                        /* '<S5>/Step4' */
  real_T Step1;                        /* '<S5>/Step1' */
  real_T r1;                           /* '<S3>/Read 1' */
  real_T r2;                           /* '<S3>/Read 2' */
  real_T changevaluefourtimeseverysecond;
                           /* '<Root>/change value four  times every second ' */
  real_T w1;                           /* '<S3>/Write 1' */
  real_T w2;                           /* '<S3>/Write 2' */
  real_T Memory1;                      /* '<S23>/Memory1' */
  real_T counter;                      /* '<S23>/Add1' */
  real_T Mod1;                         /* '<S23>/Mod1' */
  real_T index;                        /* '<S23>/MATLAB Function1' */
  real_T theta1;                     /* '<S4>/Increment through  theta array' */
  real_T theta2;                     /* '<S4>/Increment through  theta array' */
  real_T motorID;                      /* '<S12>/CAN Unpack3' */
  real_T MP_8H;                        /* '<S12>/CAN Unpack3' */
  real_T MP_8L;                        /* '<S12>/CAN Unpack3' */
  real_T MS_8H;                        /* '<S12>/CAN Unpack3' */
  real_T MS_4L;                        /* '<S12>/CAN Unpack3' */
  real_T MC_4H;                        /* '<S12>/CAN Unpack3' */
  real_T MC_8L;                        /* '<S12>/CAN Unpack3' */
  real_T motorID_k;                    /* '<S10>/CAN Unpack3' */
  real_T MP_8H_o;                      /* '<S10>/CAN Unpack3' */
  real_T MP_8L_m;                      /* '<S10>/CAN Unpack3' */
  real_T MS_8H_j;                      /* '<S10>/CAN Unpack3' */
  real_T MS_4L_e;                      /* '<S10>/CAN Unpack3' */
  real_T MC_4H_d;                      /* '<S10>/CAN Unpack3' */
  real_T MC_8L_d;                      /* '<S10>/CAN Unpack3' */
  real_T X_foot;                       /* '<Root>/MATLAB Function' */
  real_T Y_foot;                       /* '<Root>/MATLAB Function' */
  uint8_T TmpSignalConversionAtCANPack1In[8];
  uint8_T TmpSignalConversionAtCANPack1_b[8];
  uint8_T TmpSignalConversionAtCANPack_bh[8];
  uint8_T TmpSignalConversionAtCANPac_bhh[8];
  boolean_T CANRead1_o1;               /* '<S12>/CAN Read1' */
  boolean_T Compare;                   /* '<S18>/Compare' */
  boolean_T CANRead1_o1_g;             /* '<S10>/CAN Read1' */
  boolean_T Compare_l;                 /* '<S14>/Compare' */
  B_MATLABFunction_TestKinemati_T sf_MATLABFunction_kk;/* '<S13>/MATLAB Function' */
  B_MATLABFunction2_TestKinemat_T sf_MATLABFunction2_f;/* '<S12>/MATLAB Function2' */
  B_EnabledSubsystem_TestKinema_T EnabledSubsystem_d;/* '<S12>/Enabled Subsystem' */
  B_MATLABFunction_TestKinemati_T sf_MATLABFunction_k;/* '<S11>/MATLAB Function' */
  B_MATLABFunction2_TestKinemat_T sf_MATLABFunction2;/* '<S10>/MATLAB Function2' */
  B_EnabledSubsystem_TestKinema_T EnabledSubsystem;/* '<S10>/Enabled Subsystem' */
} B_TestKinematics_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T Memory1_PreviousInput;        /* '<S23>/Memory1' */
  void *CANsetup_PWORK;                /* '<S2>/CAN setup' */
  struct {
    void *LoggedData[2];
  } Scope_PWORK;                       /* '<Root>/Scope' */

  struct {
    void *LoggedData;
  } ToWorkspace_PWORK;                 /* '<Root>/To Workspace' */

  struct {
    void *LoggedData;
  } ToWorkspace1_PWORK;                /* '<Root>/To Workspace1' */

  void *CANWrite1_PWORK;               /* '<S13>/CAN Write1' */
  void *CANRead1_PWORK;                /* '<S12>/CAN Read1' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MATLA;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_g;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_h;   /* synthesized block */

  void *CANWrite1_PWORK_a;             /* '<S11>/CAN Write1' */
  void *CANRead1_PWORK_a;              /* '<S10>/CAN Read1' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_b;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MA_gp;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MA_h1;   /* synthesized block */

  void *CANWrite1_PWORK_g;             /* '<S9>/CAN Write1' */
  void *CANWrite1_PWORK_gn;            /* '<S8>/CAN Write1' */
  void *CANWrite1_PWORK_i;             /* '<S7>/CAN Write1' */
  void *CANWrite1_PWORK_ii;            /* '<S6>/CAN Write1' */
  int32_T clockTickCounter;            /* '<S3>/Read 1' */
  int32_T clockTickCounter_i;          /* '<S3>/Read 2' */
  int32_T clockTickCounter_b;
                           /* '<Root>/change value four  times every second ' */
  int32_T clockTickCounter_h;          /* '<S3>/Write 1' */
  int32_T clockTickCounter_m;          /* '<S3>/Write 2' */
  int_T CANPack3_ModeSignalID;         /* '<S13>/CAN Pack3' */
  int_T CANUnpack3_ModeSignalID;       /* '<S12>/CAN Unpack3' */
  int_T CANUnpack3_StatusPortID;       /* '<S12>/CAN Unpack3' */
  int_T CANPack3_ModeSignalID_h;       /* '<S11>/CAN Pack3' */
  int_T CANUnpack3_ModeSignalID_f;     /* '<S10>/CAN Unpack3' */
  int_T CANUnpack3_StatusPortID_f;     /* '<S10>/CAN Unpack3' */
  int8_T TriggeredSubsystem_SubsysRanBC;/* '<Root>/Triggered Subsystem' */
  int8_T Motor3WriteTHETA1_SubsysRanBC;/* '<S3>/Motor 3 Write - THETA1' */
  int8_T Motor3ReadTHETA1_SubsysRanBC; /* '<S3>/Motor 3 Read - THETA1' */
  int8_T Motor2WriteTHETA2_SubsysRanBC;/* '<S3>/Motor 2 Write - THETA2' */
  int8_T Motor2ReadTHETA2_SubsysRanBC; /* '<S3>/Motor 2 Read - THETA2' */
  int8_T SetOriginM3_SubsysRanBC;      /* '<S5>/Set Origin M3' */
  int8_T SetOriginM2_SubsysRanBC;      /* '<S5>/Set Origin M2' */
  int8_T EnterMotorControlModeM3_SubsysR;/* '<S5>/Enter Motor Control Mode M3' */
  int8_T EnterMotorControlModeM2_SubsysR;/* '<S5>/Enter Motor Control Mode M2' */
  DW_EnabledSubsystem_TestKinem_T EnabledSubsystem_d;/* '<S12>/Enabled Subsystem' */
  DW_EnabledSubsystem_TestKinem_T EnabledSubsystem;/* '<S10>/Enabled Subsystem' */
} DW_TestKinematics_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<Root>/Triggered Subsystem' */
  ZCSigState Motor3WriteTHETA1_Trig_ZCE;/* '<S3>/Motor 3 Write - THETA1' */
  ZCSigState Motor3ReadTHETA1_Trig_ZCE;/* '<S3>/Motor 3 Read - THETA1' */
  ZCSigState Motor2WriteTHETA2_Trig_ZCE;/* '<S3>/Motor 2 Write - THETA2' */
  ZCSigState Motor2ReadTHETA2_Trig_ZCE;/* '<S3>/Motor 2 Read - THETA2' */
  ZCSigState SetOriginM3_Trig_ZCE;     /* '<S5>/Set Origin M3' */
  ZCSigState SetOriginM2_Trig_ZCE;     /* '<S5>/Set Origin M2' */
  ZCSigState EnterMotorControlModeM3_Trig_ZC;/* '<S5>/Enter Motor Control Mode M3' */
  ZCSigState EnterMotorControlModeM2_Trig_ZC;/* '<S5>/Enter Motor Control Mode M2' */
} PrevZCX_TestKinematics_T;

/* Parameters (default storage) */
struct P_TestKinematics_T_ {
  real_T theta1_final[120];            /* Variable: theta1_final
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T theta2_final[120];            /* Variable: theta2_final
                                        * Referenced by: '<Root>/Constant2'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_TestKinematics_T {
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[1];
    SimStruct childSFunctions[9];
    SimStruct *childSFunctionPtrs[9];
    struct _ssBlkInfo2 blkInfo2[9];
    struct _ssSFcnModelMethods2 methods2[9];
    struct _ssSFcnModelMethods3 methods3[9];
    struct _ssSFcnModelMethods4 methods4[9];
    struct _ssStatesInfo2 statesInfo2[9];
    ssPeriodicStatesInfo periodicStatesInfo[9];
    struct _ssPortInfo2 inputOutputPortInfo2[9];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn3;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn4;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn5;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn6;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn7;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[3];
      mxArray *params[3];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn8;
  } NonInlinedSFcns;

  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T options;
    int_T numContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[1];
    time_T offsetTimesArray[1];
    int_T sampleTimeTaskIDArray[1];
    int_T sampleHitArray[1];
    int_T perTaskSampleHitsArray[1];
    time_T tArray[1];
  } Timing;
};

/* Block parameters (default storage) */
#ifdef __cplusplus

extern "C" {

#endif

  extern P_TestKinematics_T TestKinematics_P;

#ifdef __cplusplus

}
#endif

/* Block signals (default storage) */
#ifdef __cplusplus

extern "C" {

#endif

  extern B_TestKinematics_T TestKinematics_B;

#ifdef __cplusplus

}
#endif

/* Block states (default storage) */
extern DW_TestKinematics_T TestKinematics_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_TestKinematics_T TestKinematics_PrevZCX;

#ifdef __cplusplus

extern "C" {

#endif

  /* Model entry point functions */
  extern void TestKinematics_initialize(void);
  extern void TestKinematics_step(void);
  extern void TestKinematics_terminate(void);

#ifdef __cplusplus

}
#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_TestKinematics_T *const TestKinematics_M;

#ifdef __cplusplus

}
#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'TestKinematics'
 * '<S1>'   : 'TestKinematics/MATLAB Function'
 * '<S2>'   : 'TestKinematics/Motor Setup'
 * '<S3>'   : 'TestKinematics/Subsystem1'
 * '<S4>'   : 'TestKinematics/Triggered Subsystem'
 * '<S5>'   : 'TestKinematics/Motor Setup/Motor Setup'
 * '<S6>'   : 'TestKinematics/Motor Setup/Motor Setup/Enter Motor Control Mode M2'
 * '<S7>'   : 'TestKinematics/Motor Setup/Motor Setup/Enter Motor Control Mode M3'
 * '<S8>'   : 'TestKinematics/Motor Setup/Motor Setup/Set Origin M2'
 * '<S9>'   : 'TestKinematics/Motor Setup/Motor Setup/Set Origin M3'
 * '<S10>'  : 'TestKinematics/Subsystem1/Motor 2 Read - THETA2'
 * '<S11>'  : 'TestKinematics/Subsystem1/Motor 2 Write - THETA2'
 * '<S12>'  : 'TestKinematics/Subsystem1/Motor 3 Read - THETA1'
 * '<S13>'  : 'TestKinematics/Subsystem1/Motor 3 Write - THETA1'
 * '<S14>'  : 'TestKinematics/Subsystem1/Motor 2 Read - THETA2/Compare To Constant'
 * '<S15>'  : 'TestKinematics/Subsystem1/Motor 2 Read - THETA2/Enabled Subsystem'
 * '<S16>'  : 'TestKinematics/Subsystem1/Motor 2 Read - THETA2/MATLAB Function2'
 * '<S17>'  : 'TestKinematics/Subsystem1/Motor 2 Write - THETA2/MATLAB Function'
 * '<S18>'  : 'TestKinematics/Subsystem1/Motor 3 Read - THETA1/Compare To Constant'
 * '<S19>'  : 'TestKinematics/Subsystem1/Motor 3 Read - THETA1/Enabled Subsystem'
 * '<S20>'  : 'TestKinematics/Subsystem1/Motor 3 Read - THETA1/MATLAB Function2'
 * '<S21>'  : 'TestKinematics/Subsystem1/Motor 3 Write - THETA1/MATLAB Function'
 * '<S22>'  : 'TestKinematics/Triggered Subsystem/Increment through  theta array'
 * '<S23>'  : 'TestKinematics/Triggered Subsystem/counter (rotation every 10 seconds -  set simTime =  3 + 3rev*(10) = 15 seconds and points = 10)'
 * '<S24>'  : 'TestKinematics/Triggered Subsystem/counter (rotation every 10 seconds -  set simTime =  3 + 3rev*(10) = 15 seconds and points = 10)/MATLAB Function1'
 */
#endif                                 /* RTW_HEADER_TestKinematics_h_ */
