#ifndef TESTKINEMATICS_CALINTF_H
#define TESTKINEMATICS_CALINTF_H
#include "SegmentInfo.hpp"

namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif
