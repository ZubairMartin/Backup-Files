#include "TestKinematics.h"

/* Storage class 'PageSwitching' */

/* Storage class 'PageSwitching' */
TestKinematics_cal_type TestKinematics_cal_impl = {
  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S14>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_b
   * Referenced by: '<S18>/Constant'
   */
  3.0,

  /* Computed Parameter: CANWrite1_P1_Size
   * Referenced by: '<S6>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S6>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_n
   * Referenced by: '<S7>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S7>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_c
   * Referenced by: '<S8>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S8>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: CANWrite1_P1_Size_j
   * Referenced by: '<S9>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S9>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: motor2position_Y0
   * Referenced by: '<S10>/motor 2 position'
   */
  0.0,

  /* Computed Parameter: CANRead1_P1_Size
   * Referenced by: '<S10>/CAN Read1'
   */
  { 1.0, 6.0 },

  /* Expression: [initValues(1:4) messageType initValues(6)]
   * Referenced by: '<S10>/CAN Read1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0 },

  /* Computed Parameter: CANWrite1_P1_Size_f
   * Referenced by: '<S11>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S11>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: motor3position_Y0
   * Referenced by: '<S12>/motor 3 position'
   */
  0.0,

  /* Computed Parameter: CANRead1_P1_Size_n
   * Referenced by: '<S12>/CAN Read1'
   */
  { 1.0, 6.0 },

  /* Expression: [initValues(1:4) messageType initValues(6)]
   * Referenced by: '<S12>/CAN Read1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0 },

  /* Computed Parameter: CANWrite1_P1_Size_e
   * Referenced by: '<S13>/CAN Write1'
   */
  { 1.0, 7.0 },

  /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
   * Referenced by: '<S13>/CAN Write1'
   */
  { 691.0, 1.0, -1.0, 0.0, 1.0, 1.0, 0.0 },

  /* Computed Parameter: theta1_Y0
   * Referenced by: '<S4>/theta1'
   */
  0.0,

  /* Computed Parameter: theta2_Y0
   * Referenced by: '<S4>/theta2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S23>/Memory1'
   */
  0.0,

  /* Expression: 5.001*10^3
   * Referenced by: '<S23>/Reset counter  (Max value of first rotation counter)1'
   */
  5001.0,

  /* Computed Parameter: CANsetup_P1_Size
   * Referenced by: '<S2>/CAN setup'
   */
  { 1.0, 40.0 },

  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S2>/CAN setup'
   */
  { 691.0, 1.0, -1.0, -1.0, 2.0, 2.0, 8.0, 31.0, 8.0, 2.0, 8.0, 31.0, 8.0, 1.0,
    2.0, 8.0, 31.0, 8.0, 2.0, 8.0, 31.0, 8.0, 1.0, 2.0, 8.0, 31.0, 8.0, 2.0, 2.0,
    5.0, 2.0, 1.0, 2.0, 8.0, 31.0, 8.0, 2.0, 2.0, 5.0, 2.0 },

  /* Computed Parameter: CANsetup_P2_Size
   * Referenced by: '<S2>/CAN setup'
   */
  { 1.0, 1.0 },

  /* Expression: initStruct
   * Referenced by: '<S2>/CAN setup'
   */
  0.0,

  /* Computed Parameter: CANsetup_P3_Size
   * Referenced by: '<S2>/CAN setup'
   */
  { 1.0, 31.0 },

  /* Expression: termStruct
   * Referenced by: '<S2>/CAN setup'
   */
  { 2.0, 0.0, 1.0, 0.0, 2.0, 8.0, 0.0, 255.0, 255.0, 255.0, 255.0, 255.0, 255.0,
    255.0, 253.0, 0.001, 0.0, 1.0, 0.0, 3.0, 8.0, 0.0, 255.0, 255.0, 255.0,
    255.0, 255.0, 255.0, 255.0, 253.0, 0.001 },

  /* Expression: 2
   * Referenced by: '<S5>/Step3'
   */
  2.0,

  /* Expression: 0
   * Referenced by: '<S5>/Step3'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S5>/Step3'
   */
  1.0,

  /* Expression: 1.0
   * Referenced by: '<S5>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S5>/Step'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S5>/Step'
   */
  1.0,

  /* Expression: 1.5
   * Referenced by: '<S5>/Step4'
   */
  1.5,

  /* Expression: 0
   * Referenced by: '<S5>/Step4'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S5>/Step4'
   */
  1.0,

  /* Expression: 0.5
   * Referenced by: '<S5>/Step1'
   */
  0.5,

  /* Expression: 0
   * Referenced by: '<S5>/Step1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S5>/Step1'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S3>/Read 1'
   */
  1.0,

  /* Computed Parameter: Read1_Period
   * Referenced by: '<S3>/Read 1'
   */
  4.0,

  /* Computed Parameter: Read1_Duty
   * Referenced by: '<S3>/Read 1'
   */
  2.0,

  /* Expression: 3.001
   * Referenced by: '<S3>/Read 1'
   */
  3.001,

  /* Expression: 1
   * Referenced by: '<S3>/Read 2'
   */
  1.0,

  /* Computed Parameter: Read2_Period
   * Referenced by: '<S3>/Read 2'
   */
  4.0,

  /* Computed Parameter: Read2_Duty
   * Referenced by: '<S3>/Read 2'
   */
  2.0,

  /* Expression: 3.003
   * Referenced by: '<S3>/Read 2'
   */
  3.003,

  /* Expression: 1
   * Referenced by: '<Root>/start counter'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<Root>/change value four  times every second '
   */
  1.0,

  /* Computed Parameter: changevaluefourtimeseveryseco_b
   * Referenced by: '<Root>/change value four  times every second '
   */
  2.0,

  /* Computed Parameter: changevaluefourtimeseveryseco_j
   * Referenced by: '<Root>/change value four  times every second '
   */
  1.0,

  /* Expression: 3
   * Referenced by: '<Root>/change value four  times every second '
   */
  3.0,

  /* Expression: 0
   * Referenced by: '<S3>/Constant2'
   */
  0.0,

  /* Expression: 7
   * Referenced by: '<S3>/Constant3'
   */
  7.0,

  /* Expression: 0.2
   * Referenced by: '<S3>/Constant4'
   */
  0.2,

  /* Expression: 0
   * Referenced by: '<S3>/Constant1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S3>/Write 1'
   */
  1.0,

  /* Computed Parameter: Write1_Period
   * Referenced by: '<S3>/Write 1'
   */
  4.0,

  /* Computed Parameter: Write1_Duty
   * Referenced by: '<S3>/Write 1'
   */
  2.0,

  /* Expression: 3
   * Referenced by: '<S3>/Write 1'
   */
  3.0,

  /* Expression: 0
   * Referenced by: '<S3>/Constant6'
   */
  0.0,

  /* Expression: 7
   * Referenced by: '<S3>/Constant7'
   */
  7.0,

  /* Expression: 0.2
   * Referenced by: '<S3>/Constant8'
   */
  0.2,

  /* Expression: 0
   * Referenced by: '<S3>/Constant5'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S3>/Write 2'
   */
  1.0,

  /* Computed Parameter: Write2_Period
   * Referenced by: '<S3>/Write 2'
   */
  4.0,

  /* Computed Parameter: Write2_Duty
   * Referenced by: '<S3>/Write 2'
   */
  2.0,

  /* Expression: 3.002
   * Referenced by: '<S3>/Write 2'
   */
  3.002,

  /* Computed Parameter: Constant_Value
   * Referenced by: '<S6>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_e
   * Referenced by: '<S6>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_b
   * Referenced by: '<S6>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_b
   * Referenced by: '<S6>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_k
   * Referenced by: '<S6>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_m
   * Referenced by: '<S6>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_l
   * Referenced by: '<S6>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_b
   * Referenced by: '<S6>/Constant7'
   */
  252U,

  /* Computed Parameter: Constant_Value_l
   * Referenced by: '<S7>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_i
   * Referenced by: '<S7>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_c
   * Referenced by: '<S7>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_c
   * Referenced by: '<S7>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_d
   * Referenced by: '<S7>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_h
   * Referenced by: '<S7>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_lm
   * Referenced by: '<S7>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_e
   * Referenced by: '<S7>/Constant7'
   */
  252U,

  /* Computed Parameter: Constant_Value_a
   * Referenced by: '<S8>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_j
   * Referenced by: '<S8>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_i
   * Referenced by: '<S8>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_n
   * Referenced by: '<S8>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_kf
   * Referenced by: '<S8>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_mp
   * Referenced by: '<S8>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_l1
   * Referenced by: '<S8>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_m
   * Referenced by: '<S8>/Constant7'
   */
  254U,

  /* Computed Parameter: Constant_Value_b
   * Referenced by: '<S9>/Constant'
   */
  255U,

  /* Computed Parameter: Constant1_Value_jj
   * Referenced by: '<S9>/Constant1'
   */
  255U,

  /* Computed Parameter: Constant2_Value_h
   * Referenced by: '<S9>/Constant2'
   */
  255U,

  /* Computed Parameter: Constant3_Value_cx
   * Referenced by: '<S9>/Constant3'
   */
  255U,

  /* Computed Parameter: Constant4_Value_p
   * Referenced by: '<S9>/Constant4'
   */
  255U,

  /* Computed Parameter: Constant5_Value_i
   * Referenced by: '<S9>/Constant5'
   */
  255U,

  /* Computed Parameter: Constant6_Value_lp
   * Referenced by: '<S9>/Constant6'
   */
  255U,

  /* Computed Parameter: Constant7_Value_j
   * Referenced by: '<S9>/Constant7'
   */
  254U,

  /* Start of '<S12>/Enabled Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S19>/Out1'
     */
    {
      0.0,                             /* motor_ID */
      0.0,                             /* MP_8H */
      0.0,                             /* MP_8L */
      0.0,                             /* MS_8H */
      0.0,                             /* MS_4L */
      0.0,                             /* MC_4H */
      0.0                              /* MC_8L */
    }
  }
  ,

  /* End of '<S12>/Enabled Subsystem' */

  /* Start of '<S10>/Enabled Subsystem' */
  {
    /* Computed Parameter: Out1_Y0
     * Referenced by: '<S15>/Out1'
     */
    {
      0.0,                             /* motor_ID */
      0.0,                             /* MP_8H */
      0.0,                             /* MP_8L */
      0.0,                             /* MS_8H */
      0.0,                             /* MS_4L */
      0.0,                             /* MC_4H */
      0.0                              /* MC_8L */
    }
  }
  /* End of '<S10>/Enabled Subsystem' */
};

TestKinematics_cal_type *TestKinematics_cal = &TestKinematics_cal_impl;
