/*
 * TestKinematics.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TestKinematics".
 *
 * Model version              : 1.84
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C++ source code generated on : Thu May  5 12:05:50 2022
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "TestKinematics.h"
#include "TestKinematics_private.h"

/* Block signals (default storage) */
B_TestKinematics_T TestKinematics_B;

/* Block states (default storage) */
DW_TestKinematics_T TestKinematics_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_TestKinematics_T TestKinematics_PrevZCX;

/* Real-time model */
RT_MODEL_TestKinematics_T TestKinematics_M_ = RT_MODEL_TestKinematics_T();
RT_MODEL_TestKinematics_T *const TestKinematics_M = &TestKinematics_M_;

/*
 * System initialize for enable system:
 *    '<S10>/Enabled Subsystem'
 *    '<S12>/Enabled Subsystem'
 */
void TestKinem_EnabledSubsystem_Init(B_EnabledSubsystem_TestKinema_T *localB,
  TestK_EnabledSubsystem_cal_type *TestKinematic_PageSwitching_arg)
{
  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->motorID = 0.0;

  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->MP_8H = TestKinematic_PageSwitching_arg->Out1_Y0.MP_8H;

  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->MP_8L = TestKinematic_PageSwitching_arg->Out1_Y0.MP_8L;

  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->MS_8H = TestKinematic_PageSwitching_arg->Out1_Y0.MS_8H;

  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->MS_4L = TestKinematic_PageSwitching_arg->Out1_Y0.MS_4L;

  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->MC_4H = TestKinematic_PageSwitching_arg->Out1_Y0.MC_4H;

  /* SystemInitialize for SignalConversion generated from: '<S15>/Out1' incorporates:
   *  Outport: '<S15>/Out1'
   */
  localB->MC_8L = TestKinematic_PageSwitching_arg->Out1_Y0.MC_8L;
}

/*
 * Output and update for enable system:
 *    '<S10>/Enabled Subsystem'
 *    '<S12>/Enabled Subsystem'
 */
void TestKinematics_EnabledSubsystem(boolean_T rtu_Enable, real_T rtu_In1,
  real_T rtu_In1_p, real_T rtu_In1_m, real_T rtu_In1_c, real_T rtu_In1_k, real_T
  rtu_In1_o, real_T rtu_In1_i, B_EnabledSubsystem_TestKinema_T *localB,
  DW_EnabledSubsystem_TestKinem_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S10>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S15>/Enable'
   */
  if (rtu_Enable) {
    /* SignalConversion generated from: '<S15>/Out1' */
    localB->motorID = rtu_In1;

    /* SignalConversion generated from: '<S15>/Out1' */
    localB->MP_8H = rtu_In1_p;

    /* SignalConversion generated from: '<S15>/Out1' */
    localB->MP_8L = rtu_In1_m;

    /* SignalConversion generated from: '<S15>/Out1' */
    localB->MS_8H = rtu_In1_c;

    /* SignalConversion generated from: '<S15>/Out1' */
    localB->MS_4L = rtu_In1_k;

    /* SignalConversion generated from: '<S15>/Out1' */
    localB->MC_4H = rtu_In1_o;

    /* SignalConversion generated from: '<S15>/Out1' */
    localB->MC_8L = rtu_In1_i;
    localDW->EnabledSubsystem_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S10>/Enabled Subsystem' */
}

/*
 * Output and update for atomic system:
 *    '<S10>/MATLAB Function2'
 *    '<S12>/MATLAB Function2'
 */
void TestKinematics_MATLABFunction2(real_T rtu_pos_h, real_T rtu_pos_l, real_T
  rtu_vel_h, real_T rtu_vel_l, real_T rtu_i_h, real_T rtu_i_l,
  B_MATLABFunction2_TestKinemat_T *localB)
{
  localB->final_pos = (static_cast<real_T>(static_cast<uint64_T>
    (static_cast<real_T>(static_cast<uint64_T>(rtu_pos_h) << 8)) |
    static_cast<uint64_T>(rtu_pos_l)) * 25.0 / 65535.0 - 12.5) * 4.0 *
    3.1415926535897931 / 12.5;
  localB->final_vel = static_cast<real_T>(static_cast<uint64_T>
    (static_cast<real_T>(static_cast<uint64_T>(rtu_vel_h) << 4)) |
    static_cast<uint64_T>(rtu_vel_l)) * 46.48 / 4095.0 - 23.24;
  localB->final_i = static_cast<real_T>(static_cast<uint64_T>(static_cast<real_T>
    (static_cast<uint64_T>(rtu_i_h) << 8)) | static_cast<uint64_T>(rtu_i_l)) *
    108.0 / 4095.0 - 54.0;
}

/*
 * Output and update for atomic system:
 *    '<S11>/MATLAB Function'
 *    '<S13>/MATLAB Function'
 */
void TestKinematics_MATLABFunction(real_T rtu_p_des, real_T rtu_v_des, real_T
  rtu_kp, real_T rtu_kd, real_T rtu_t_ff, B_MATLABFunction_TestKinemati_T
  *localB)
{
  real_T kd_int;
  real_T kp_int;
  real_T p_int;
  real_T t_int;
  real_T v_int;
  t_int = rtu_p_des;
  if (-12.5 < t_int) {
    p_int = t_int;
  } else {
    p_int = -12.5;
  }

  t_int = p_int;
  if (t_int > 12.5) {
    p_int = 12.5;
  }

  t_int = rtu_v_des;
  if (-50.0 < t_int) {
    v_int = t_int;
  } else {
    v_int = -50.0;
  }

  t_int = v_int;
  if (t_int > 50.0) {
    v_int = 50.0;
  }

  t_int = rtu_kp;
  if (0.0 < t_int) {
    kp_int = t_int;
  } else {
    kp_int = 0.0;
  }

  t_int = kp_int;
  if (t_int > 500.0) {
    kp_int = 500.0;
  }

  t_int = rtu_kd;
  if (0.0 < t_int) {
    kd_int = t_int;
  } else {
    kd_int = 0.0;
  }

  t_int = kd_int;
  if (t_int > 5.0) {
    kd_int = 5.0;
  }

  t_int = rtu_t_ff;
  if (!(-65.0 < t_int)) {
    t_int = -65.0;
  }

  if (t_int > 65.0) {
    t_int = 65.0;
  }

  p_int = (p_int - -12.5) * 2621.44;
  v_int = (v_int - -50.0) * 40.96;
  kp_int *= 8.192;
  kd_int *= 819.2;
  t_int = (t_int - -65.0) * 31.507692307692309;
  localB->P8H = static_cast<real_T>(static_cast<uint64_T>(p_int) >> 8);
  localB->P8L = static_cast<uint8_T>(p_int);
  localB->V8H = static_cast<real_T>(static_cast<uint64_T>(v_int) >> 4);
  localB->V4L = static_cast<uint8_T>(static_cast<uint8_T>(v_int) & 15);
  localB->KP4H = static_cast<real_T>(static_cast<uint64_T>(kp_int) >> 8);
  localB->KP8L = static_cast<uint8_T>(kp_int);
  localB->KD8H = static_cast<real_T>(static_cast<uint64_T>(kd_int) >> 4);
  localB->KD4L = static_cast<uint8_T>(static_cast<uint8_T>(kd_int) & 15);
  localB->T4H = static_cast<real_T>(static_cast<uint64_T>(t_int) >> 8);
  localB->T8L = static_cast<uint8_T>(t_int);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T tmp;
  int32_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u1 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u0 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(tmp_0), static_cast<real_T>(tmp));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T q;
  real_T y;
  boolean_T yEq;
  y = u0;
  if (u1 == 0.0) {
    if (u0 == 0.0) {
      y = u1;
    }
  } else if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (u0 == 0.0) {
    y = 0.0 / u1;
  } else if (rtIsInf(u1)) {
    if ((u1 < 0.0) != (u0 < 0.0)) {
      y = u1;
    }
  } else {
    y = std::fmod(u0, u1);
    yEq = (y == 0.0);
    if ((!yEq) && (u1 > std::floor(u1))) {
      q = std::abs(u0 / u1);
      yEq = !(std::abs(q - std::floor(q + 0.5)) > DBL_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0;
    } else {
      if ((u0 < 0.0) != (u1 < 0.0)) {
        y += u1;
      }
    }
  }

  return y;
}

/* Model step function */
void TestKinematics_step(void)
{
  real_T B1_idx_1;
  real_T B2_idx_0;
  real_T B2_idx_1;
  real_T a;
  ZCEventType zcEvent;

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.EnterMotorControlModeM2_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.EnterMotorControlModeM3_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.SetOriginM2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.SetOriginM3_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.EnabledSubsystem.EnabledSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.Motor2ReadTHETA2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.Motor2WriteTHETA2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.Motor3ReadTHETA1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.Motor3WriteTHETA1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(TestKinematics_DW.TriggeredSubsystem_SubsysRanBC);

  /* S-Function (sg_IO602_IO691_setup_s): '<S2>/CAN setup' */

  /* Level2 S-Function Block: '<S2>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[8];
    sfcnOutputs(rts,0);
  }

  /* Step: '<S5>/Step3' */
  a = TestKinematics_M->Timing.t[0];
  if (a < TestKinematics_cal->Step3_Time) {
    /* Step: '<S5>/Step3' */
    TestKinematics_B.Step3 = TestKinematics_cal->Step3_Y0;
  } else {
    /* Step: '<S5>/Step3' */
    TestKinematics_B.Step3 = TestKinematics_cal->Step3_YFinal;
  }

  /* End of Step: '<S5>/Step3' */

  /* Outputs for Triggered SubSystem: '<S5>/Enter Motor Control Mode M2' incorporates:
   *  TriggerPort: '<S6>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.EnterMotorControlModeM2_Trig_ZC,
                     (TestKinematics_B.Step3));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S6>/CAN Pack1' incorporates:
     *  Constant: '<S6>/Constant'
     *  Constant: '<S6>/Constant1'
     *  Constant: '<S6>/Constant2'
     *  Constant: '<S6>/Constant3'
     *  Constant: '<S6>/Constant4'
     *  Constant: '<S6>/Constant5'
     *  Constant: '<S6>/Constant6'
     *  Constant: '<S6>/Constant7'
     */
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[0] =
      TestKinematics_cal->Constant_Value;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[1] =
      TestKinematics_cal->Constant1_Value_e;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[2] =
      TestKinematics_cal->Constant2_Value_b;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[3] =
      TestKinematics_cal->Constant3_Value_b;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[4] =
      TestKinematics_cal->Constant4_Value_k;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[5] =
      TestKinematics_cal->Constant5_Value_m;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[6] =
      TestKinematics_cal->Constant6_Value_l;
    TestKinematics_B.TmpSignalConversionAtCANPac_bhh[7] =
      TestKinematics_cal->Constant7_Value_b;

    /* S-Function (scanpack): '<S6>/CAN Pack1' */
    /* S-Function (scanpack): '<S6>/CAN Pack1' */
    TestKinematics_B.CANPack1_j3.ID = 2U;
    TestKinematics_B.CANPack1_j3.Length = 8U;
    TestKinematics_B.CANPack1_j3.Extended = 0U;
    TestKinematics_B.CANPack1_j3.Remote = 0;
    TestKinematics_B.CANPack1_j3.Data[0] = 0;
    TestKinematics_B.CANPack1_j3.Data[1] = 0;
    TestKinematics_B.CANPack1_j3.Data[2] = 0;
    TestKinematics_B.CANPack1_j3.Data[3] = 0;
    TestKinematics_B.CANPack1_j3.Data[4] = 0;
    TestKinematics_B.CANPack1_j3.Data[5] = 0;
    TestKinematics_B.CANPack1_j3.Data[6] = 0;
    TestKinematics_B.CANPack1_j3.Data[7] = 0;

    {
      (void) std::memcpy((TestKinematics_B.CANPack1_j3.Data),
                         &TestKinematics_B.TmpSignalConversionAtCANPac_bhh[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S6>/CAN Write1' */

    /* Level2 S-Function Block: '<S6>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[0];
      sfcnOutputs(rts,0);
    }

    TestKinematics_DW.EnterMotorControlModeM2_SubsysR = 4;
  }

  /* End of Outputs for SubSystem: '<S5>/Enter Motor Control Mode M2' */

  /* Step: '<S5>/Step' */
  a = TestKinematics_M->Timing.t[0];
  if (a < TestKinematics_cal->Step_Time) {
    /* Step: '<S5>/Step' */
    TestKinematics_B.Step = TestKinematics_cal->Step_Y0;
  } else {
    /* Step: '<S5>/Step' */
    TestKinematics_B.Step = TestKinematics_cal->Step_YFinal;
  }

  /* End of Step: '<S5>/Step' */

  /* Outputs for Triggered SubSystem: '<S5>/Enter Motor Control Mode M3' incorporates:
   *  TriggerPort: '<S7>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.EnterMotorControlModeM3_Trig_ZC,
                     (TestKinematics_B.Step));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S7>/CAN Pack1' incorporates:
     *  Constant: '<S7>/Constant'
     *  Constant: '<S7>/Constant1'
     *  Constant: '<S7>/Constant2'
     *  Constant: '<S7>/Constant3'
     *  Constant: '<S7>/Constant4'
     *  Constant: '<S7>/Constant5'
     *  Constant: '<S7>/Constant6'
     *  Constant: '<S7>/Constant7'
     */
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[0] =
      TestKinematics_cal->Constant_Value_l;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[1] =
      TestKinematics_cal->Constant1_Value_i;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[2] =
      TestKinematics_cal->Constant2_Value_c;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[3] =
      TestKinematics_cal->Constant3_Value_c;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[4] =
      TestKinematics_cal->Constant4_Value_d;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[5] =
      TestKinematics_cal->Constant5_Value_h;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[6] =
      TestKinematics_cal->Constant6_Value_lm;
    TestKinematics_B.TmpSignalConversionAtCANPack_bh[7] =
      TestKinematics_cal->Constant7_Value_e;

    /* S-Function (scanpack): '<S7>/CAN Pack1' */
    /* S-Function (scanpack): '<S7>/CAN Pack1' */
    TestKinematics_B.CANPack1_j.ID = 3U;
    TestKinematics_B.CANPack1_j.Length = 8U;
    TestKinematics_B.CANPack1_j.Extended = 0U;
    TestKinematics_B.CANPack1_j.Remote = 0;
    TestKinematics_B.CANPack1_j.Data[0] = 0;
    TestKinematics_B.CANPack1_j.Data[1] = 0;
    TestKinematics_B.CANPack1_j.Data[2] = 0;
    TestKinematics_B.CANPack1_j.Data[3] = 0;
    TestKinematics_B.CANPack1_j.Data[4] = 0;
    TestKinematics_B.CANPack1_j.Data[5] = 0;
    TestKinematics_B.CANPack1_j.Data[6] = 0;
    TestKinematics_B.CANPack1_j.Data[7] = 0;

    {
      (void) std::memcpy((TestKinematics_B.CANPack1_j.Data),
                         &TestKinematics_B.TmpSignalConversionAtCANPack_bh[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S7>/CAN Write1' */

    /* Level2 S-Function Block: '<S7>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[1];
      sfcnOutputs(rts,0);
    }

    TestKinematics_DW.EnterMotorControlModeM3_SubsysR = 4;
  }

  /* End of Outputs for SubSystem: '<S5>/Enter Motor Control Mode M3' */

  /* Step: '<S5>/Step4' */
  a = TestKinematics_M->Timing.t[0];
  if (a < TestKinematics_cal->Step4_Time) {
    /* Step: '<S5>/Step4' */
    TestKinematics_B.Step4 = TestKinematics_cal->Step4_Y0;
  } else {
    /* Step: '<S5>/Step4' */
    TestKinematics_B.Step4 = TestKinematics_cal->Step4_YFinal;
  }

  /* End of Step: '<S5>/Step4' */

  /* Outputs for Triggered SubSystem: '<S5>/Set Origin M2' incorporates:
   *  TriggerPort: '<S8>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.SetOriginM2_Trig_ZCE,
                     (TestKinematics_B.Step4));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S8>/CAN Pack1' incorporates:
     *  Constant: '<S8>/Constant'
     *  Constant: '<S8>/Constant1'
     *  Constant: '<S8>/Constant2'
     *  Constant: '<S8>/Constant3'
     *  Constant: '<S8>/Constant4'
     *  Constant: '<S8>/Constant5'
     *  Constant: '<S8>/Constant6'
     *  Constant: '<S8>/Constant7'
     */
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[0] =
      TestKinematics_cal->Constant_Value_a;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[1] =
      TestKinematics_cal->Constant1_Value_j;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[2] =
      TestKinematics_cal->Constant2_Value_i;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[3] =
      TestKinematics_cal->Constant3_Value_n;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[4] =
      TestKinematics_cal->Constant4_Value_kf;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[5] =
      TestKinematics_cal->Constant5_Value_mp;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[6] =
      TestKinematics_cal->Constant6_Value_l1;
    TestKinematics_B.TmpSignalConversionAtCANPack1_b[7] =
      TestKinematics_cal->Constant7_Value_m;

    /* S-Function (scanpack): '<S8>/CAN Pack1' */
    /* S-Function (scanpack): '<S8>/CAN Pack1' */
    TestKinematics_B.CANPack1_p.ID = 2U;
    TestKinematics_B.CANPack1_p.Length = 8U;
    TestKinematics_B.CANPack1_p.Extended = 0U;
    TestKinematics_B.CANPack1_p.Remote = 0;
    TestKinematics_B.CANPack1_p.Data[0] = 0;
    TestKinematics_B.CANPack1_p.Data[1] = 0;
    TestKinematics_B.CANPack1_p.Data[2] = 0;
    TestKinematics_B.CANPack1_p.Data[3] = 0;
    TestKinematics_B.CANPack1_p.Data[4] = 0;
    TestKinematics_B.CANPack1_p.Data[5] = 0;
    TestKinematics_B.CANPack1_p.Data[6] = 0;
    TestKinematics_B.CANPack1_p.Data[7] = 0;

    {
      (void) std::memcpy((TestKinematics_B.CANPack1_p.Data),
                         &TestKinematics_B.TmpSignalConversionAtCANPack1_b[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S8>/CAN Write1' */

    /* Level2 S-Function Block: '<S8>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[2];
      sfcnOutputs(rts,0);
    }

    TestKinematics_DW.SetOriginM2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S5>/Set Origin M2' */

  /* Step: '<S5>/Step1' */
  a = TestKinematics_M->Timing.t[0];
  if (a < TestKinematics_cal->Step1_Time) {
    /* Step: '<S5>/Step1' */
    TestKinematics_B.Step1 = TestKinematics_cal->Step1_Y0;
  } else {
    /* Step: '<S5>/Step1' */
    TestKinematics_B.Step1 = TestKinematics_cal->Step1_YFinal;
  }

  /* End of Step: '<S5>/Step1' */

  /* Outputs for Triggered SubSystem: '<S5>/Set Origin M3' incorporates:
   *  TriggerPort: '<S9>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.SetOriginM3_Trig_ZCE,
                     (TestKinematics_B.Step1));
  if (zcEvent != NO_ZCEVENT) {
    /* SignalConversion generated from: '<S9>/CAN Pack1' incorporates:
     *  Constant: '<S9>/Constant'
     *  Constant: '<S9>/Constant1'
     *  Constant: '<S9>/Constant2'
     *  Constant: '<S9>/Constant3'
     *  Constant: '<S9>/Constant4'
     *  Constant: '<S9>/Constant5'
     *  Constant: '<S9>/Constant6'
     *  Constant: '<S9>/Constant7'
     */
    TestKinematics_B.TmpSignalConversionAtCANPack1In[0] =
      TestKinematics_cal->Constant_Value_b;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[1] =
      TestKinematics_cal->Constant1_Value_jj;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[2] =
      TestKinematics_cal->Constant2_Value_h;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[3] =
      TestKinematics_cal->Constant3_Value_cx;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[4] =
      TestKinematics_cal->Constant4_Value_p;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[5] =
      TestKinematics_cal->Constant5_Value_i;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[6] =
      TestKinematics_cal->Constant6_Value_lp;
    TestKinematics_B.TmpSignalConversionAtCANPack1In[7] =
      TestKinematics_cal->Constant7_Value_j;

    /* S-Function (scanpack): '<S9>/CAN Pack1' */
    /* S-Function (scanpack): '<S9>/CAN Pack1' */
    TestKinematics_B.CANPack1.ID = 3U;
    TestKinematics_B.CANPack1.Length = 8U;
    TestKinematics_B.CANPack1.Extended = 0U;
    TestKinematics_B.CANPack1.Remote = 0;
    TestKinematics_B.CANPack1.Data[0] = 0;
    TestKinematics_B.CANPack1.Data[1] = 0;
    TestKinematics_B.CANPack1.Data[2] = 0;
    TestKinematics_B.CANPack1.Data[3] = 0;
    TestKinematics_B.CANPack1.Data[4] = 0;
    TestKinematics_B.CANPack1.Data[5] = 0;
    TestKinematics_B.CANPack1.Data[6] = 0;
    TestKinematics_B.CANPack1.Data[7] = 0;

    {
      (void) std::memcpy((TestKinematics_B.CANPack1.Data),
                         &TestKinematics_B.TmpSignalConversionAtCANPack1In[0],
                         8 * sizeof(uint8_T));
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S9>/CAN Write1' */

    /* Level2 S-Function Block: '<S9>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[3];
      sfcnOutputs(rts,0);
    }

    TestKinematics_DW.SetOriginM3_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S5>/Set Origin M3' */

  /* DiscretePulseGenerator: '<S3>/Read 1' */
  TestKinematics_B.r1 = (TestKinematics_DW.clockTickCounter <
    TestKinematics_cal->Read1_Duty) && (TestKinematics_DW.clockTickCounter >= 0)
    ? TestKinematics_cal->Read1_Amp : 0.0;

  /* DiscretePulseGenerator: '<S3>/Read 1' */
  if (TestKinematics_DW.clockTickCounter >= TestKinematics_cal->Read1_Period -
      1.0) {
    TestKinematics_DW.clockTickCounter = 0;
  } else {
    TestKinematics_DW.clockTickCounter++;
  }

  /* Outputs for Triggered SubSystem: '<S3>/Motor 3 Read - THETA1' incorporates:
   *  TriggerPort: '<S12>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.Motor3ReadTHETA1_Trig_ZCE,
                     (TestKinematics_B.r1));
  if (zcEvent != NO_ZCEVENT) {
    /* S-Function (sg_IO602_IO691_read_s): '<S12>/CAN Read1' */

    /* Level2 S-Function Block: '<S12>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[6];
      sfcnOutputs(rts,0);
    }

    /* S-Function (scanunpack): '<S12>/CAN Unpack3' */
    {
      /* S-Function (scanunpack): '<S12>/CAN Unpack3' */
      if ((8 == TestKinematics_B.CANRead1_o2.Length) &&
          (TestKinematics_B.CANRead1_o2.ID != INVALID_CAN_ID) ) {
        if ((0 == TestKinematics_B.CANRead1_o2.ID) && (0U ==
             TestKinematics_B.CANRead1_o2.Extended) ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.motorID = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MP_8H = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 16
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[2]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MP_8L = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[3]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MS_8H = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 36
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[4]) & (uint8_T)(0xF0U))
                      >> 4);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MS_4L = result;
              }
            }

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 32
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[4]) & (uint8_T)(0xFU));
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MC_4H = result;
              }
            }

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 40
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2.Data[5]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MC_8L = result;
              }
            }
          }
        }
      }
    }

    /* RelationalOperator: '<S18>/Compare' incorporates:
     *  Constant: '<S18>/Constant'
     */
    TestKinematics_B.Compare = (TestKinematics_B.motorID ==
      TestKinematics_cal->CompareToConstant_const_b);

    /* Outputs for Enabled SubSystem: '<S12>/Enabled Subsystem' */
    TestKinematics_EnabledSubsystem(TestKinematics_B.Compare,
      TestKinematics_B.motorID, TestKinematics_B.MP_8H, TestKinematics_B.MP_8L,
      TestKinematics_B.MS_8H, TestKinematics_B.MS_4L, TestKinematics_B.MC_4H,
      TestKinematics_B.MC_8L, &TestKinematics_B.EnabledSubsystem_d,
      &TestKinematics_DW.EnabledSubsystem_d);

    /* End of Outputs for SubSystem: '<S12>/Enabled Subsystem' */

    /* MATLAB Function: '<S12>/MATLAB Function2' */
    TestKinematics_MATLABFunction2(TestKinematics_B.EnabledSubsystem_d.MP_8H,
      TestKinematics_B.EnabledSubsystem_d.MP_8L,
      TestKinematics_B.EnabledSubsystem_d.MS_8H,
      TestKinematics_B.EnabledSubsystem_d.MS_4L,
      TestKinematics_B.EnabledSubsystem_d.MC_4H,
      TestKinematics_B.EnabledSubsystem_d.MC_8L,
      &TestKinematics_B.sf_MATLABFunction2_f);
    TestKinematics_DW.Motor3ReadTHETA1_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S3>/Motor 3 Read - THETA1' */

  /* DiscretePulseGenerator: '<S3>/Read 2' */
  TestKinematics_B.r2 = (TestKinematics_DW.clockTickCounter_i <
    TestKinematics_cal->Read2_Duty) && (TestKinematics_DW.clockTickCounter_i >=
    0) ? TestKinematics_cal->Read2_Amp : 0.0;

  /* DiscretePulseGenerator: '<S3>/Read 2' */
  if (TestKinematics_DW.clockTickCounter_i >= TestKinematics_cal->Read2_Period -
      1.0) {
    TestKinematics_DW.clockTickCounter_i = 0;
  } else {
    TestKinematics_DW.clockTickCounter_i++;
  }

  /* Outputs for Triggered SubSystem: '<S3>/Motor 2 Read - THETA2' incorporates:
   *  TriggerPort: '<S10>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.Motor2ReadTHETA2_Trig_ZCE,
                     (TestKinematics_B.r2));
  if (zcEvent != NO_ZCEVENT) {
    /* S-Function (sg_IO602_IO691_read_s): '<S10>/CAN Read1' */

    /* Level2 S-Function Block: '<S10>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[4];
      sfcnOutputs(rts,0);
    }

    /* S-Function (scanunpack): '<S10>/CAN Unpack3' */
    {
      /* S-Function (scanunpack): '<S10>/CAN Unpack3' */
      if ((8 == TestKinematics_B.CANRead1_o2_d.Length) &&
          (TestKinematics_B.CANRead1_o2_d.ID != INVALID_CAN_ID) ) {
        if ((0 == TestKinematics_B.CANRead1_o2_d.ID) && (0U ==
             TestKinematics_B.CANRead1_o2_d.Extended) ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.motorID_k = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MP_8H_o = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 16
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[2]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MP_8L_m = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[3]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MS_8H_j = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 36
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[4]) & (uint8_T)(0xF0U))
                      >> 4);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MS_4L_e = result;
              }
            }

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 32
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[4]) & (uint8_T)(0xFU));
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MC_4H_d = result;
              }
            }

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 40
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (TestKinematics_B.CANRead1_o2_d.Data[5]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                TestKinematics_B.MC_8L_d = result;
              }
            }
          }
        }
      }
    }

    /* RelationalOperator: '<S14>/Compare' incorporates:
     *  Constant: '<S14>/Constant'
     */
    TestKinematics_B.Compare_l = (TestKinematics_B.motorID_k ==
      TestKinematics_cal->CompareToConstant_const);

    /* Outputs for Enabled SubSystem: '<S10>/Enabled Subsystem' */
    TestKinematics_EnabledSubsystem(TestKinematics_B.Compare_l,
      TestKinematics_B.motorID_k, TestKinematics_B.MP_8H_o,
      TestKinematics_B.MP_8L_m, TestKinematics_B.MS_8H_j,
      TestKinematics_B.MS_4L_e, TestKinematics_B.MC_4H_d,
      TestKinematics_B.MC_8L_d, &TestKinematics_B.EnabledSubsystem,
      &TestKinematics_DW.EnabledSubsystem);

    /* End of Outputs for SubSystem: '<S10>/Enabled Subsystem' */

    /* MATLAB Function: '<S10>/MATLAB Function2' */
    TestKinematics_MATLABFunction2(TestKinematics_B.EnabledSubsystem.MP_8H,
      TestKinematics_B.EnabledSubsystem.MP_8L,
      TestKinematics_B.EnabledSubsystem.MS_8H,
      TestKinematics_B.EnabledSubsystem.MS_4L,
      TestKinematics_B.EnabledSubsystem.MC_4H,
      TestKinematics_B.EnabledSubsystem.MC_8L,
      &TestKinematics_B.sf_MATLABFunction2);
    TestKinematics_DW.Motor2ReadTHETA2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S3>/Motor 2 Read - THETA2' */

  /* MATLAB Function: '<Root>/MATLAB Function' */
  a = -0.06 - std::cos(1.5707963267948966 -
                       TestKinematics_B.sf_MATLABFunction2_f.final_pos) * 0.18;
  B1_idx_1 = std::sin(1.5707963267948966 -
                      TestKinematics_B.sf_MATLABFunction2_f.final_pos) * 0.18;
  B2_idx_0 = std::cos(3.1415926535897931 - (1.5707963267948966 -
    TestKinematics_B.sf_MATLABFunction2.final_pos)) * 0.18 + 0.06;
  B2_idx_1 = std::sin(3.1415926535897931 - (1.5707963267948966 -
    TestKinematics_B.sf_MATLABFunction2.final_pos)) * 0.18;
  a = std::abs(a - B2_idx_0);
  B1_idx_1 -= B2_idx_1;
  B2_idx_1 = std::sqrt(a * a + B1_idx_1 * B1_idx_1);
  a = std::acos(((0.09 - B2_idx_1 * B2_idx_1) - 0.09) / (-2.0 * B2_idx_1 * 0.3))
    + rt_atan2d_snf(B1_idx_1, a);
  TestKinematics_B.X_foot = (std::cos(3.1415926535897931 - (1.5707963267948966 -
    TestKinematics_B.sf_MATLABFunction2.final_pos)) * 0.18 + 0.06) - std::cos(a
    + 0.066869026139001891) * 0.33672954507613351;
  TestKinematics_B.Y_foot = std::sin(3.1415926535897931 - (1.5707963267948966 -
    TestKinematics_B.sf_MATLABFunction2.final_pos)) * 0.18 + std::sin(a +
    0.066869026139001891) * 0.33672954507613351;

  /* DiscretePulseGenerator: '<Root>/change value four  times every second ' */
  TestKinematics_B.changevaluefourtimeseverysecond =
    (TestKinematics_DW.clockTickCounter_b <
     TestKinematics_cal->changevaluefourtimeseveryseco_j) &&
    (TestKinematics_DW.clockTickCounter_b >= 0) ?
    TestKinematics_cal->changevaluefourtimeseverysecond : 0.0;

  /* DiscretePulseGenerator: '<Root>/change value four  times every second ' */
  if (TestKinematics_DW.clockTickCounter_b >=
      TestKinematics_cal->changevaluefourtimeseveryseco_b - 1.0) {
    TestKinematics_DW.clockTickCounter_b = 0;
  } else {
    TestKinematics_DW.clockTickCounter_b++;
  }

  /* Outputs for Triggered SubSystem: '<Root>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S4>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.TriggeredSubsystem_Trig_ZCE,
                     (TestKinematics_B.changevaluefourtimeseverysecond));
  if (zcEvent != NO_ZCEVENT) {
    /* Memory: '<S23>/Memory1' */
    TestKinematics_B.Memory1 = TestKinematics_DW.Memory1_PreviousInput;

    /* Sum: '<S23>/Add1' incorporates:
     *  Constant: '<Root>/start counter'
     */
    TestKinematics_B.counter = TestKinematics_cal->startcounter_Value +
      TestKinematics_B.Memory1;

    /* Math: '<S23>/Mod1' incorporates:
     *  Constant: '<S23>/Reset counter  (Max value of first rotation counter)1'
     */
    TestKinematics_B.Mod1 = rt_modd_snf(TestKinematics_B.counter,
      TestKinematics_cal->ResetcounterMaxvalueoffirstrota);

    /* MATLAB Function: '<S23>/MATLAB Function1' */
    TestKinematics_B.index = std::floor(TestKinematics_B.Mod1 / 125.0) + 1.0;

    /* MATLAB Function: '<S4>/Increment through  theta array' incorporates:
     *  Constant: '<Root>/Constant1'
     *  Constant: '<Root>/Constant2'
     */
    TestKinematics_B.theta1 = TestKinematics_P.theta1_final[static_cast<int32_T>
      (TestKinematics_B.index) - 1];
    TestKinematics_B.theta2 = TestKinematics_P.theta2_final[static_cast<int32_T>
      (TestKinematics_B.index) - 1];

    /* Update for Memory: '<S23>/Memory1' */
    TestKinematics_DW.Memory1_PreviousInput = TestKinematics_B.Mod1;
    TestKinematics_DW.TriggeredSubsystem_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<Root>/Triggered Subsystem' */

  /* DiscretePulseGenerator: '<S3>/Write 1' */
  TestKinematics_B.w1 = (TestKinematics_DW.clockTickCounter_h <
    TestKinematics_cal->Write1_Duty) && (TestKinematics_DW.clockTickCounter_h >=
    0) ? TestKinematics_cal->Write1_Amp : 0.0;

  /* DiscretePulseGenerator: '<S3>/Write 1' */
  if (TestKinematics_DW.clockTickCounter_h >= TestKinematics_cal->Write1_Period
      - 1.0) {
    TestKinematics_DW.clockTickCounter_h = 0;
  } else {
    TestKinematics_DW.clockTickCounter_h++;
  }

  /* Outputs for Triggered SubSystem: '<S3>/Motor 3 Write - THETA1' incorporates:
   *  TriggerPort: '<S13>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.Motor3WriteTHETA1_Trig_ZCE,
                     (TestKinematics_B.w1));
  if (zcEvent != NO_ZCEVENT) {
    /* MATLAB Function: '<S13>/MATLAB Function' incorporates:
     *  Constant: '<S3>/Constant1'
     *  Constant: '<S3>/Constant2'
     *  Constant: '<S3>/Constant3'
     *  Constant: '<S3>/Constant4'
     */
    TestKinematics_MATLABFunction(TestKinematics_B.theta1,
      TestKinematics_cal->Constant2_Value, TestKinematics_cal->Constant3_Value,
      TestKinematics_cal->Constant4_Value, TestKinematics_cal->Constant1_Value,
      &TestKinematics_B.sf_MATLABFunction_kk);

    /* S-Function (scanpack): '<S13>/CAN Pack3' */
    /* S-Function (scanpack): '<S13>/CAN Pack3' */
    TestKinematics_B.CANPack3.ID = 3U;
    TestKinematics_B.CANPack3.Length = 8U;
    TestKinematics_B.CANPack3.Extended = 0U;
    TestKinematics_B.CANPack3.Remote = 0;
    TestKinematics_B.CANPack3.Data[0] = 0;
    TestKinematics_B.CANPack3.Data[1] = 0;
    TestKinematics_B.CANPack3.Data[2] = 0;
    TestKinematics_B.CANPack3.Data[3] = 0;
    TestKinematics_B.CANPack3.Data[4] = 0;
    TestKinematics_B.CANPack3.Data[5] = 0;
    TestKinematics_B.CANPack3.Data[6] = 0;
    TestKinematics_B.CANPack3.Data[7] = 0;

    {
      /* --------------- START Packing signal 0 ------------------
       *  startBit                = 0
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_kk.P8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[0] =
                TestKinematics_B.CANPack3.Data[0] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 1 ------------------
       *  startBit                = 8
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_kk.P8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestKinematics_B.CANPack3.Data[1] =
                TestKinematics_B.CANPack3.Data[1] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 2 ------------------
       *  startBit                = 16
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_kk.V8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[2] =
                TestKinematics_B.CANPack3.Data[2] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 3 ------------------
       *  startBit                = 28
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_kk.V4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[3] =
                TestKinematics_B.CANPack3.Data[3] | (uint8_T)((uint8_T)((uint8_T)
                (packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 4 ------------------
       *  startBit                = 24
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_kk.KP4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[3] =
                TestKinematics_B.CANPack3.Data[3] | (uint8_T)((uint8_T)
                (packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 5 ------------------
       *  startBit                = 32
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_kk.KP8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestKinematics_B.CANPack3.Data[4] =
                TestKinematics_B.CANPack3.Data[4] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 6 ------------------
       *  startBit                = 40
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_kk.KD8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[5] =
                TestKinematics_B.CANPack3.Data[5] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 7 ------------------
       *  startBit                = 52
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_kk.KD4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[6] =
                TestKinematics_B.CANPack3.Data[6] | (uint8_T)((uint8_T)((uint8_T)
                (packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 8 ------------------
       *  startBit                = 48
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_kk.T4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3.Data[6] =
                TestKinematics_B.CANPack3.Data[6] | (uint8_T)((uint8_T)
                (packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 9 ------------------
       *  startBit                = 56
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_kk.T8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestKinematics_B.CANPack3.Data[7] =
                TestKinematics_B.CANPack3.Data[7] | (uint8_T)(packedValue);
            }
          }
        }
      }
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S13>/CAN Write1' */

    /* Level2 S-Function Block: '<S13>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[7];
      sfcnOutputs(rts,0);
    }

    TestKinematics_DW.Motor3WriteTHETA1_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S3>/Motor 3 Write - THETA1' */

  /* DiscretePulseGenerator: '<S3>/Write 2' */
  TestKinematics_B.w2 = (TestKinematics_DW.clockTickCounter_m <
    TestKinematics_cal->Write2_Duty) && (TestKinematics_DW.clockTickCounter_m >=
    0) ? TestKinematics_cal->Write2_Amp : 0.0;

  /* DiscretePulseGenerator: '<S3>/Write 2' */
  if (TestKinematics_DW.clockTickCounter_m >= TestKinematics_cal->Write2_Period
      - 1.0) {
    TestKinematics_DW.clockTickCounter_m = 0;
  } else {
    TestKinematics_DW.clockTickCounter_m++;
  }

  /* Outputs for Triggered SubSystem: '<S3>/Motor 2 Write - THETA2' incorporates:
   *  TriggerPort: '<S11>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &TestKinematics_PrevZCX.Motor2WriteTHETA2_Trig_ZCE,
                     (TestKinematics_B.w2));
  if (zcEvent != NO_ZCEVENT) {
    /* MATLAB Function: '<S11>/MATLAB Function' incorporates:
     *  Constant: '<S3>/Constant5'
     *  Constant: '<S3>/Constant6'
     *  Constant: '<S3>/Constant7'
     *  Constant: '<S3>/Constant8'
     */
    TestKinematics_MATLABFunction(TestKinematics_B.theta2,
      TestKinematics_cal->Constant6_Value, TestKinematics_cal->Constant7_Value,
      TestKinematics_cal->Constant8_Value, TestKinematics_cal->Constant5_Value,
      &TestKinematics_B.sf_MATLABFunction_k);

    /* S-Function (scanpack): '<S11>/CAN Pack3' */
    /* S-Function (scanpack): '<S11>/CAN Pack3' */
    TestKinematics_B.CANPack3_m.ID = 2U;
    TestKinematics_B.CANPack3_m.Length = 8U;
    TestKinematics_B.CANPack3_m.Extended = 0U;
    TestKinematics_B.CANPack3_m.Remote = 0;
    TestKinematics_B.CANPack3_m.Data[0] = 0;
    TestKinematics_B.CANPack3_m.Data[1] = 0;
    TestKinematics_B.CANPack3_m.Data[2] = 0;
    TestKinematics_B.CANPack3_m.Data[3] = 0;
    TestKinematics_B.CANPack3_m.Data[4] = 0;
    TestKinematics_B.CANPack3_m.Data[5] = 0;
    TestKinematics_B.CANPack3_m.Data[6] = 0;
    TestKinematics_B.CANPack3_m.Data[7] = 0;

    {
      /* --------------- START Packing signal 0 ------------------
       *  startBit                = 0
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_k.P8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[0] =
                TestKinematics_B.CANPack3_m.Data[0] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 1 ------------------
       *  startBit                = 8
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestKinematics_B.sf_MATLABFunction_k.P8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestKinematics_B.CANPack3_m.Data[1] =
                TestKinematics_B.CANPack3_m.Data[1] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 2 ------------------
       *  startBit                = 16
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_k.V8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[2] =
                TestKinematics_B.CANPack3_m.Data[2] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 3 ------------------
       *  startBit                = 28
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestKinematics_B.sf_MATLABFunction_k.V4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[3] =
                TestKinematics_B.CANPack3_m.Data[3] | (uint8_T)((uint8_T)
                ((uint8_T)(packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 4 ------------------
       *  startBit                = 24
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_k.KP4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[3] =
                TestKinematics_B.CANPack3_m.Data[3] | (uint8_T)((uint8_T)
                (packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 5 ------------------
       *  startBit                = 32
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_k.KP8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestKinematics_B.CANPack3_m.Data[4] =
                TestKinematics_B.CANPack3_m.Data[4] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 6 ------------------
       *  startBit                = 40
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_k.KD8H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(255)) {
            packedValue = (uint8_T) 255;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[5] =
                TestKinematics_B.CANPack3_m.Data[5] | (uint8_T)(packedValue);
            }
          }
        }
      }

      /* --------------- START Packing signal 7 ------------------
       *  startBit                = 52
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T)
            (TestKinematics_B.sf_MATLABFunction_k.KD4L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          if (packingValue > (uint8_T)(15)) {
            packedValue = (uint8_T) 15;
          } else {
            packedValue = (uint8_T) (packingValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[6] =
                TestKinematics_B.CANPack3_m.Data[6] | (uint8_T)((uint8_T)
                ((uint8_T)(packedValue & (uint8_T)0xFU) << 4));
            }
          }
        }
      }

      /* --------------- START Packing signal 8 ------------------
       *  startBit                = 48
       *  length                  = 4
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        real64_T outValue = 0;

        {
          real64_T result = TestKinematics_B.sf_MATLABFunction_k.T4H;

          /* no scaling required */
          /* round to closest integer value for integer CAN signal */
          outValue = round(result);
        }

        {
          uint8_T packedValue;
          if (outValue > (real64_T)(15)) {
            packedValue = (uint8_T) 15;
          } else if (outValue < (real64_T)(0)) {
            packedValue = (uint8_T) 0;
          } else {
            packedValue = (uint8_T) (outValue);
          }

          {
            {
              TestKinematics_B.CANPack3_m.Data[6] =
                TestKinematics_B.CANPack3_m.Data[6] | (uint8_T)((uint8_T)
                (packedValue & (uint8_T)0xFU));
            }
          }
        }
      }

      /* --------------- START Packing signal 9 ------------------
       *  startBit                = 56
       *  length                  = 8
       *  desiredSignalByteLayout = LITTLEENDIAN
       *  dataType                = UNSIGNED
       *  factor                  = 1.0
       *  offset                  = 0.0
       *  minimum                 = 0.0
       *  maximum                 = 0.0
       * -----------------------------------------------------------------------*/
      {
        uint32_T packingValue = 0;

        {
          uint32_T result = (uint32_T) (TestKinematics_B.sf_MATLABFunction_k.T8L);

          /* no scaling required */
          packingValue = result;
        }

        {
          uint8_T packedValue;
          packedValue = (uint8_T) (packingValue);

          {
            {
              TestKinematics_B.CANPack3_m.Data[7] =
                TestKinematics_B.CANPack3_m.Data[7] | (uint8_T)(packedValue);
            }
          }
        }
      }
    }

    /* S-Function (sg_IO602_IO691_write_s): '<S11>/CAN Write1' */

    /* Level2 S-Function Block: '<S11>/CAN Write1' (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[5];
      sfcnOutputs(rts,0);
    }

    TestKinematics_DW.Motor2WriteTHETA2_SubsysRanBC = 4;
  }

  /* End of Outputs for SubSystem: '<S3>/Motor 2 Write - THETA2' */

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++TestKinematics_M->Timing.clockTick0)) {
    ++TestKinematics_M->Timing.clockTickH0;
  }

  TestKinematics_M->Timing.t[0] = TestKinematics_M->Timing.clockTick0 *
    TestKinematics_M->Timing.stepSize0 + TestKinematics_M->Timing.clockTickH0 *
    TestKinematics_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void TestKinematics_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  rtsiSetSolverName(&TestKinematics_M->solverInfo,"FixedStepDiscrete");
  TestKinematics_M->solverInfoPtr = (&TestKinematics_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = TestKinematics_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    TestKinematics_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    TestKinematics_M->Timing.sampleTimes =
      (&TestKinematics_M->Timing.sampleTimesArray[0]);
    TestKinematics_M->Timing.offsetTimes =
      (&TestKinematics_M->Timing.offsetTimesArray[0]);

    /* task periods */
    TestKinematics_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    TestKinematics_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(TestKinematics_M, &TestKinematics_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = TestKinematics_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    TestKinematics_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(TestKinematics_M, -1);
  TestKinematics_M->Timing.stepSize0 = 0.001;
  TestKinematics_M->solverInfoPtr = (&TestKinematics_M->solverInfo);
  TestKinematics_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&TestKinematics_M->solverInfo, 0.001);
  rtsiSetSolverMode(&TestKinematics_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) std::memset((static_cast<void *>(&TestKinematics_B)), 0,
                     sizeof(B_TestKinematics_T));

  {
    TestKinematics_B.CANPack3 = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANRead1_o2 = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANPack3_m = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANRead1_o2_d = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANPack1 = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANPack1_p = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANPack1_j = CAN_DATATYPE_GROUND;
    TestKinematics_B.CANPack1_j3 = CAN_DATATYPE_GROUND;
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&TestKinematics_DW), 0,
                     sizeof(DW_TestKinematics_T));

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &TestKinematics_M->NonInlinedSFcns.sfcnInfo;
    TestKinematics_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(TestKinematics_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &TestKinematics_M->Sizes.numSampTimes);
    TestKinematics_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (TestKinematics_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,TestKinematics_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(TestKinematics_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(TestKinematics_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (TestKinematics_M));
    rtssSetStepSizePtr(sfcnInfo, &TestKinematics_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(TestKinematics_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &TestKinematics_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &TestKinematics_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &TestKinematics_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &TestKinematics_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &TestKinematics_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &TestKinematics_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &TestKinematics_M->solverInfoPtr);
  }

  TestKinematics_M->Sizes.numSFcns = (9);

  /* register each child */
  {
    (void) std::memset(static_cast<void *>
                       (&TestKinematics_M->NonInlinedSFcns.childSFunctions[0]),
                       0,
                       9*sizeof(SimStruct));
    TestKinematics_M->childSfunctions =
      (&TestKinematics_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 9; i++) {
        TestKinematics_M->childSfunctions[i] =
          (&TestKinematics_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: TestKinematics/<S6>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn0.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn0.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestKinematics_B.CANPack1_j3);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestKinematics/Motor Setup/Motor Setup/Enter Motor Control Mode M2/CAN Write1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANWrite1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANWrite1_PWORK_ii);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANWrite1_PWORK_ii);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestKinematics/<S7>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn1.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestKinematics_B.CANPack1_j);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestKinematics/Motor Setup/Motor Setup/Enter Motor Control Mode M3/CAN Write1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANWrite1_P1_Size_n);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANWrite1_PWORK_i);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANWrite1_PWORK_i);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestKinematics/<S8>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn2.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn2.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestKinematics_B.CANPack1_p);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestKinematics/Motor Setup/Motor Setup/Set Origin M2/CAN Write1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANWrite1_P1_Size_c);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANWrite1_PWORK_gn);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANWrite1_PWORK_gn);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestKinematics/<S9>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn3.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn3.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestKinematics_B.CANPack1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestKinematics/Motor Setup/Motor Setup/Set Origin M3/CAN Write1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANWrite1_P1_Size_j);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANWrite1_PWORK_g);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANWrite1_PWORK_g);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestKinematics/<S10>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn4.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn4.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *)
            &TestKinematics_B.CANRead1_o1_g));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &TestKinematics_B.CANRead1_o2_d));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts, "TestKinematics/Subsystem1/Motor 2 Read - THETA2/CAN Read1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANRead1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANRead1_PWORK_a);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANRead1_PWORK_a);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: TestKinematics/<S11>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[5]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[5]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn5.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn5.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestKinematics_B.CANPack3_m);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestKinematics/Subsystem1/Motor 2 Write - THETA2/CAN Write1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANWrite1_P1_Size_f);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANWrite1_PWORK_a);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn5.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn5.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANWrite1_PWORK_a);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestKinematics/<S12>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[6]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[6]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn6.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn6.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *)
            &TestKinematics_B.CANRead1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &TestKinematics_B.CANRead1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts, "TestKinematics/Subsystem1/Motor 3 Read - THETA1/CAN Read1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANRead1_P1_Size_n);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANRead1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn6.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn6.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANRead1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: TestKinematics/<S13>/CAN Write1 (sg_IO602_IO691_write_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[7]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[7]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn7.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &TestKinematics_M->NonInlinedSFcns.Sfcn7.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &TestKinematics_B.CANPack3);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Write1");
      ssSetPath(rts,
                "TestKinematics/Subsystem1/Motor 3 Write - THETA1/CAN Write1");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANWrite1_P1_Size_e);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANWrite1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn7.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn7.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANWrite1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_write_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: TestKinematics/<S2>/CAN setup (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts = TestKinematics_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod = TestKinematics_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset = TestKinematics_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap = TestKinematics_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &TestKinematics_M->NonInlinedSFcns.blkInfo2[8]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &TestKinematics_M->NonInlinedSFcns.inputOutputPortInfo2[8]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, TestKinematics_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &TestKinematics_M->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &TestKinematics_M->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &TestKinematics_M->NonInlinedSFcns.methods4[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &TestKinematics_M->NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &TestKinematics_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* path info */
      ssSetModelName(rts, "CAN setup");
      ssSetPath(rts, "TestKinematics/Motor Setup/CAN setup");
      ssSetRTModel(rts,TestKinematics_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &TestKinematics_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)TestKinematics_cal->CANsetup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)TestKinematics_cal->CANsetup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)TestKinematics_cal->CANsetup_P3_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &TestKinematics_DW.CANsetup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn8.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &TestKinematics_M->NonInlinedSFcns.Sfcn8.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &TestKinematics_DW.CANsetup_PWORK);
      }

      /* registration */
      sg_IO602_IO691_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Start for S-Function (sg_IO602_IO691_setup_s): '<S2>/CAN setup' */
  /* Level2 S-Function Block: '<S2>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[8];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for DiscretePulseGenerator: '<S3>/Read 1' */
  TestKinematics_DW.clockTickCounter = -3001;

  /* Start for DiscretePulseGenerator: '<S3>/Read 2' */
  TestKinematics_DW.clockTickCounter_i = -3003;

  /* Start for DiscretePulseGenerator: '<Root>/change value four  times every second ' */
  TestKinematics_DW.clockTickCounter_b = -3000;

  /* Start for DiscretePulseGenerator: '<S3>/Write 1' */
  TestKinematics_DW.clockTickCounter_h = -3000;

  /* Start for DiscretePulseGenerator: '<S3>/Write 2' */
  TestKinematics_DW.clockTickCounter_m = -3001;
  TestKinematics_PrevZCX.EnterMotorControlModeM2_Trig_ZC = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.EnterMotorControlModeM3_Trig_ZC = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.SetOriginM2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.SetOriginM3_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.Motor2ReadTHETA2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.Motor2WriteTHETA2_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.Motor3ReadTHETA1_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.Motor3WriteTHETA1_Trig_ZCE = UNINITIALIZED_ZCSIG;
  TestKinematics_PrevZCX.TriggeredSubsystem_Trig_ZCE = UNINITIALIZED_ZCSIG;

  /* Start for S-Function (sg_IO602_IO691_write_s): '<S6>/CAN Write1' */
  /* Level2 S-Function Block: '<S6>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S5>/Enter Motor Control Mode M2' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S7>/CAN Write1' */
  /* Level2 S-Function Block: '<S7>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S5>/Enter Motor Control Mode M3' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S8>/CAN Write1' */
  /* Level2 S-Function Block: '<S8>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S5>/Set Origin M2' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S9>/CAN Write1' */
  /* Level2 S-Function Block: '<S9>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[3];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S5>/Set Origin M3' */
  /* Start for S-Function (sg_IO602_IO691_read_s): '<S12>/CAN Read1' */
  /* Level2 S-Function Block: '<S12>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[6];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (scanunpack): '<S12>/CAN Unpack3' */

  /*-----------S-Function Block: <S12>/CAN Unpack3 -----------------*/

  /* SystemInitialize for Enabled SubSystem: '<S12>/Enabled Subsystem' */
  TestKinem_EnabledSubsystem_Init(&TestKinematics_B.EnabledSubsystem_d,
    &TestKinematics_cal->TestKine_EnabledSubsystem_d_cal);

  /* End of SystemInitialize for SubSystem: '<S12>/Enabled Subsystem' */

  /* SystemInitialize for Outport: '<S12>/motor 3 position' */
  TestKinematics_B.sf_MATLABFunction2_f.final_pos =
    TestKinematics_cal->motor3position_Y0;

  /* End of SystemInitialize for SubSystem: '<S3>/Motor 3 Read - THETA1' */
  /* Start for S-Function (sg_IO602_IO691_read_s): '<S10>/CAN Read1' */
  /* Level2 S-Function Block: '<S10>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[4];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (scanunpack): '<S10>/CAN Unpack3' */

  /*-----------S-Function Block: <S10>/CAN Unpack3 -----------------*/

  /* SystemInitialize for Enabled SubSystem: '<S10>/Enabled Subsystem' */
  TestKinem_EnabledSubsystem_Init(&TestKinematics_B.EnabledSubsystem,
    &TestKinematics_cal->TestKinema_EnabledSubsystem_cal);

  /* End of SystemInitialize for SubSystem: '<S10>/Enabled Subsystem' */

  /* SystemInitialize for Outport: '<S10>/motor 2 position' */
  TestKinematics_B.sf_MATLABFunction2.final_pos =
    TestKinematics_cal->motor2position_Y0;

  /* End of SystemInitialize for SubSystem: '<S3>/Motor 2 Read - THETA2' */

  /* SystemInitialize for Triggered SubSystem: '<Root>/Triggered Subsystem' */
  /* InitializeConditions for Memory: '<S23>/Memory1' */
  TestKinematics_DW.Memory1_PreviousInput =
    TestKinematics_cal->Memory1_InitialCondition;

  /* SystemInitialize for Outport: '<S4>/theta1' */
  TestKinematics_B.theta1 = TestKinematics_cal->theta1_Y0;

  /* SystemInitialize for Outport: '<S4>/theta2' */
  TestKinematics_B.theta2 = TestKinematics_cal->theta2_Y0;

  /* End of SystemInitialize for SubSystem: '<Root>/Triggered Subsystem' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S13>/CAN Write1' */
  /* Level2 S-Function Block: '<S13>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[7];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S3>/Motor 3 Write - THETA1' */
  /* Start for S-Function (sg_IO602_IO691_write_s): '<S11>/CAN Write1' */
  /* Level2 S-Function Block: '<S11>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[5];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of SystemInitialize for SubSystem: '<S3>/Motor 2 Write - THETA2' */
}

/* Model terminate function */
void TestKinematics_terminate(void)
{
  /* Terminate for S-Function (sg_IO602_IO691_setup_s): '<S2>/CAN setup' */
  /* Level2 S-Function Block: '<S2>/CAN setup' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[8];
    sfcnTerminate(rts);
  }

  /* Terminate for Triggered SubSystem: '<S5>/Enter Motor Control Mode M2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S6>/CAN Write1' */
  /* Level2 S-Function Block: '<S6>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S5>/Enter Motor Control Mode M2' */

  /* Terminate for Triggered SubSystem: '<S5>/Enter Motor Control Mode M3' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S7>/CAN Write1' */
  /* Level2 S-Function Block: '<S7>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S5>/Enter Motor Control Mode M3' */

  /* Terminate for Triggered SubSystem: '<S5>/Set Origin M2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S8>/CAN Write1' */
  /* Level2 S-Function Block: '<S8>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S5>/Set Origin M2' */

  /* Terminate for Triggered SubSystem: '<S5>/Set Origin M3' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S9>/CAN Write1' */
  /* Level2 S-Function Block: '<S9>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S5>/Set Origin M3' */

  /* Terminate for Triggered SubSystem: '<S3>/Motor 3 Read - THETA1' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S12>/CAN Read1' */
  /* Level2 S-Function Block: '<S12>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S3>/Motor 3 Read - THETA1' */

  /* Terminate for Triggered SubSystem: '<S3>/Motor 2 Read - THETA2' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S10>/CAN Read1' */
  /* Level2 S-Function Block: '<S10>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S3>/Motor 2 Read - THETA2' */

  /* Terminate for Triggered SubSystem: '<S3>/Motor 3 Write - THETA1' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S13>/CAN Write1' */
  /* Level2 S-Function Block: '<S13>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S3>/Motor 3 Write - THETA1' */

  /* Terminate for Triggered SubSystem: '<S3>/Motor 2 Write - THETA2' */

  /* Terminate for S-Function (sg_IO602_IO691_write_s): '<S11>/CAN Write1' */
  /* Level2 S-Function Block: '<S11>/CAN Write1' (sg_IO602_IO691_write_s) */
  {
    SimStruct *rts = TestKinematics_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S3>/Motor 2 Write - THETA2' */
}
