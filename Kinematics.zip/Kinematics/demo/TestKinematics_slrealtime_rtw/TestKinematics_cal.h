#ifndef RTW_HEADER_TestKinematics_cal_h_
#define RTW_HEADER_TestKinematics_cal_h_
#include "rtwtypes.h"
#include "TestKinematics_types.h"

/* Storage class 'PageSwitching', for system '<S10>/Enabled Subsystem' */
typedef struct {
  struct_Qf6qpjnCSySZJkQhCiHVS Out1_Y0;/* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S15>/Out1'
                                        */
} TestK_EnabledSubsystem_cal_type;

/* Storage class 'PageSwitching', for system '<Root>' */
typedef struct {
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S14>/Constant'
                                       */
  real_T CompareToConstant_const_b; /* Mask Parameter: CompareToConstant_const_b
                                     * Referenced by: '<S18>/Constant'
                                     */
  real_T CANWrite1_P1_Size[2];         /* Computed Parameter: CANWrite1_P1_Size
                                        * Referenced by: '<S6>/CAN Write1'
                                        */
  real_T CANWrite1_P1[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S6>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_n[2];      /* Computed Parameter: CANWrite1_P1_Size_n
                                       * Referenced by: '<S7>/CAN Write1'
                                       */
  real_T CANWrite1_P1_c[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S7>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_c[2];      /* Computed Parameter: CANWrite1_P1_Size_c
                                       * Referenced by: '<S8>/CAN Write1'
                                       */
  real_T CANWrite1_P1_d[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S8>/CAN Write1'
      */
  real_T CANWrite1_P1_Size_j[2];      /* Computed Parameter: CANWrite1_P1_Size_j
                                       * Referenced by: '<S9>/CAN Write1'
                                       */
  real_T CANWrite1_P1_m[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S9>/CAN Write1'
      */
  real_T motor2position_Y0;            /* Computed Parameter: motor2position_Y0
                                        * Referenced by: '<S10>/motor 2 position'
                                        */
  real_T CANRead1_P1_Size[2];          /* Computed Parameter: CANRead1_P1_Size
                                        * Referenced by: '<S10>/CAN Read1'
                                        */
  real_T CANRead1_P1[6];
                      /* Expression: [initValues(1:4) messageType initValues(6)]
                       * Referenced by: '<S10>/CAN Read1'
                       */
  real_T CANWrite1_P1_Size_f[2];      /* Computed Parameter: CANWrite1_P1_Size_f
                                       * Referenced by: '<S11>/CAN Write1'
                                       */
  real_T CANWrite1_P1_o[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S11>/CAN Write1'
      */
  real_T motor3position_Y0;            /* Computed Parameter: motor3position_Y0
                                        * Referenced by: '<S12>/motor 3 position'
                                        */
  real_T CANRead1_P1_Size_n[2];        /* Computed Parameter: CANRead1_P1_Size_n
                                        * Referenced by: '<S12>/CAN Read1'
                                        */
  real_T CANRead1_P1_a[6];
                      /* Expression: [initValues(1:4) messageType initValues(6)]
                       * Referenced by: '<S12>/CAN Read1'
                       */
  real_T CANWrite1_P1_Size_e[2];      /* Computed Parameter: CANWrite1_P1_Size_e
                                       * Referenced by: '<S13>/CAN Write1'
                                       */
  real_T CANWrite1_P1_h[7];
     /* Expression: [initValues(1:4) messageType initValues(6) enableStatusPort]
      * Referenced by: '<S13>/CAN Write1'
      */
  real_T theta1_Y0;                    /* Computed Parameter: theta1_Y0
                                        * Referenced by: '<S4>/theta1'
                                        */
  real_T theta2_Y0;                    /* Computed Parameter: theta2_Y0
                                        * Referenced by: '<S4>/theta2'
                                        */
  real_T Memory1_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S23>/Memory1'
                                        */
  real_T ResetcounterMaxvalueoffirstrota;/* Expression: 5.001*10^3
                                          * Referenced by: '<S23>/Reset counter  (Max value of first rotation counter)1'
                                          */
  real_T CANsetup_P1_Size[2];          /* Computed Parameter: CANsetup_P1_Size
                                        * Referenced by: '<S2>/CAN setup'
                                        */
  real_T CANsetup_P1[40];
  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S2>/CAN setup'
   */
  real_T CANsetup_P2_Size[2];          /* Computed Parameter: CANsetup_P2_Size
                                        * Referenced by: '<S2>/CAN setup'
                                        */
  real_T CANsetup_P2;                  /* Expression: initStruct
                                        * Referenced by: '<S2>/CAN setup'
                                        */
  real_T CANsetup_P3_Size[2];          /* Computed Parameter: CANsetup_P3_Size
                                        * Referenced by: '<S2>/CAN setup'
                                        */
  real_T CANsetup_P3[31];              /* Expression: termStruct
                                        * Referenced by: '<S2>/CAN setup'
                                        */
  real_T Step3_Time;                   /* Expression: 2
                                        * Referenced by: '<S5>/Step3'
                                        */
  real_T Step3_Y0;                     /* Expression: 0
                                        * Referenced by: '<S5>/Step3'
                                        */
  real_T Step3_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S5>/Step3'
                                        */
  real_T Step_Time;                    /* Expression: 1.0
                                        * Referenced by: '<S5>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<S5>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 1
                                        * Referenced by: '<S5>/Step'
                                        */
  real_T Step4_Time;                   /* Expression: 1.5
                                        * Referenced by: '<S5>/Step4'
                                        */
  real_T Step4_Y0;                     /* Expression: 0
                                        * Referenced by: '<S5>/Step4'
                                        */
  real_T Step4_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S5>/Step4'
                                        */
  real_T Step1_Time;                   /* Expression: 0.5
                                        * Referenced by: '<S5>/Step1'
                                        */
  real_T Step1_Y0;                     /* Expression: 0
                                        * Referenced by: '<S5>/Step1'
                                        */
  real_T Step1_YFinal;                 /* Expression: 1
                                        * Referenced by: '<S5>/Step1'
                                        */
  real_T Read1_Amp;                    /* Expression: 1
                                        * Referenced by: '<S3>/Read 1'
                                        */
  real_T Read1_Period;                 /* Computed Parameter: Read1_Period
                                        * Referenced by: '<S3>/Read 1'
                                        */
  real_T Read1_Duty;                   /* Computed Parameter: Read1_Duty
                                        * Referenced by: '<S3>/Read 1'
                                        */
  real_T Read1_PhaseDelay;             /* Expression: 3.001
                                        * Referenced by: '<S3>/Read 1'
                                        */
  real_T Read2_Amp;                    /* Expression: 1
                                        * Referenced by: '<S3>/Read 2'
                                        */
  real_T Read2_Period;                 /* Computed Parameter: Read2_Period
                                        * Referenced by: '<S3>/Read 2'
                                        */
  real_T Read2_Duty;                   /* Computed Parameter: Read2_Duty
                                        * Referenced by: '<S3>/Read 2'
                                        */
  real_T Read2_PhaseDelay;             /* Expression: 3.003
                                        * Referenced by: '<S3>/Read 2'
                                        */
  real_T startcounter_Value;           /* Expression: 1
                                        * Referenced by: '<Root>/start counter'
                                        */
  real_T changevaluefourtimeseverysecond;/* Expression: 1
                                          * Referenced by: '<Root>/change value four  times every second '
                                          */
  real_T changevaluefourtimeseveryseco_b;
                          /* Computed Parameter: changevaluefourtimeseveryseco_b
                           * Referenced by: '<Root>/change value four  times every second '
                           */
  real_T changevaluefourtimeseveryseco_j;
                          /* Computed Parameter: changevaluefourtimeseveryseco_j
                           * Referenced by: '<Root>/change value four  times every second '
                           */
  real_T changevaluefourtimeseveryseco_p;/* Expression: 3
                                          * Referenced by: '<Root>/change value four  times every second '
                                          */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 7
                                        * Referenced by: '<S3>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 0.2
                                        * Referenced by: '<S3>/Constant4'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant1'
                                        */
  real_T Write1_Amp;                   /* Expression: 1
                                        * Referenced by: '<S3>/Write 1'
                                        */
  real_T Write1_Period;                /* Computed Parameter: Write1_Period
                                        * Referenced by: '<S3>/Write 1'
                                        */
  real_T Write1_Duty;                  /* Computed Parameter: Write1_Duty
                                        * Referenced by: '<S3>/Write 1'
                                        */
  real_T Write1_PhaseDelay;            /* Expression: 3
                                        * Referenced by: '<S3>/Write 1'
                                        */
  real_T Constant6_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant6'
                                        */
  real_T Constant7_Value;              /* Expression: 7
                                        * Referenced by: '<S3>/Constant7'
                                        */
  real_T Constant8_Value;              /* Expression: 0.2
                                        * Referenced by: '<S3>/Constant8'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant5'
                                        */
  real_T Write2_Amp;                   /* Expression: 1
                                        * Referenced by: '<S3>/Write 2'
                                        */
  real_T Write2_Period;                /* Computed Parameter: Write2_Period
                                        * Referenced by: '<S3>/Write 2'
                                        */
  real_T Write2_Duty;                  /* Computed Parameter: Write2_Duty
                                        * Referenced by: '<S3>/Write 2'
                                        */
  real_T Write2_PhaseDelay;            /* Expression: 3.002
                                        * Referenced by: '<S3>/Write 2'
                                        */
  uint8_T Constant_Value;              /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S6>/Constant'
                                        */
  uint8_T Constant1_Value_e;           /* Computed Parameter: Constant1_Value_e
                                        * Referenced by: '<S6>/Constant1'
                                        */
  uint8_T Constant2_Value_b;           /* Computed Parameter: Constant2_Value_b
                                        * Referenced by: '<S6>/Constant2'
                                        */
  uint8_T Constant3_Value_b;           /* Computed Parameter: Constant3_Value_b
                                        * Referenced by: '<S6>/Constant3'
                                        */
  uint8_T Constant4_Value_k;           /* Computed Parameter: Constant4_Value_k
                                        * Referenced by: '<S6>/Constant4'
                                        */
  uint8_T Constant5_Value_m;           /* Computed Parameter: Constant5_Value_m
                                        * Referenced by: '<S6>/Constant5'
                                        */
  uint8_T Constant6_Value_l;           /* Computed Parameter: Constant6_Value_l
                                        * Referenced by: '<S6>/Constant6'
                                        */
  uint8_T Constant7_Value_b;           /* Computed Parameter: Constant7_Value_b
                                        * Referenced by: '<S6>/Constant7'
                                        */
  uint8_T Constant_Value_l;            /* Computed Parameter: Constant_Value_l
                                        * Referenced by: '<S7>/Constant'
                                        */
  uint8_T Constant1_Value_i;           /* Computed Parameter: Constant1_Value_i
                                        * Referenced by: '<S7>/Constant1'
                                        */
  uint8_T Constant2_Value_c;           /* Computed Parameter: Constant2_Value_c
                                        * Referenced by: '<S7>/Constant2'
                                        */
  uint8_T Constant3_Value_c;           /* Computed Parameter: Constant3_Value_c
                                        * Referenced by: '<S7>/Constant3'
                                        */
  uint8_T Constant4_Value_d;           /* Computed Parameter: Constant4_Value_d
                                        * Referenced by: '<S7>/Constant4'
                                        */
  uint8_T Constant5_Value_h;           /* Computed Parameter: Constant5_Value_h
                                        * Referenced by: '<S7>/Constant5'
                                        */
  uint8_T Constant6_Value_lm;          /* Computed Parameter: Constant6_Value_lm
                                        * Referenced by: '<S7>/Constant6'
                                        */
  uint8_T Constant7_Value_e;           /* Computed Parameter: Constant7_Value_e
                                        * Referenced by: '<S7>/Constant7'
                                        */
  uint8_T Constant_Value_a;            /* Computed Parameter: Constant_Value_a
                                        * Referenced by: '<S8>/Constant'
                                        */
  uint8_T Constant1_Value_j;           /* Computed Parameter: Constant1_Value_j
                                        * Referenced by: '<S8>/Constant1'
                                        */
  uint8_T Constant2_Value_i;           /* Computed Parameter: Constant2_Value_i
                                        * Referenced by: '<S8>/Constant2'
                                        */
  uint8_T Constant3_Value_n;           /* Computed Parameter: Constant3_Value_n
                                        * Referenced by: '<S8>/Constant3'
                                        */
  uint8_T Constant4_Value_kf;          /* Computed Parameter: Constant4_Value_kf
                                        * Referenced by: '<S8>/Constant4'
                                        */
  uint8_T Constant5_Value_mp;          /* Computed Parameter: Constant5_Value_mp
                                        * Referenced by: '<S8>/Constant5'
                                        */
  uint8_T Constant6_Value_l1;          /* Computed Parameter: Constant6_Value_l1
                                        * Referenced by: '<S8>/Constant6'
                                        */
  uint8_T Constant7_Value_m;           /* Computed Parameter: Constant7_Value_m
                                        * Referenced by: '<S8>/Constant7'
                                        */
  uint8_T Constant_Value_b;            /* Computed Parameter: Constant_Value_b
                                        * Referenced by: '<S9>/Constant'
                                        */
  uint8_T Constant1_Value_jj;          /* Computed Parameter: Constant1_Value_jj
                                        * Referenced by: '<S9>/Constant1'
                                        */
  uint8_T Constant2_Value_h;           /* Computed Parameter: Constant2_Value_h
                                        * Referenced by: '<S9>/Constant2'
                                        */
  uint8_T Constant3_Value_cx;          /* Computed Parameter: Constant3_Value_cx
                                        * Referenced by: '<S9>/Constant3'
                                        */
  uint8_T Constant4_Value_p;           /* Computed Parameter: Constant4_Value_p
                                        * Referenced by: '<S9>/Constant4'
                                        */
  uint8_T Constant5_Value_i;           /* Computed Parameter: Constant5_Value_i
                                        * Referenced by: '<S9>/Constant5'
                                        */
  uint8_T Constant6_Value_lp;          /* Computed Parameter: Constant6_Value_lp
                                        * Referenced by: '<S9>/Constant6'
                                        */
  uint8_T Constant7_Value_j;           /* Computed Parameter: Constant7_Value_j
                                        * Referenced by: '<S9>/Constant7'
                                        */
  TestK_EnabledSubsystem_cal_type TestKine_EnabledSubsystem_d_cal;/* '<S12>/Enabled Subsystem' */
  TestK_EnabledSubsystem_cal_type TestKinema_EnabledSubsystem_cal;/* '<S10>/Enabled Subsystem' */
} TestKinematics_cal_type;

/* Storage class 'PageSwitching' */

/* Storage class 'PageSwitching' */
extern TestKinematics_cal_type TestKinematics_cal_impl;
extern TestKinematics_cal_type *TestKinematics_cal;

#endif                                 /* RTW_HEADER_TestKinematics_cal_h_ */
