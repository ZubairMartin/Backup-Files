#include "TestKinematics_calintf.h"
#include "TestKinematics.h"
#include "TestKinematics_cal.h"

extern TestKinematics_cal_type TestKinematics_cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    {
      (void*)&TestKinematics_cal_impl, (void**)&TestKinematics_cal, sizeof
        (TestKinematics_cal_type), 2
    } };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime
