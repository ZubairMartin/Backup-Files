/* Main generated for Simulink Real-Time model TestKinematics */
#include <ModelInfo.hpp>
#include "TestKinematics.h"
#include "TestKinematics_calintf.h"

/* Task descriptors */
slrealtime::TaskInfo task_1( 0u, std::bind(TestKinematics_step), slrealtime::TaskInfo::PERIODIC, 0.001, 0, 40);

/* Model descriptor */
slrealtime::ModelInfo TestKinematics_Info =
{
    "TestKinematics",
    TestKinematics_initialize,
    TestKinematics_terminate,
    []()->char const*& { return TestKinematics_M->errorStatus; },
    []()->unsigned char& { return TestKinematics_M->Timing.stopRequestedFlag; },
    { task_1 },
    slrealtime::getSegmentVector()
};

int main(int argc, char *argv[]) {
    return slrealtime::runModel(argc, argv, TestKinematics_Info);
}
