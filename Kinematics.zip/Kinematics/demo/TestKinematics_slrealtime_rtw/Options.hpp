#ifndef __OPTIONS_H___
#define __OPTIONS_H___

#include "simstruc_types.h"
#ifndef MT
#define MT 0                    /* MT may be undefined by simstruc_types.h */
#endif

#include "TestKinematics.h"

#define FULLMULTITHREAD	1

#endif // __OPTIONS_H___
