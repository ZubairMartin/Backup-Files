L1 = 18/100;
L2 = 18/100;
L3 = 30/100;
L4 = 30/100;
L5 = 12/100;
L6 = 4.5/100;
mu = 150*pi/180;

% TEST
X_foot = 0.1500;  
Y_foot = 0.3500;

% % q1 = 77 and q2 = 135
% X_foot = 0.0894;  
% Y_foot = 0.4243;

% % q1 = 85 and q2 = 150
% X_foot = 0.1501;  
% Y_foot = 0.3957;

% q1 = 45 and q2 = 103
% X_foot = -0.0886;  
% Y_foot = 0.4244;

% % q1 = 25 and q2 = 95
% X_foot = -0.1620;  
% Y_foot = 0.3825;

r = Y_foot;
p = L5/2 - X_foot; 

lamda = atan2(r,p);

c2 = sqrt( (X_foot - L5/2)^2 + (Y_foot)^2);

a = sqrt( (L6)^2 + (L3)^2 - 2*(L6)*(L3)*cos(mu) );
phi =  asin(L3*(sin(mu)/a));

alpha2 = acos( ((a)^2-(L2)^2-(c2)^2) / (-2*(L2)*(c2)) );
epsilon = asin(L2*(sin(alpha2)/a));
omega = pi - (phi + lamda-epsilon);
X_joint = X_foot - L6*cos(omega);
Y_joint = Y_foot - L6*sin(omega);

c1 = sqrt( (X_joint + L5/2)^2 + (Y_joint)^2);
alpha1 = acos( ((L4)^2-(L1)^2-(c1)^2) / (-2*(L1)*(c1)) );

mc1 = (Y_joint/(X_joint + L5/2));
cint1 = mc1*L5/2;

mc2 = (Y_foot/(X_foot - L5/2));
cint2 = -mc2*L5/2;

X_int = (cint2-cint1)/(mc1-mc2);
Y_int = mc1*X_int + cint1;

c1_extend = sqrt( (X_int + L5/2)^2 + (Y_int)^2);
c2_extend = sqrt( (X_int - L5/2)^2 + (Y_int)^2);

beta2 = acos( ((c1_extend)^2-(c2_extend)^2-(L5)^2) / (-2*(c2_extend)*(L5)) );
beta1 = acos( ((c2_extend)^2-(c1_extend)^2-(L5)^2) / (-2*(c1_extend)*(L5)) );

q1 = (pi - (alpha1+beta1))*180/pi
q2 = (beta2+alpha2)*180/pi



