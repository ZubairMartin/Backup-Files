%% Define values
% L1 = sym('L1','real');
% L2 = sym('L2','real');
% L3 = sym('L3','real');
% L4 = sym('L4','real');
% L5 = sym('L5','real');
% L6 = sym('L6','real');
% 
% epsilon1 = sym('epsilon1','real');
% epsilon2 = sym('epsilon2','real');

L1 = 18/100;
L2 = 18/100;
L3 = 30/100;
L4 = 30/100;
L5 = 12/100;
L6 = 4.5/100;
mu = 150*pi/180;

q1 = 75.1033*pi/180; % 77 (45) (25) (85)
q2 = 164.4557*pi/180; % 135 (103) (95) (150)

%% Find knee coordinates and distances
B1 = [-0.5*L5 - L1*cos(q1) ; L1*sin(q1)];
B2 = [0.5*L5 + L2*cos(pi-q2) ; L2*sin(pi-q2)];

a = abs(B1(1) - B2(1));
b =  B1(2) - B2(2);
B12 = sqrt(a^2 + b^2);

%% Knee angle
alpha = atan2(b,a);
beta = acos( ((L4)^2 - (B12)^2 - (L3)^2)/(-2*(B12)*(L3)) );
q3 = alpha + beta;

%% Angle between virtual leg and knee
c = sqrt(L3^2 + L6^4 - 2*L3*L6*cos(mu)); % virtual leg
lamda = asin(L6*(sin(mu)/c));

X_foot = 0.5*L5 + L2*cos(pi-q2) - c*cos(q3+lamda)
Y_foot = L2*sin(pi-q2) + c*sin(q3+lamda)


