figure()
plot(X_foot_check,Y_foot_check,'.')
axis('equal');